[Setup]
AppName=RecloserOptimisation
AppId={{E8610B90-5E6A-4C5D-9D95-5AE3C7A3B7F0}
AppVersion=1.0.0
DefaultDirName={autopf}\RecloserOptimisation
DefaultGroupName=RecloserOptimisation
OutputBaseFilename=RecloserOptimisation-Setup
OutputDir=..
UninstallDisplayName=RecloserOptimisation
UninstallDisplayIcon={app}\RecloserOptimisation.exe
Compression=lzma2/fast
SolidCompression=no
SetupIconFile=..\src\RecloserOptimisation.App\assets\icon.ico
InfoBeforeFile=..\DOWNLOAD_REQUIREMENTS.txt
PrivilegesRequired=admin
CloseApplications=yes
UsePreviousAppDir=no

[Files]
Source: "build\app\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion
Source: "..\src\RecloserOptimisation.App\assets\icon.ico"; DestDir: "{app}\Assets"; Flags: ignoreversion
Source: "..\DOWNLOAD_REQUIREMENTS.txt"; DestDir: "{app}"; Flags: ignoreversion

[InstallDelete]
Type: files; Name: "{commondesktop}\RecloserOptimisation.lnk"
Type: files; Name: "{commondesktop}\Recloser Optimisation.lnk"
Type: files; Name: "{group}\RecloserOptimisation.lnk"
Type: files; Name: "{group}\Recloser Optimisation.lnk"
Type: files; Name: "{group}\Start-RecloserOptimisation.lnk"

[Icons]
Name: "{group}\Recloser Optimisation"; Filename: "{app}\RecloserOptimisation.exe"; IconFilename: "{app}\Assets\icon.ico"
Name: "{commondesktop}\Recloser Optimisation"; Filename: "{app}\RecloserOptimisation.exe"; IconFilename: "{app}\Assets\icon.ico"
Name: "{group}\Uninstall Recloser Optimisation"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\RecloserOptimisation.exe"; Description: "Launch RecloserOptimisation"; Flags: nowait postinstall skipifsilent
