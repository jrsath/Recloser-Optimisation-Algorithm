namespace RecloserOptimisation.App.ViewModels;
 
// View model placeholder for the reports page.
public sealed class ReportsViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Reports";
}
