namespace RecloserOptimisation.App.ViewModels;

// View model placeholder for the model explorer page.
public sealed class ExplorerViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Explorer";
}
