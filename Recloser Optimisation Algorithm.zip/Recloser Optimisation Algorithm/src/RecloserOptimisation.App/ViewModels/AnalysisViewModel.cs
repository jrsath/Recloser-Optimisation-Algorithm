namespace RecloserOptimisation.App.ViewModels;

// View model placeholder for the analysis page.
public sealed class AnalysisViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Analysis";
}
