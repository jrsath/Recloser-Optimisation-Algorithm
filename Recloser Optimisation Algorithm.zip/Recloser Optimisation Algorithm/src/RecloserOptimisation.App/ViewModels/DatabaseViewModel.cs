namespace RecloserOptimisation.App.ViewModels;

// View model placeholder for the database and storage page.
public sealed class DatabaseViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Database";
}
