namespace RecloserOptimisation.App.ViewModels;

// View model placeholder for the settings page.
public sealed class SettingsViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Settings";
}
