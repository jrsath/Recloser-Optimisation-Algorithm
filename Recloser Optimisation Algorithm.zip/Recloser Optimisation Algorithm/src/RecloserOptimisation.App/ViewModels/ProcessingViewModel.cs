namespace RecloserOptimisation.App.ViewModels;

// View model placeholder for the processing page.
public sealed class ProcessingViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Processing";
}
