namespace RecloserOptimisation.App.ViewModels;
 
// View model placeholder for the validation page.
public sealed class ValidationViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Validation";
}
