namespace RecloserOptimisation.App.ViewModels;

// View model placeholder for the map page.
public sealed class MapViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Map";
}
