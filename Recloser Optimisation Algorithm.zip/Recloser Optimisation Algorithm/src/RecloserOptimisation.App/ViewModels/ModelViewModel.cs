namespace RecloserOptimisation.App.ViewModels;

// View model placeholder for the model page.
public sealed class ModelViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Model";
}
