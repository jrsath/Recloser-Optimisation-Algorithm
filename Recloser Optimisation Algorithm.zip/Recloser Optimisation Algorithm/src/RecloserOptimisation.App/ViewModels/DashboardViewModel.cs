namespace RecloserOptimisation.App.ViewModels;

// View model placeholder for the dashboard page.

public sealed class DashboardViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Dashboard";
}
