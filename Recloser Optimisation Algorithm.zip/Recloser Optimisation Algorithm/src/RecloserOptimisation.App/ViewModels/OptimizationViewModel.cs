namespace RecloserOptimisation.App.ViewModels;

// View model placeholder for the optimization page.
public sealed class OptimizationViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Optimization";
}
