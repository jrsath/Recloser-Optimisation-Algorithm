namespace RecloserOptimisation.App.ViewModels;

// View model placeholder for the outages page.
public sealed class OutagesViewModel
{
    // Display name used by the page/view registration layer.
    public string PageName => "Outages";
}
