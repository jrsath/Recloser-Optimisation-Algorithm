# ROA large processed example dataset

Synthetic King Country example data, version 1.5.

This is not real utility data. It is shaped to resemble the supplied reference map: 33 kV backbone, named recloser nodes, large 11 kV primary trunks, four-level radial branching, switches at tap-off nodes, reclosers at primary/large-area tap-offs, distributed transformers, linked loads, and normally-open interties.

Counts: 3690 nodes, 3698 lines, 627 transformers, 109 protection devices/reclosers, 404 switches, 627 loads.
