# ROA Large Example Processed Dataset

Synthetic example data for development/testing. Red network is 11 kV, blue network is 33 kV. Not real utility data.

## Shape
- Each 11 kV feeder has a main trunk through an area.
- Short laterals/sub-branches leave the trunk and remain part of the same feeder.
- A small number of nearby feeder ends are connected by normally-open interties.
- 33 kV is a simple source/backbone network.

## Counts
- Nodes: 424
- Lines: 425
- Feeders: 6
- Transformers: 88
- Loads: 88
- Protection: 18
- Switches: 20
