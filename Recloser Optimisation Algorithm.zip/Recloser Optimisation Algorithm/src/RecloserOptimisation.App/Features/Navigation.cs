using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Page navigation, shared UI helpers, and status updates.

    // Navigates to the database page from a dashboard quick action.
    private void NavigateDatabase(string view)
    {
        ShowPage("Ingestion");
        SetStatus($"Database quick action: {view}");
    }

    // Switches the visible page, updates navigation styling, and refreshes page-specific canvases.
    private void ShowPage(string name)
    {
        foreach (var page in _pages)
        {
            page.Value.Visibility = page.Key == name ? Visibility.Visible : Visibility.Collapsed;
        }

        foreach (var button in _navButtons)
        {
            var active = (string)button.Tag == name;
            button.Background = BrushFrom(active ? "#1D5ECF" : "Transparent");
            button.Foreground = BrushFrom(active ? "#FFFFFF" : "#DBE9FB");
        }

        var titles = new Dictionary<string, (string Subtitle, string Title)>
        {
            ["Dashboard"] = ("Prototype", "Dashboard"),
            ["Ingestion"] = ("File database and pipeline", "Database"),
            ["Map"] = ("Geospatial workspace", "Topology Map"),
            ["Outages"] = ("Reliability data", "Outages"),
            ["Optimization"] = ("Algorithm hub", "Optimization"),
            ["Reports"] = ("Outputs", "Reports"),
            ["Settings"] = ("Workspace", "Settings"),
        };

        ViewSubtitle.Text = titles[name].Subtitle;
        ViewTitle.Text = titles[name].Title;
        SetStatus($"Viewing {titles[name].Title}");

        if (name == "Map")
        {
            Dispatcher.BeginInvoke(new Action(RenderMap), DispatcherPriority.Loaded);
        }

        if (name == "Ingestion")
        {
            Dispatcher.BeginInvoke(new Action(RenderRadar), DispatcherPriority.Loaded);
        }
    }

    // Converts a XAML color string into a reusable WPF brush.
    private static Brush BrushFrom(string color)
    {
        return (Brush)new BrushConverter().ConvertFromString(color)!;
    }

    // Reads the displayed text from a combo box whether the value is selected or typed.
    private static string SelectedComboText(ComboBox combo)
    {
        return combo.SelectedItem is ComboBoxItem item
            ? item.Content?.ToString() ?? ""
            : combo.Text ?? "";
    }

    // Writes a status message into the application footer.
    private void SetStatus(string message)
    {
        StatusText.Text = message;
    }
}

