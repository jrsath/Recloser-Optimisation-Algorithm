using System;
using System.Linq;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    // Convert network model into reliability inputs.
    private static ReliabilityMetricsRecord CalculateReliability(
        CartesianMapRecord map,
        int proposedReclosers)
    {
        var customers =
            Math.Max(
                1,
                map.Loads.Sum(load => load.Customers));

        var totalLineKm =
            Math.Max(
                0.1,
                map.Edges.Sum(edge => edge.LengthM) / 1000.0);

        var existingReclosers =
            map.ProtectionDevices.Count(device =>
                device.AssetType.Contains(
                    "recloser",
                    StringComparison.OrdinalIgnoreCase) &&
                !device.Proposed);

        var customerInterruptions =
            TryGetOptionalDoubleProperty(
                map,
                "CustomerInterruptions");

        var customerMinutesInterrupted =
            TryGetOptionalDoubleProperty(
                map,
                "CustomerMinutesInterrupted");

        return SaidiSaifiCalculator.Calculate(
            customers,
            totalLineKm,
            map.Feeders.Count,
            existingReclosers,
            proposedReclosers,
            customerInterruptions,
            customerMinutesInterrupted);
    }

    private static double? TryGetOptionalDoubleProperty(
        object target,
        string propertyName)
    {
        var property =
            target
                .GetType()
                .GetProperty(propertyName);

        if (property is null)
        {
            return null;
        }

        var value =
            property.GetValue(target);

        return value switch
        {
            double doubleValue => doubleValue,
            float floatValue => floatValue,
            int intValue => intValue,
            long longValue => longValue,
            decimal decimalValue => (double)decimalValue,
            _ => null
        };
    }
}
