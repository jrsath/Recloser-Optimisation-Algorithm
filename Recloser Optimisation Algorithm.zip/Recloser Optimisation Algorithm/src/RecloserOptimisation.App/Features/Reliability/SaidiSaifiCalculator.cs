using System;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

internal static class SaidiSaifiCalculator
{
    public static ReliabilityMetricsRecord Calculate(
        double customers,
        double totalLineKm,
        int feederCount,
        int existingReclosers,
        int proposedReclosers,

        // Optional outage history inputs
        double? customerInterruptions = null,
        double? customerMinutesInterrupted = null)
    {
        var safeCustomers = Math.Max(1.0, customers);
        var safeLineKm = Math.Max(0.1, totalLineKm);
        var safeFeeders = Math.Max(1, feederCount);

        double saidi;
        double saifi;
        double caidi;

        // USE REAL OUTAGE DATA IF AVAILABLE
        // SAIFI = Customer Interruptions / Customers Served
        // SAIDI = Customer Minutes Interrupted / Customers Served
        // CAIDI = SAIDI / SAIFI
        if (customerInterruptions.HasValue &&
            customerMinutesInterrupted.HasValue &&
            customerInterruptions.Value > 0)
        {
            saifi =
                customerInterruptions.Value /
                safeCustomers;

            saidi =
                customerMinutesInterrupted.Value /
                safeCustomers;

            caidi =
                saifi > 0
                    ? saidi / saifi
                    : 0;
        }
        else
        {
            // ESTIMATE WHEN NO OUTAGE HISTORY EXISTS
            var kmPerFeeder =
                safeLineKm / safeFeeders;

            // Annual interruption frequency increases
            // with feeder exposure.
            var baseFailureRate =
                0.45 +
                (kmPerFeeder * 0.012);

            // Protection reduces outage frequency.
            var frequencyProtectionFactor =
                1.0 +
                (existingReclosers * 0.06) +
                (proposedReclosers * 0.15);

            saifi =
                Math.Max(
                    0.05,
                    baseFailureRate /
                    frequencyProtectionFactor);

            // Restoration time.
            var baseRestorationMinutes =
                90.0 +
                (kmPerFeeder * 0.8);

            // Reclosers reduce outage duration.
            var durationProtectionFactor =
                1.0 +
                (existingReclosers * 0.03) +
                (proposedReclosers * 0.08);

            caidi =
                Math.Max(
                    20.0,
                    baseRestorationMinutes /
                    durationProtectionFactor);

            saidi =
                saifi * caidi;
        }

        return new ReliabilityMetricsRecord
        {
            Saidi = Math.Round(saidi, 2),
            Saifi = Math.Round(saifi, 3),
            Caidi = Math.Round(caidi, 2),

            Customers = (int)Math.Round(safeCustomers),
            TotalLineKm = Math.Round(safeLineKm, 2),

            ExistingReclosers = existingReclosers,
            ProposedReclosers = proposedReclosers
        };
    }
}