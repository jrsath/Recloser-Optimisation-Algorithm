using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Central wiring for buttons, filters, maps, and selection events.

    // Connects view controls to their handlers after the split UserControls have been initialized.
    private void BindEvents()
    {
        foreach (var button in _navButtons)
        {
            button.Click += (_, _) => ShowPage((string)button.Tag);
        }

        ProjectButton.Click += (_, _) => ShowPage("Settings");
        AccountButton.Click += (_, _) => ShowPage("Settings");
        AccountCombo.SelectionChanged += (_, _) => ChangeAccount(AccountCombo.SelectedItem as UserAccount);
        ProjectCombo.SelectionChanged += (_, _) => ChangeProject(ProjectCombo.SelectedItem as ProjectRecord);
        HeaderProjectCombo.SelectionChanged += (_, _) => ChangeProject(HeaderProjectCombo.SelectedItem as ProjectRecord);
        HeaderModelCombo.SelectionChanged += (_, _) => SetStatus($"Model selected: {SelectedComboText(HeaderModelCombo)}");
        CreateAccountButton.Click += (_, _) => CreateAccount();
        CreateProjectButton.Click += (_, _) => CreateProject();
        LogoutButton.Click += (_, _) => Logout();
        SwitchAccountButton.Click += (_, _) => ShowAccountSwitch();
        VersionHistoryLimitCombo.SelectionChanged += (_, _) => ChangeVersionHistoryLimit();
        SettingsMapSourceCombo.SelectionChanged += (_, _) => ApplySettingsMapDefaults();
        SettingsMapAreaCombo.SelectionChanged += (_, _) => ApplySettingsMapDefaults();
        ProjectCacheLinzToggle.Checked += (_, _) => SaveCurrentProjectSettings();
        ProjectCacheLinzToggle.Unchecked += (_, _) => SaveCurrentProjectSettings();
        ProjectUseOfflineFirstToggle.Checked += (_, _) => SaveCurrentProjectSettings();
        ProjectUseOfflineFirstToggle.Unchecked += (_, _) => SaveCurrentProjectSettings();
        ImportTemplateButton.Click += (_, _) => ImportTemplate();
        EditTemplateButton.Click += (_, _) => SetStatus("Template editing is enabled only while Developer mode is active");
        TopImportButton.Click += (_, _) =>
        {
            ShowPage("Ingestion");
            ChooseImportFiles();
        };
        QuickImportButton.Click += (_, _) =>
        {
            ShowPage("Ingestion");
            ChooseImportFiles();
        };
        QuickDatabaseButton.Click += (_, _) => NavigateDatabase("Source files storage");
        QuickProcessingButton.Click += (_, _) => NavigateDatabase("Working directory");
        QuickMapButton.Click += (_, _) => ShowPage("Map");
        QuickOptimizationButton.Click += (_, _) => ShowPage("Optimization");
        QuickReportsButton.Click += (_, _) => ShowPage("Reports");
        ChooseFilesButton.Click += (_, _) => ChooseImportFiles();
        ChooseFolderButton.Click += (_, _) => ChooseImportFolder();
        ViewStagedButton.Click += (_, _) => ToggleStagedProcessingPanel();
        ExportManifestButton.Click += (_, _) => ExportManifest();
        ExportCurrentProjectManifestButton.Click += (_, _) => ExportManifest();
        OpenSelectedFileButton.Click += (_, _) => OpenSelectedDatabaseFile();
        BuildModelButton.Click += (_, _) => BuildModel();
        BuildModelStorageButton.Click += (_, _) => BuildModelFromStoragePrompt();
        ExportTemplateButton.Click += (_, _) => ExportTemplate();
        ExportGeoJsonButton.Click += (_, _) => ExportGeoJson();
        ImportsGrid.SelectionChanged += (_, _) => PreviewDatabaseFile(ImportsGrid.SelectedItem);
        ProcessedFilesGrid.SelectionChanged += (_, _) => PreviewDatabaseFile(ProcessedFilesGrid.SelectedItem);
        ImportsGrid.CurrentCellChanged += (_, _) =>
        {
            SaveProjectStorageMetadata();
            RefreshWorkingDirectoryStorage();
            RefreshSelectedProcessingFilesFromActiveSources();
        };
        ProcessedFilesGrid.CurrentCellChanged += (_, _) =>
        {
            SaveProjectStorageMetadata();
            RefreshWorkingDirectoryStorage();
        };
        ProjectModelStorageGrid.SelectionChanged += (_, _) => PreviewDatabaseFile(ProjectModelStorageGrid.SelectedItem);
        WorkingDirectoryGrid.SelectionChanged += (_, _) => PreviewDatabaseFile(WorkingDirectoryGrid.SelectedItem);
        ReportsGrid.SelectionChanged += (_, _) => PreviewSelectedReport();
        AdapterFilesGrid.SelectionChanged += (_, _) => UpdateAdapterPlanDetail();
        ImportAdapterPlanButton.Click += (_, _) => ImportSelectedAdapterPlan();
        UploadCustomAdapterButton.Click += (_, _) => UploadCustomAdapterPlan();
        CreateAdapterPlanButton.Click += (_, _) => CreateAdapterPlan();
        ProcessedActivateMenuItem.Click += (_, _) => ActivateSelectedStorageItem();
        ProcessedOpenMenuItem.Click += (_, _) => OpenSelectedDatabaseFile();
        ProcessedRenameMenuItem.Click += (_, _) => RenameSelectedStorageItem();
        ProcessedLockMenuItem.Click += (_, _) => ToggleSelectedStorageLock();
        ProcessedDeleteMenuItem.Click += (_, _) => DeleteSelectedStorageItem();
        ModelActivateMenuItem.Click += (_, _) => ActivateSelectedStorageItem();
        ModelOpenMenuItem.Click += (_, _) => OpenSelectedDatabaseFile();
        ModelRenameMenuItem.Click += (_, _) => RenameSelectedStorageItem();
        ModelLockMenuItem.Click += (_, _) => ToggleSelectedStorageLock();
        ModelDeleteMenuItem.Click += (_, _) => DeleteSelectedStorageItem();
        SourceActivateMenuItem.Click += (_, _) => ActivateSelectedStorageItem();
        SourceOpenMenuItem.Click += (_, _) => OpenSelectedDatabaseFile();
        SourceRenameMenuItem.Click += (_, _) => RenameSelectedStorageItem();
        SourceLockMenuItem.Click += (_, _) => ToggleSelectedStorageLock();
        SourceDeleteMenuItem.Click += (_, _) => DeleteSelectedStorageItem();
        WorkingActivateMenuItem.Click += (_, _) => ActivateSelectedStorageItem();
        WorkingOpenMenuItem.Click += (_, _) => OpenSelectedDatabaseFile();
        WorkingRenameMenuItem.Click += (_, _) => RenameSelectedStorageItem();
        WorkingLockMenuItem.Click += (_, _) => ToggleSelectedStorageLock();
        WorkingDeleteMenuItem.Click += (_, _) => DeleteSelectedStorageItem();
        ImportsGrid.PreviewMouseRightButtonDown += SelectStorageRowOnRightClick;
        ProcessedFilesGrid.PreviewMouseRightButtonDown += SelectStorageRowOnRightClick;
        ProjectModelStorageGrid.PreviewMouseRightButtonDown += SelectStorageRowOnRightClick;
        WorkingDirectoryGrid.PreviewMouseRightButtonDown += SelectStorageRowOnRightClick;
        StageProcessingButton.Click += (_, _) => ToggleProcessingFileSelection();
        ClearStagedButton.Click += (_, _) => ClearStagedProcessing();
        PauseProcessingButton.Click += (_, _) => SetProcessingRunState("Paused");
        RunProcessingButton.Click += (_, _) => SetProcessingRunState("Running");
        FileNameFilterBox.TextChanged += (_, _) => RefreshFileFilters();
        FileNameFilterBox.GotFocus += (_, _) => ClearSearchPlaceholder(FileNameFilterBox);
        FileNameFilterBox.LostFocus += (_, _) => RestoreSearchPlaceholder(FileNameFilterBox);
        ExplorerSearchBox.GotFocus += (_, _) => ClearSearchPlaceholder(ExplorerSearchBox);
        ExplorerSearchBox.LostFocus += (_, _) => RestoreSearchPlaceholder(ExplorerSearchBox);
        SourceTypeCombo.SelectionChanged += (_, _) => RefreshFileFilters();
        ProcessingModeCombo.SelectionChanged += (_, _) => ApplyProcessingMode();
        RulesetCombo.SelectionChanged += (_, _) => ApplyRulesetSelection();
        GenerateProcessedModelButton.Click += (_, _) => StageProcessing();
        CreateReportButton.Click += (_, _) => CreateReport();
        CreateOutputFilesButton.Click += (_, _) => CreateOutputFiles();
        PrepareOptimizationRunButton.Click += (_, _) => PrepareOptimizationRunSetup();
        OptimizationObjectiveCombo.SelectionChanged += (_, _) => ApplyOptimizationObjectiveMode();
        RunSetupModelCombo.SelectionChanged += (_, _) => SetStatus($"Run setup model selected: {SelectedComboText(RunSetupModelCombo)}");
        ImportOptimizationAlgorithmButton.Click += (_, _) => ImportOptimizationAlgorithm();
        ExportOptimizationLogsButton.Click += (_, _) => ExportOptimizationLogs();
        CenterMapButton.Click += (_, _) => CenterMap();
        CacheMapViewButton.Click += (_, _) =>
        {
            RenderMap();
            CacheSelectedMapOverlays();
            SetStatus("Map refreshed; online modes update cached tiles when the network is available");
        };
        MapAssetSearchButton.Click += (_, _) => SearchMapAssets();
        ImportMapLayerButton.Click += (_, _) => ImportMapLayer();
        DropMarkerButton.Click += (_, _) => DropMapMarker();
        RunMapOptimizationButton.Click += (_, _) => PrepareOptimizationRunSetup();
        CompareCandidateSitesButton.Click += (_, _) => CompareCandidateSites();
        ComparisonModeButton.Click += (_, _) => EnableComparisonMode();
        SaveSingleLineDiagramButton.Click += (_, _) => SaveSingleLineDiagram();
        ExportSingleLineDiagramButton.Click += (_, _) => ExportSingleLineDiagram();
        PrintSingleLineDiagramButton.Click += (_, _) => PrintSingleLineDiagram();
        ExpandSldPreviewButton.Click += (_, _) => ToggleSldPreviewExpansion();
        SldSearchBox.GotFocus += (_, _) => ClearSldSearchPlaceholder();
        SldSearchBox.LostFocus += (_, _) => RestoreSldSearchPlaceholder();
        SldSearchBox.TextChanged += (_, _) => RenderLastSingleLineDiagramPreview();
        MapAssetSearchBox.KeyDown += (_, e) =>
        {
            if (e.Key == Key.Enter)
            {
                SearchMapAssets();
                e.Handled = true;
            }
        };
        MapSchematicAreaCombo.SelectionChanged += (_, _) => ApplySchematicArea();
        MapViewCombo.SelectionChanged += (_, _) => ApplyMapViewMode();
        MapModeCombo.SelectionChanged += (_, _) => ApplyMapViewMode();
        MapModelCombo.SelectionChanged += (_, _) =>
        {
            CenterMapOnSelectedModel();
            ApplyMapViewMode();
            SetStatus($"Map model selected: {SelectedComboText(MapModelCombo)}");
        };
        DeveloperModeToggle.Checked += (_, _) => EnableDeveloperModelCopy();
        DeveloperModeToggle.Unchecked += (_, _) => DisableDeveloperModelCopy();
        OverlayToggle.Checked += (_, _) =>
        {
            MapEmptyBadge.Visibility = Visibility.Visible;
            RequestMapRender();
        };
        OverlayToggle.Unchecked += (_, _) =>
        {
            MapEmptyBadge.Visibility = Visibility.Collapsed;
            RequestMapRender();
        };
        MapLayerCombo.SelectionChanged += (_, _) =>
        {
            if (MapLayerCombo.SelectedItem is ComboBoxItem item)
            {
                _activeLayer = item.Content.ToString() ?? "Current project map";
                RequestMapRender();
                SetStatus($"{_activeLayer} selected");
            }
        };
        MapBaseLayerCombo.SelectionChanged += (_, _) =>
        {
            _activeBaseLayer = SelectedComboText(MapBaseLayerCombo);
            RequestMapRender();
            SetStatus($"{_activeBaseLayer} map layer selected");
        };
        LayerTopologyToggle.Checked += (_, _) => RequestMapRender();
        LayerTopologyToggle.Unchecked += (_, _) => RequestMapRender();
        LayerModelLinesToggle.Checked += (_, _) => RequestMapRender();
        LayerModelLinesToggle.Unchecked += (_, _) => RequestMapRender();
        LayerModelNodesToggle.Checked += (_, _) => RequestMapRender();
        LayerModelNodesToggle.Unchecked += (_, _) => RequestMapRender();
        LayerModelSubstationsToggle.Checked += (_, _) => RequestMapRender();
        LayerModelSubstationsToggle.Unchecked += (_, _) => RequestMapRender();
        LayerModel11KvToggle.Checked += (_, _) => RequestMapRender();
        LayerModel11KvToggle.Unchecked += (_, _) => RequestMapRender();
        LayerModel33KvToggle.Checked += (_, _) => RequestMapRender();
        LayerModel33KvToggle.Unchecked += (_, _) => RequestMapRender();
        LayerModelLoadsToggle.Checked += (_, _) => RequestMapRender();
        LayerModelLoadsToggle.Unchecked += (_, _) => RequestMapRender();
        LayerModelTransformersToggle.Checked += (_, _) => RequestMapRender();
        LayerModelTransformersToggle.Unchecked += (_, _) => RequestMapRender();
        LayerModelSwitchesToggle.Checked += (_, _) => RequestMapRender();
        LayerModelSwitchesToggle.Unchecked += (_, _) => RequestMapRender();
        LayerModelProtectionToggle.Checked += (_, _) => RequestMapRender();
        LayerModelProtectionToggle.Unchecked += (_, _) => RequestMapRender();
        LayerOutagesToggle.Checked += (_, _) => RequestMapRender();
        LayerOutagesToggle.Unchecked += (_, _) => RequestMapRender();
        LayerLinzParcelsToggle.Checked += (_, _) => RequestMapRender();
        LayerLinzParcelsToggle.Unchecked += (_, _) => RequestMapRender();
        LayerLinzAddressesToggle.Checked += (_, _) => RequestMapRender();
        LayerLinzAddressesToggle.Unchecked += (_, _) => RequestMapRender();
        LayerHeightToggle.Checked += (_, _) => RequestMapRender();
        LayerHeightToggle.Unchecked += (_, _) => RequestMapRender();
        SearchGoogleMapsMenuItem.Click += (_, _) => OpenCurrentMapPoint();
        CopyMapCoordinatesMenuItem.Click += (_, _) => CopyCurrentMapCoordinates();

        MapHost.SizeChanged += (_, _) => RequestMapRender();
        MapHost.MouseWheel += MapHostOnMouseWheel;
        MapHost.MouseLeftButtonDown += MapHostOnMouseLeftButtonDown;
        MapHost.MouseLeftButtonUp += MapHostOnMouseLeftButtonUp;
        MapHost.MouseRightButtonDown += MapHostOnMouseRightButtonDown;
        MapHost.MouseLeave += (_, _) => StopMapDrag();
        MapHost.MouseMove += MapHostOnMouseMove;

        RegisterPageScrolling(DashboardPage, IngestionPage, ProcessingPage, ModelPage, ExplorerPage, ValidationPage, AnalysisPage, OutagesPage, OptimizationPage, ReportsPage, SettingsPage);
    }

    // Enables smoother vertical mouse-wheel scrolling across all top-level pages.
    private static void RegisterPageScrolling(params ScrollViewer[] pages)
    {
        foreach (var page in pages)
        {
            page.PanningMode = PanningMode.VerticalOnly;
            page.PreviewMouseWheel += PageScrollViewerOnPreviewMouseWheel;
        }
    }

    // Applies mouse-wheel delta directly to the containing page scroll viewer.
    private static void PageScrollViewerOnPreviewMouseWheel(object sender, MouseWheelEventArgs e)
    {
        if (sender is not ScrollViewer viewer)
        {
            return;
        }

        viewer.ScrollToVerticalOffset(viewer.VerticalOffset - e.Delta);
        e.Handled = true;
    }
}
