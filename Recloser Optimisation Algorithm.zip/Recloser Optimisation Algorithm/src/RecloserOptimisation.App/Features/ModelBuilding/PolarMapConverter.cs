using System;
using System.Collections.Generic;
using System.Linq;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    // Choose a substation origin, project each node to metres, then convert every edge to length and bearing.
    private static PolarMapRecord ConvertCartesianToPolarMap(CartesianMapRecord map)
    {
        var origin = map.Nodes.FirstOrDefault(node => node.Type.Contains("substation", StringComparison.OrdinalIgnoreCase))
            ?? map.Nodes.FirstOrDefault()
            ?? new CartesianNodeRecord();
        var originLat = origin.Latitude;
        var originLng = origin.Longitude;
        var polar = new PolarMapRecord
        {
            OriginNodeId = origin.Id,
            OriginLatitude = originLat,
            OriginLongitude = originLng,
        };

        foreach (var node in map.Nodes)
        {
            var (x, y) = LatLngToMetres(originLat, originLng, node.Latitude, node.Longitude);
            polar.Nodes.Add(new PolarNodeRecord
            {
                NodeId = node.Id,
                Type = node.Type,
                FeederId = node.FeederId,
                XMetres = x,
                YMetres = y,
                RadiusM = Math.Sqrt(x * x + y * y),
                AngleDeg = NormalizeAngle(Math.Atan2(y, x) * 180.0 / Math.PI),
            });
        }

        var polarNodes = polar.Nodes.ToDictionary(node => node.NodeId, StringComparer.OrdinalIgnoreCase);
        foreach (var edge in map.Edges)
        {
            if (!polarNodes.TryGetValue(edge.FromNode, out var from) || !polarNodes.TryGetValue(edge.ToNode, out var to))
            {
                continue;
            }

            var dx = to.XMetres - from.XMetres;
            var dy = to.YMetres - from.YMetres;
            polar.Edges.Add(new PolarEdgeRecord
            {
                EdgeId = edge.Id,
                FromNode = edge.FromNode,
                ToNode = edge.ToNode,
                FeederId = edge.FeederId,
                LengthM = edge.LengthM > 0 ? edge.LengthM : Math.Sqrt(dx * dx + dy * dy),
                AngleDeg = NormalizeAngle(Math.Atan2(dy, dx) * 180.0 / Math.PI),
                VoltageKv = edge.VoltageKv,
            });
        }

        return polar;
    }

    // Approximate local latitude/longitude offsets as x/y metre offsets from the origin.
    private static (double X, double Y) LatLngToMetres(double originLat, double originLng, double latitude, double longitude)
    {
        const double metresPerDegreeLat = 111_320.0;
        var metresPerDegreeLng = metresPerDegreeLat * Math.Cos(originLat * Math.PI / 180.0);
        return ((longitude - originLng) * metresPerDegreeLng, (latitude - originLat) * metresPerDegreeLat);
    }

    // Convert negative bearings into the 0-360 degree range expected by optimization vectors.
    private static double NormalizeAngle(double angle)
    {
        return angle < 0 ? angle + 360.0 : angle;
    }
}
