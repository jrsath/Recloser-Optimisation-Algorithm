using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    private static readonly string[] ModelInputFiles =
    {
        "nodes.csv",
        "lines.csv",
        "loads.csv",
        "transformers.csv",
        "switches.csv",
        "protection.csv",
        "feeders.csv",
    };

    // Builds a base model, then converts it into Cartesian and polar forms.
    private void BuildModel()
    {
        var activeFiles = _processedFiles.Where(file => file.Active).ToList();
        if (activeFiles.Count == 0)
        {
            SetStatus("Activate at least one processed file before building a model");
            return;
        }

        BuildModelFromFiles(activeFiles, "active processed");
    }

    // Opens a file picker dialog over processed storage so selected files can build a project model.
    private void BuildModelFromStoragePrompt()
    {
        var dialog = new Window
        {
            Owner = this,
            Title = "Build Project Model",
            Width = 520,
            Height = 460,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
        };

        var list = new ListBox
        {
            SelectionMode = SelectionMode.Multiple,
            DisplayMemberPath = "File",
            ItemsSource = _processedFiles,
            Margin = new Thickness(0, 0, 0, 12),
        };

        var buildButton = new Button
        {
            Content = "Build Model",
            Width = 120,
            HorizontalAlignment = HorizontalAlignment.Right,
        };

        var panel = new StackPanel { Margin = new Thickness(16) };
        panel.Children.Add(new TextBlock
        {
            Text = "Select processed files to build into a saved project model.",
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(0, 0, 0, 12),
        });
        panel.Children.Add(list);
        panel.Children.Add(buildButton);
        dialog.Content = panel;

        buildButton.Click += (_, _) =>
        {
            var selectedFiles = list.SelectedItems.Cast<ProcessedFile>().ToList();
            if (selectedFiles.Count == 0)
            {
                SetStatus("Select at least one processed file to build a model");
                return;
            }

            dialog.DialogResult = true;
            BuildModelFromFiles(selectedFiles, "selected project storage");
        };

        dialog.ShowDialog();
    }

    // Serializes a built model from selected processed files and makes it the active map layer.
    private void BuildModelFromFiles(List<ProcessedFile> activeFiles, string sourceLabel)
    {
        var project = _workspaceStore.CurrentProject(_workspaceState);
        var previousModelId = project.Settings.ActiveModelId;
        var baseModel = BuildBaseModel(activeFiles);
        var cartesianMap = ConvertBaseModelToCartesianMap(baseModel);
        var polarMap = ConvertCartesianToPolarMap(cartesianMap);
        var reliability = CalculateReliability(cartesianMap, proposedReclosers: 0);
        var model = new BuiltModelRecord
        {
            Id = $"base-model-{DateTime.UtcNow:yyyyMMdd-HHmmss}",
            Name = $"Base model {DateTime.Now:yyyy-MM-dd HH:mm}",
            ProjectId = project.Id,
            Status = "Base model converted to cartesian and polar",
            SourceProcessedFiles = activeFiles.Select(file => file.File).ToList(),
            BaseModel = baseModel,
            CartesianMap = cartesianMap,
            PolarMap = polarMap,
            BaselineReliability = reliability,
            ValidationMessages =
            {
                $"Built from {sourceLabel} file selection.",
                previousModelId.Length > 0 ? $"Previous active model version saved: {previousModelId}." : "No previous active model existed.",
                "Pipeline step 1 complete: processed files parsed into a base model.",
                "Pipeline step 2 complete: base model converted into a Cartesian map for display.",
                "Pipeline step 3 complete: Cartesian map converted into a polar vector map for optimization.",
            },
        };

        model.ValidationMessages.Add($"Base model saved: {baseModel.Nodes.Count} nodes, {baseModel.Lines.Count} lines, {baseModel.Loads.Count} loads.");
        model.ValidationMessages.Add($"Cartesian geometry saved: {cartesianMap.Nodes.Count} nodes and {cartesianMap.Edges.Count} edges.");
        model.ValidationMessages.Add($"Components saved: {cartesianMap.Loads.Count} loads, {cartesianMap.Transformers.Count} transformers, {cartesianMap.Switches.Count} switches, {cartesianMap.ProtectionDevices.Count} protection devices, {cartesianMap.Feeders.Count} feeders.");
        model.ValidationMessages.Add($"Baseline reliability: SAIDI {reliability.Saidi:N2}, SAIFI {reliability.Saifi:N3}, CAIDI {reliability.Caidi:N2}, customers {reliability.Customers:N0}.");

        SaveBuiltModel(model);
        LoadBuiltModelStorage();
        SelectComboContent(MapModelCombo, $"{model.Id} model layer");
        SelectComboContent(HeaderModelCombo, model.Id);
        CenterMapOnCartesianMap(cartesianMap);
        RenderMap();
        SetStatus($"Built base model and map conversions: {cartesianMap.Nodes.Count} nodes, {cartesianMap.Edges.Count} lines, SAIDI {reliability.Saidi:N2}, SAIFI {reliability.Saifi:N3}");
    }

    // Writes a built model to current storage and history, then marks it as active.
    private void SaveBuiltModel(BuiltModelRecord model)
    {
        var project = _workspaceStore.CurrentProject(_workspaceState);
        var builtModelsPath = _workspaceStore.BuiltModelsPath(_workspaceState);
        var historyPath = _workspaceStore.ModelHistoryPath(_workspaceState);
        var fileName = $"{model.Id}.json";
        var content = JsonSerializer.Serialize(model, _jsonOptions);
        File.WriteAllText(Path.Combine(builtModelsPath, fileName), content);
        File.WriteAllText(Path.Combine(historyPath, fileName), content);

        project.Settings.ActiveModelId = model.Id;
        project.UpdatedAt = DateTime.UtcNow;
        _workspaceStore.Save(_workspaceState);
    }

    // Parses processed inputs into the source-oriented base model.
    private BaseModelRecord BuildBaseModel(List<ProcessedFile> activeFiles)
    {
        var sourcePaths = ResolveModelSourcePaths(activeFiles);
        var byName = sourcePaths
            .GroupBy(path => Path.GetFileName(path), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.First(), StringComparer.OrdinalIgnoreCase);

        var model = new BaseModelRecord
        {
            SourceFiles = sourcePaths.Select(Path.GetFileName).Where(name => !string.IsNullOrWhiteSpace(name)).Select(name => name!).OrderBy(name => name).ToList(),
        };
        if (byName.TryGetValue("nodes.csv", out var nodesPath))
        {
            model.Nodes.AddRange(ParseCartesianNodes(nodesPath));
        }

        if (byName.TryGetValue("lines.csv", out var linesPath))
        {
            model.Lines.AddRange(ParseCartesianEdges(linesPath));
        }

        if (byName.TryGetValue("loads.csv", out var loadsPath))
        {
            model.Loads.AddRange(ParseLoads(loadsPath));
        }

        if (byName.TryGetValue("transformers.csv", out var transformersPath))
        {
            model.Transformers.AddRange(ParseTransformers(transformersPath));
        }

        if (byName.TryGetValue("switches.csv", out var switchesPath))
        {
            model.Switches.AddRange(ParseSwitches(switchesPath));
        }

        if (byName.TryGetValue("protection.csv", out var protectionPath))
        {
            model.ProtectionDevices.AddRange(ParseProtectionDevices(protectionPath));
        }

        if (byName.TryGetValue("feeders.csv", out var feedersPath))
        {
            model.Feeders.AddRange(ParseFeeders(feedersPath));
        }

        if (model.Nodes.Count == 0)
        {
            model.Nodes.AddRange(BuildFallbackCartesianNodes(activeFiles));
        }

        return model;
    }

    // Converts the source-oriented base model into Cartesian geometry for map display.
    private static CartesianMapRecord ConvertBaseModelToCartesianMap(BaseModelRecord model)
    {
        var map = new CartesianMapRecord
        {
            CoordinateSystem = model.CoordinateSystem,
            Nodes = model.Nodes.ToList(),
            Edges = model.Lines.ToList(),
            Loads = model.Loads.ToList(),
            Transformers = model.Transformers.ToList(),
            Switches = model.Switches.ToList(),
            ProtectionDevices = model.ProtectionDevices.ToList(),
            Feeders = model.Feeders.ToList(),
        };

        FillMissingLineLengths(map);
        return map;
    }

    // Builds a source path set from selected files plus sibling processed dataset files.
    private List<string> ResolveModelSourcePaths(List<ProcessedFile> activeFiles)
    {
        var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var file in activeFiles)
        {
            AddModelSourcePath(paths, ResolveProcessedSourcePath(file));
        }

        foreach (var folder in paths.Select(Path.GetDirectoryName).Where(path => !string.IsNullOrWhiteSpace(path)).Distinct(StringComparer.OrdinalIgnoreCase).ToList())
        {
            foreach (var modelInput in ModelInputFiles)
            {
                AddModelSourcePath(paths, Path.Combine(folder!, modelInput));
            }
        }

        return paths.Where(File.Exists).ToList();
    }

    // Adds a model source path if it exists and is a file.
    private static void AddModelSourcePath(HashSet<string> paths, string path)
    {
        if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
        {
            paths.Add(path);
        }
    }

    // Resolves a processed file back to its original source path when prototype metadata contains one.
    private string ResolveProcessedSourcePath(ProcessedFile file)
    {
        var path = ResolvePreviewPath(file.Path);
        if (!File.Exists(path))
        {
            return "";
        }

        if (!Path.GetExtension(path).Equals(".json", StringComparison.OrdinalIgnoreCase))
        {
            return path;
        }

        try
        {
            using var document = JsonDocument.Parse(File.ReadAllText(path));
            if (document.RootElement.TryGetProperty("SourcePath", out var sourcePath))
            {
                var resolved = ResolvePreviewPath(sourcePath.GetString() ?? "");
                return File.Exists(resolved) ? resolved : path;
            }
        }
        catch
        {
            return path;
        }

        return path;
    }

    // Converts Cartesian nodes and edges into a polar vector representation for optimization.
    private static PolarMapRecord ConvertCartesianToPolarMap(CartesianMapRecord map)
    {
        var origin = map.Nodes.FirstOrDefault(node => node.Type.Contains("substation", StringComparison.OrdinalIgnoreCase))
            ?? map.Nodes.FirstOrDefault()
            ?? new CartesianNodeRecord();
        var originLat = origin.Latitude;
        var originLng = origin.Longitude;
        var polar = new PolarMapRecord
        {
            OriginNodeId = origin.Id,
            OriginLatitude = originLat,
            OriginLongitude = originLng,
        };

        foreach (var node in map.Nodes)
        {
            var (x, y) = LatLngToMetres(originLat, originLng, node.Latitude, node.Longitude);
            polar.Nodes.Add(new PolarNodeRecord
            {
                NodeId = node.Id,
                Type = node.Type,
                FeederId = node.FeederId,
                XMetres = x,
                YMetres = y,
                RadiusM = Math.Sqrt(x * x + y * y),
                AngleDeg = NormalizeAngle(Math.Atan2(y, x) * 180.0 / Math.PI),
            });
        }

        var polarNodes = polar.Nodes.ToDictionary(node => node.NodeId, StringComparer.OrdinalIgnoreCase);
        foreach (var edge in map.Edges)
        {
            if (!polarNodes.TryGetValue(edge.FromNode, out var from) || !polarNodes.TryGetValue(edge.ToNode, out var to))
            {
                continue;
            }

            var dx = to.XMetres - from.XMetres;
            var dy = to.YMetres - from.YMetres;
            polar.Edges.Add(new PolarEdgeRecord
            {
                EdgeId = edge.Id,
                FromNode = edge.FromNode,
                ToNode = edge.ToNode,
                FeederId = edge.FeederId,
                LengthM = edge.LengthM > 0 ? edge.LengthM : Math.Sqrt(dx * dx + dy * dy),
                AngleDeg = NormalizeAngle(Math.Atan2(dy, dx) * 180.0 / Math.PI),
                VoltageKv = edge.VoltageKv,
            });
        }

        return polar;
    }

    // Calculates a deterministic baseline reliability estimate from line length, customers, and protection density.
    private static ReliabilityMetricsRecord CalculateReliability(CartesianMapRecord map, int proposedReclosers)
    {
        var customers = Math.Max(1, map.Loads.Sum(load => load.Customers));
        var totalLineKm = Math.Max(0.1, map.Edges.Sum(edge => edge.LengthM) / 1000.0);
        var existingReclosers = map.ProtectionDevices.Count(device => device.AssetType.Contains("recloser", StringComparison.OrdinalIgnoreCase) && !device.Proposed);
        var protectionFactor = 1.0 + (existingReclosers * 0.055) + (proposedReclosers * 0.12);
        var ruralExposure = totalLineKm / Math.Max(1, map.Feeders.Count);
        var saifi = Math.Round((0.42 + ruralExposure * 0.018 + customers / 120000.0) / protectionFactor, 3);
        var caidi = Math.Round(78.0 + ruralExposure * 1.7, 2);
        var saidi = Math.Round(saifi * caidi, 2);

        return new ReliabilityMetricsRecord
        {
            Saidi = saidi,
            Saifi = saifi,
            Caidi = caidi,
            Customers = customers,
            TotalLineKm = Math.Round(totalLineKm, 2),
            ExistingReclosers = existingReclosers,
            ProposedReclosers = proposedReclosers,
        };
    }

    // Reads processed nodes.csv rows into Cartesian node records with coordinates and feeder IDs.
    private static IEnumerable<CartesianNodeRecord> ParseCartesianNodes(string path)
    {
        foreach (var row in ReadCsvRows(path))
        {
            if (!row.TryGetValue("NodeID", out var id)
                || !TryGetDouble(row, "Latitude", out var latitude)
                || !TryGetDouble(row, "Longitude", out var longitude))
            {
                continue;
            }

            yield return new CartesianNodeRecord
            {
                Id = id,
                Type = Get(row, "NodeType"),
                Latitude = latitude,
                Longitude = longitude,
                ElevationM = GetDouble(row, "Elevation_m"),
                FeederId = Get(row, "FeederID"),
                Source = Get(row, "Source"),
                Status = Get(row, "Status"),
            };
        }
    }

    // Reads processed lines.csv rows into Cartesian edge records linking node IDs.
    private static IEnumerable<CartesianEdgeRecord> ParseCartesianEdges(string path)
    {
        foreach (var row in ReadCsvRows(path))
        {
            var fromNode = Get(row, "FromNode");
            var toNode = Get(row, "ToNode");
            if (string.IsNullOrWhiteSpace(fromNode) || string.IsNullOrWhiteSpace(toNode))
            {
                continue;
            }

            yield return new CartesianEdgeRecord
            {
                Id = Get(row, "LineID", $"{fromNode}-{toNode}"),
                FromNode = fromNode,
                ToNode = toNode,
                FeederId = Get(row, "FeederID"),
                VoltageKv = GetDouble(row, "Voltage_kV"),
                LengthM = GetDouble(row, "Length_m"),
                Conductor = Get(row, "Conductor"),
                Phase = Get(row, "Phase"),
                NormallyEnergised = GetBool(row, "NormallyEnergised", defaultValue: true),
                Status = Get(row, "Status"),
            };
        }
    }

    private static IEnumerable<ModelLoadRecord> ParseLoads(string path)
    {
        foreach (var row in ReadCsvRows(path))
        {
            yield return new ModelLoadRecord
            {
                Id = Get(row, "LoadID"),
                NodeId = Get(row, "NodeID"),
                Kva = GetDouble(row, "kVA"),
                Customers = GetInt(row, "Customers"),
                Phase = Get(row, "Phase"),
                FeederId = Get(row, "FeederID"),
                Status = Get(row, "Status"),
            };
        }
    }

    private static IEnumerable<ModelTransformerRecord> ParseTransformers(string path)
    {
        foreach (var row in ReadCsvRows(path))
        {
            yield return new ModelTransformerRecord
            {
                Id = Get(row, "TransformerID"),
                NodeId = Get(row, "NodeID"),
                Kva = GetDouble(row, "kVA"),
                PrimaryKv = GetDouble(row, "Primary_kV"),
                SecondaryKv = GetDouble(row, "Secondary_kV"),
                Phase = Get(row, "Phase"),
                FeederId = Get(row, "FeederID"),
                Status = Get(row, "Status"),
            };
        }
    }

    private static IEnumerable<ModelSwitchRecord> ParseSwitches(string path)
    {
        foreach (var row in ReadCsvRows(path))
        {
            yield return new ModelSwitchRecord
            {
                Id = Get(row, "SwitchID"),
                SwitchType = Get(row, "SwitchType"),
                NodeId = Get(row, "NodeID"),
                Normally = Get(row, "Normally"),
                VoltageKv = GetDouble(row, "Voltage_kV"),
                FeederId = Get(row, "FeederID"),
                Status = Get(row, "Status"),
            };
        }
    }

    private static IEnumerable<ModelProtectionDeviceRecord> ParseProtectionDevices(string path)
    {
        foreach (var row in ReadCsvRows(path))
        {
            yield return new ModelProtectionDeviceRecord
            {
                Id = Get(row, "AssetID"),
                AssetType = Get(row, "AssetType"),
                NodeId = Get(row, "NodeID"),
                VoltageKv = GetDouble(row, "Voltage_kV"),
                FeederId = Get(row, "FeederID"),
                Model = Get(row, "Model"),
                Status = Get(row, "Status"),
            };
        }
    }

    private static IEnumerable<ModelFeederRecord> ParseFeeders(string path)
    {
        foreach (var row in ReadCsvRows(path))
        {
            yield return new ModelFeederRecord
            {
                Id = Get(row, "FeederID"),
                Name = Get(row, "Name"),
                SourceSubstation = Get(row, "SourceSubstation"),
                NominalVoltageKv = GetDouble(row, "NominalVoltage_kV"),
                Status = Get(row, "Status"),
            };
        }
    }

    // Streams CSV rows into case-insensitive dictionaries keyed by header name.
    private static IEnumerable<Dictionary<string, string>> ReadCsvRows(string path)
    {
        using var reader = new StreamReader(path);
        var headerLine = reader.ReadLine();
        if (string.IsNullOrWhiteSpace(headerLine))
        {
            yield break;
        }

        var headers = SplitCsvLine(headerLine).ToArray();
        while (!reader.EndOfStream)
        {
            var values = SplitCsvLine(reader.ReadLine() ?? "").ToArray();
            var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < headers.Length && i < values.Length; i++)
            {
                row[headers[i]] = values[i];
            }

            yield return row;
        }
    }

    // Splits one simple CSV line while preserving commas inside quoted values.
    private static IEnumerable<string> SplitCsvLine(string line)
    {
        var values = new List<string>();
        var current = "";
        var inQuotes = false;
        foreach (var character in line)
        {
            if (character == '"')
            {
                inQuotes = !inQuotes;
                continue;
            }

            if (character == ',' && !inQuotes)
            {
                values.Add(current);
                current = "";
                continue;
            }

            current += character;
        }

        values.Add(current);
        return values;
    }

    private static string Get(Dictionary<string, string> row, string key, string fallback = "")
    {
        return row.TryGetValue(key, out var value) ? value : fallback;
    }

    private static double GetDouble(Dictionary<string, string> row, string key)
    {
        return TryGetDouble(row, key, out var value) ? value : 0;
    }

    private static bool TryGetDouble(Dictionary<string, string> row, string key, out double value)
    {
        return double.TryParse(Get(row, key), NumberStyles.Float, CultureInfo.InvariantCulture, out value);
    }

    private static int GetInt(Dictionary<string, string> row, string key)
    {
        return int.TryParse(Get(row, key), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value) ? value : 0;
    }

    private static bool GetBool(Dictionary<string, string> row, string key, bool defaultValue = false)
    {
        var value = Get(row, key);
        if (string.IsNullOrWhiteSpace(value))
        {
            return defaultValue;
        }

        return value.Equals("true", StringComparison.OrdinalIgnoreCase)
            || value.Equals("yes", StringComparison.OrdinalIgnoreCase)
            || value.Equals("1", StringComparison.OrdinalIgnoreCase)
            || value.Equals("closed", StringComparison.OrdinalIgnoreCase);
    }

    private static void FillMissingLineLengths(CartesianMapRecord map)
    {
        var nodes = map.Nodes.ToDictionary(node => node.Id, StringComparer.OrdinalIgnoreCase);
        foreach (var edge in map.Edges.Where(edge => edge.LengthM <= 0))
        {
            if (nodes.TryGetValue(edge.FromNode, out var from) && nodes.TryGetValue(edge.ToNode, out var to))
            {
                edge.LengthM = HaversineMetres(from.Latitude, from.Longitude, to.Latitude, to.Longitude);
            }
        }
    }

    private static (double X, double Y) LatLngToMetres(double originLat, double originLng, double latitude, double longitude)
    {
        const double metresPerDegreeLat = 111_320.0;
        var metresPerDegreeLng = metresPerDegreeLat * Math.Cos(originLat * Math.PI / 180.0);
        return ((longitude - originLng) * metresPerDegreeLng, (latitude - originLat) * metresPerDegreeLat);
    }

    private static double HaversineMetres(double lat1, double lng1, double lat2, double lng2)
    {
        const double earthRadiusM = 6_371_000.0;
        var dLat = (lat2 - lat1) * Math.PI / 180.0;
        var dLng = (lng2 - lng1) * Math.PI / 180.0;
        var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2)
            + Math.Cos(lat1 * Math.PI / 180.0) * Math.Cos(lat2 * Math.PI / 180.0)
            * Math.Sin(dLng / 2) * Math.Sin(dLng / 2);
        return earthRadiusM * 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
    }

    private static double NormalizeAngle(double angle)
    {
        return angle < 0 ? angle + 360.0 : angle;
    }

    // Creates temporary map nodes when selected processed files do not include node CSV geometry yet.
    private static IEnumerable<CartesianNodeRecord> BuildFallbackCartesianNodes(List<ProcessedFile> activeFiles)
    {
        var seed = new[]
        {
            (-38.3350, 175.1650),
            (-38.3600, 175.1200),
            (-38.3050, 175.2100),
            (-38.3900, 175.2400),
        };

        for (var i = 0; i < activeFiles.Count && i < seed.Length; i++)
        {
            yield return new CartesianNodeRecord
            {
                Id = Path.GetFileNameWithoutExtension(activeFiles[i].File),
                Type = "Processed input",
                Latitude = seed[i].Item1,
                Longitude = seed[i].Item2,
                FeederId = "fallback",
            };
        }
    }
}
