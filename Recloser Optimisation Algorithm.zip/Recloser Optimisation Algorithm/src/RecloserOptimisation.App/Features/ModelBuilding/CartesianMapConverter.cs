using System;
using System.Linq;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    // Copy base model tables into map tables, then repair missing edge lengths from node coordinates.
    private static CartesianMapRecord ConvertBaseModelToCartesianMap(BaseModelRecord model)
    {
        var map = new CartesianMapRecord
        {
            CoordinateSystem = model.CoordinateSystem,
            Nodes = model.Nodes.ToList(),
            Edges = model.Lines.ToList(),
            Loads = model.Loads.ToList(),
            Transformers = model.Transformers.ToList(),
            Switches = model.Switches.ToList(),
            ProtectionDevices = model.ProtectionDevices.ToList(),
            Feeders = model.Feeders.ToList(),
        };

        FillMissingLineLengths(map);
        return map;
    }

    // For each edge with no length, find both endpoint nodes and calculate geographic distance.
    private static void FillMissingLineLengths(CartesianMapRecord map)
    {
        var nodes = map.Nodes.ToDictionary(node => node.Id, StringComparer.OrdinalIgnoreCase);
        foreach (var edge in map.Edges.Where(edge => edge.LengthM <= 0))
        {
            if (nodes.TryGetValue(edge.FromNode, out var from) && nodes.TryGetValue(edge.ToNode, out var to))
            {
                edge.LengthM = HaversineMetres(from.Latitude, from.Longitude, to.Latitude, to.Longitude);
            }
        }
    }

    // Apply the haversine formula to convert latitude/longitude difference into metres.
    private static double HaversineMetres(double lat1, double lng1, double lat2, double lng2)
    {
        const double earthRadiusM = 6_371_000.0;
        var dLat = (lat2 - lat1) * Math.PI / 180.0;
        var dLng = (lng2 - lng1) * Math.PI / 180.0;
        var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2)
            + Math.Cos(lat1 * Math.PI / 180.0) * Math.Cos(lat2 * Math.PI / 180.0)
            * Math.Sin(dLng / 2) * Math.Sin(dLng / 2);
        return earthRadiusM * 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
    }
}
