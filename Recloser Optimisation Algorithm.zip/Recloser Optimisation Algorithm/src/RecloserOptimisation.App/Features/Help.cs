using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    // Registers footer help and delayed hover popups across the app.
    private void RegisterHelpBlurbs()
    {
        RegisterHelp(ProjectButton, "Switch or inspect the current project. Project files are stored under the selected account.");
        RegisterHelp(AccountButton, "Switch account, log out, or create a new account from Settings.");
        RegisterHelp(HeaderProjectCombo, "Quickly change the active project from anywhere in the app.");
        RegisterHelp(HeaderModelCombo, "Quickly change the active model for the current project.");
        RegisterHelp(BuildModelButton, "Build the current model from active processed model inputs in the build menu.");
        RegisterHelp(BuildModelStorageButton, "Build a model from the active build-menu files in the working directory.");
        RegisterHelp(RulesetCombo, "Adapter plans define how selected source files are converted into processed data.");
        RegisterHelp(MapLayerCombo, "Choose whether to use the saved current project map or fetch online tiles.");
        RegisterHelp(MapBaseLayerCombo, "Choose the visual base layer: map, satellite, or topography.");
        RegisterHelp(MapLayersCombo, "Turn detailed model, outage, LINZ and height layers on or off.");
        RegisterHelp(MapModelCombo, "Choose a saved model layer from Project Model Storage to display on the map.");
        RegisterHelp(OptimizationAlgorithmCombo, "Select the algorithm adapter for optimization runs. Reliability assessment disables this because it only scores the selected model.");
        RegisterHelp(OptimizationObjectiveCombo, "Choose SAIDI/SAIFI reduction, protection weighted optimization, or reliability assessment baseline scoring.");
        RegisterHelp(RunSetupModelCombo, "Choose the saved Project Model Storage file used for the run setup.");
        RegisterHelp(VersionHistoryLimitCombo, "Choose how many model versions are kept before the oldest is overwritten.");
        RegisterHelp(ProcessedFilesGrid, "Processed Data Storage contains files created by processing source files. These are eligible for model building.");
        RegisterHelp(ImportsGrid, "Source File Storage contains uploaded files in their original form before processing.");
        RegisterHelp(WorkingDirectoryGrid, "Working Directory shows active project files currently used by the project workflow.");
        RegisterHelp(BuildMenuGrid, "Build Menu lists active processed files that will be used to build the next model.");
        RegisterHelp(ProjectModelStorageGrid, "Project Model Storage contains built model JSON files used by the map, optimization and reports.");
        RegisterHelp(OptimizationAlgorithmsGrid, "Optimization Algorithm Storage shows visible algorithm adapter files and imported algorithm packages.");
        RegisterHelp(FileNameFilterBox, "Search storage by file name, label, status or purpose.");
        RegisterHelp(OptimizationRunPreviewText, "Run preview shows optimized model output or baseline SAIDI/SAIFI values after a reliability assessment.");
        RegisterHelp(MapCoordinateText, "Live mouse-point coordinates shown with zoom, height, address lookup hint and nearest model asset information.");

        RegisterFallbackHelp(DatabaseView, "Database and storage controls manage imported, processed, model and algorithm files.");
        RegisterFallbackHelp(MapView, "Map controls change map layers, model overlays, visible components and display errors.");
        RegisterFallbackHelp(OptimizationView, "Optimization controls prepare algorithm runs, reliability assessments and SAIDI/SAIFI comparisons.");
        RegisterFallbackHelp(ProcessingView, "Processing controls stage source files, run adapters and inspect process status.");
        RegisterFallbackHelp(SettingsView, "Settings controls manage accounts, projects, map defaults and templates.");
        RegisterFallbackHelp(ReportsView, "Reports controls create output summaries and export model results.");
        RegisterFallbackHelp(OutagesView, "Outage controls summarize interruption data used by reliability calculations.");
    }

    // Attaches footer help plus a 3-second delayed tooltip to a control.
    private void RegisterHelp(FrameworkElement element, string text)
    {
        ApplyTooltip(element, text);
        element.MouseEnter += (_, _) => HelpText.Text = text;
        element.MouseLeave += (_, _) => HelpText.Text = "Hover over titles, dropdowns and buttons for help.";
    }

    // Adds generic delayed tooltips to controls that do not already have specific help.
    private void RegisterFallbackHelp(DependencyObject root, string pageHelp)
    {
        foreach (var element in LogicalDescendants(root))
        {
            if (element.ToolTip is not null)
            {
                continue;
            }

            var text = element switch
            {
                Button button => $"{button.Content}: runs this action in the current project workflow.",
                ComboBox => "Dropdown: choose the option used by this workflow step.",
                DataGrid => "Storage table: select a row, edit label/comment cells, or right-click for actions.",
                TabControl => "Tabs: switch between related storage or workflow sections.",
                TabItem tab => $"{tab.Header}: opens this section.",
                TextBox => "Text box: click to type or edit this value.",
                CheckBox check => $"{check.Content}: turn this option on or off.",
                Expander expander => $"{expander.Header}: expand or collapse this detail section.",
                TextBlock block when !string.IsNullOrWhiteSpace(block.Text) && block.FontSize >= 16 => $"{block.Text}: {pageHelp}",
                TextBlock block when block.Text.Contains("SAIDI") || block.Text.Contains("SAIFI") => "SAIDI is average outage minutes per customer per year. SAIFI is average outage interruptions per customer per year.",
                _ => "",
            };

            if (!string.IsNullOrWhiteSpace(text))
            {
                ApplyTooltip(element, text);
            }
        }
    }

    // Enumerates logical children from split UserControls.
    private static IEnumerable<FrameworkElement> LogicalDescendants(DependencyObject root)
    {
        foreach (var child in LogicalTreeHelper.GetChildren(root))
        {
            if (child is FrameworkElement element)
            {
                yield return element;
                foreach (var descendant in LogicalDescendants(element))
                {
                    yield return descendant;
                }
            }
        }
    }

    private static void ApplyTooltip(FrameworkElement element, string text)
    {
        element.ToolTip = text;
        ToolTipService.SetInitialShowDelay(element, 3000);
        ToolTipService.SetShowDuration(element, 12000);
    }
}
