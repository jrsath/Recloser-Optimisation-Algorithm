using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    // Account and project selection. This is the root for per-user project storage.

    // Loads the persisted workspace state and populates the account/project controls.
    private void LoadWorkspace()
    {
        _workspaceState = _workspaceStore.Load();
        RefreshWorkspaceControls();
    }

    // Synchronizes account, project, storage path, and map settings controls with workspace state.
    private void RefreshWorkspaceControls()
    {
        _isUpdatingWorkspaceControls = true;

        AccountCombo.ItemsSource = null;
        AccountCombo.ItemsSource = _workspaceState.Accounts;

        var account = _workspaceStore.CurrentAccount(_workspaceState);
        AccountCombo.SelectedItem = account;

        ProjectCombo.ItemsSource = null;
        ProjectCombo.ItemsSource = account.Projects;

        var project = _workspaceStore.CurrentProject(_workspaceState);
        ProjectCombo.SelectedItem = project;
        RefreshHeaderProjectCombo(account, project);

        ProjectNameText.Text = project.Name;
        AccountNameText.Text = account.DisplayName;
        AccountRoleText.Text = account.Role;
        WorkspaceStorageText.Text = $"Storage: {_workspaceStore.ProjectPath(account, project)}";
        VersionHistoryLimitCombo.SelectedIndex = Math.Clamp(project.Settings.VersionHistoryLimit, 1, 9) - 1;
        SelectComboItem(SettingsMapSourceCombo, project.Settings.DefaultMapSource);
        RefreshMapAreaCombos(account);
        SelectComboItem(SettingsMapAreaCombo, project.Settings.DefaultMapArea);
        ProjectCacheLinzToggle.IsChecked = project.Settings.CacheLayersWhenOnline;
        ProjectUseOfflineFirstToggle.IsChecked = project.Settings.UseOfflineCacheFirst;

        _isUpdatingWorkspaceControls = false;
    }

    // Builds the header project dropdown with feeder-study creation as the final action row.
    private void RefreshHeaderProjectCombo(UserAccount account, ProjectRecord selectedProject)
    {
        HeaderProjectCombo.Items.Clear();
        ComboBoxItem? selectedItem = null;
        foreach (var project in account.Projects)
        {
            var item = new ComboBoxItem
            {
                Content = project.Name,
                Tag = project,
            };
            HeaderProjectCombo.Items.Add(item);
            if (project.Id.Equals(selectedProject.Id, StringComparison.OrdinalIgnoreCase))
            {
                selectedItem = item;
            }
        }

        HeaderProjectCombo.Items.Add(new ComboBoxItem { Content = "----------------", IsEnabled = false });
        HeaderProjectCombo.Items.Add(new ComboBoxItem { Content = "New feeder study...", Tag = "new-feeder-study" });
        HeaderProjectCombo.SelectedItem = selectedItem;
    }

    // Handles either selecting an existing project or choosing the dropdown's new-feeder-study action.
    private void ChangeHeaderProjectSelection()
    {
        if (_isUpdatingWorkspaceControls)
        {
            return;
        }

        if (HeaderProjectCombo.SelectedItem is not ComboBoxItem item)
        {
            return;
        }

        switch (item.Tag)
        {
            case ProjectRecord project:
                ChangeProject(project);
                break;
            case string action when action.Equals("new-feeder-study", StringComparison.OrdinalIgnoreCase):
                CreateFeederStudyFromPrompt();
                break;
        }
    }

    // Keeps map centering dropdowns to NZ, King Country, and current account feeder studies.
    private void RefreshMapAreaCombos(UserAccount account)
    {
        RefreshAreaCombo(SettingsMapAreaCombo, account);
        RefreshAreaCombo(MapSchematicAreaCombo, account);
    }

    private static void RefreshAreaCombo(ComboBox combo, UserAccount account)
    {
        var selected = combo.Text;
        combo.Items.Clear();
        combo.Items.Add(new ComboBoxItem { Content = "New Zealand overview" });
        combo.Items.Add(new ComboBoxItem { Content = "King Country study area" });
        foreach (var project in account.Projects.Where(project => !project.Name.Equals("King Country feeder study", StringComparison.OrdinalIgnoreCase)))
        {
            combo.Items.Add(new ComboBoxItem { Content = project.Name });
        }

        SelectComboItem(combo, string.IsNullOrWhiteSpace(selected) ? "New Zealand overview" : selected);
    }

    // Switches to another account and reloads its first available project.
    private void ChangeAccount(UserAccount? account)
    {
        if (_isUpdatingWorkspaceControls || account is null)
        {
            return;
        }

        if (account.Id.Equals("admin", StringComparison.OrdinalIgnoreCase) && !PromptForAccountPassword(account))
        {
            RefreshWorkspaceControls();
            SetStatus("Admin sign-in cancelled");
            return;
        }

        _workspaceState.CurrentAccountId = account.Id;
        _workspaceState.CurrentProjectId = account.Projects.First().Id;
        _workspaceStore.Save(_workspaceState);
        RefreshWorkspaceControls();
        ReloadProjectStorage();
        SetStatus($"Account selected: {account.DisplayName}");
    }

    // Switches the active project and reloads all project-scoped storage.
    private void ChangeProject(ProjectRecord? project)
    {
        if (_isUpdatingWorkspaceControls || project is null)
        {
            return;
        }

        _workspaceState.CurrentProjectId = project.Id;
        project.UpdatedAt = DateTime.UtcNow;
        _workspaceStore.Save(_workspaceState);
        RefreshWorkspaceControls();
        ReloadProjectStorage();
        SetStatus($"Project selected: {project.Name}");
    }

    // Creates a new workspace account from the settings-page account name field.
    private void CreateAccount()
    {
        var name = NewAccountNameBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(name))
        {
            SetStatus("Enter an account name first");
            return;
        }

        var account = _workspaceStore.AddAccount(_workspaceState, name);
        NewAccountNameBox.Text = "";
        RefreshWorkspaceControls();
        SetStatus($"Created account: {account.DisplayName}");
    }

    // Creates a new project under the current account from the settings-page project name field.
    private void CreateProject()
    {
        var name = NewProjectNameBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(name))
        {
            SetStatus("Enter a project name first");
            return;
        }

        var account = _workspaceStore.CurrentAccount(_workspaceState);
        var project = _workspaceStore.AddProject(_workspaceState, account, name);
        project.Settings.DefaultMapArea = project.Name;
        project.Settings.UseOfflineCacheFirst = true;
        project.Settings.CacheLayersWhenOnline = true;
        _workspaceStore.Save(_workspaceState);
        NewProjectNameBox.Text = "";
        RefreshWorkspaceControls();
        SetStatus($"Created project: {project.Name}");
    }

    // Creates a new feeder study after prompting for the study name.
    private void CreateFeederStudyFromPrompt()
    {
        var name = PromptForText("New feeder study", "Study name", $"Feeder study {DateTime.Now:yyyy-MM-dd HHmm}");
        if (string.IsNullOrWhiteSpace(name))
        {
            return;
        }

        var account = _workspaceStore.CurrentAccount(_workspaceState);
        var project = _workspaceStore.AddProject(_workspaceState, account, name);
        project.Settings.DefaultMapArea = project.Name;
        project.Settings.UseOfflineCacheFirst = true;
        project.Settings.CacheLayersWhenOnline = true;
        _workspaceStore.Save(_workspaceState);
        RefreshWorkspaceControls();
        ReloadProjectStorage();
        SelectComboItem(MapSchematicAreaCombo, project.Name);
        SetStatus($"Created feeder study: {project.Name}");
    }

    // Prompts for the account password; empty admin password currently accepts a blank entry.
    private bool PromptForAccountPassword(UserAccount account)
    {
        var dialog = new Window
        {
            Owner = this,
            Title = $"Sign in to {account.DisplayName}",
            Width = 380,
            Height = 170,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
        };
        var password = new PasswordBox { Height = 30, Margin = new Thickness(0, 6, 0, 12) };
        var ok = new Button { Content = "Sign in", Width = 90, HorizontalAlignment = HorizontalAlignment.Right };
        ok.Click += (_, _) => dialog.DialogResult = true;
        var panel = new StackPanel { Margin = new Thickness(16) };
        panel.Children.Add(new TextBlock { Text = "Password" });
        panel.Children.Add(password);
        panel.Children.Add(ok);
        dialog.Content = panel;
        return dialog.ShowDialog() == true && password.Password == account.Password;
    }

    // Changes the password for the currently selected account.
    private void ChangeCurrentAccountPassword()
    {
        var account = _workspaceStore.CurrentAccount(_workspaceState);
        var newPassword = PromptForPassword("Change password", "New password");
        if (newPassword is null)
        {
            return;
        }

        account.Password = newPassword;
        _workspaceStore.Save(_workspaceState);
        SetStatus($"Password updated for {account.DisplayName}");
    }

    private string? PromptForPassword(string title, string label)
    {
        var dialog = new Window
        {
            Owner = this,
            Title = title,
            Width = 380,
            Height = 170,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
        };
        var password = new PasswordBox { Height = 30, Margin = new Thickness(0, 6, 0, 12) };
        var ok = new Button { Content = "Save", Width = 90, HorizontalAlignment = HorizontalAlignment.Right };
        ok.Click += (_, _) => dialog.DialogResult = true;
        var panel = new StackPanel { Margin = new Thickness(16) };
        panel.Children.Add(new TextBlock { Text = label });
        panel.Children.Add(password);
        panel.Children.Add(ok);
        dialog.Content = panel;
        return dialog.ShowDialog() == true ? password.Password : null;
    }

    // Saves the selected built-model version history limit to the active project settings.
    private void ChangeVersionHistoryLimit()
    {
        if (_isUpdatingWorkspaceControls || VersionHistoryLimitCombo.SelectedItem is not ComboBoxItem item)
        {
            return;
        }

        if (int.TryParse(item.Content?.ToString(), out var limit))
        {
            var project = _workspaceStore.CurrentProject(_workspaceState);
            project.Settings.VersionHistoryLimit = Math.Clamp(limit, 1, 9);
            project.UpdatedAt = DateTime.UtcNow;
            _workspaceStore.Save(_workspaceState);
            SetStatus($"Version history limit set to {project.Settings.VersionHistoryLimit}");
        }
    }

    // Saves map source and area defaults, then applies them to the current map controls.
    private void ApplySettingsMapDefaults()
    {
        if (_isUpdatingWorkspaceControls)
        {
            return;
        }

        var source = SelectedComboText(SettingsMapSourceCombo);
        var area = SelectedComboText(SettingsMapAreaCombo);
        var project = _workspaceStore.CurrentProject(_workspaceState);
        project.Settings.DefaultMapSource = source;
        project.Settings.DefaultMapArea = area;
        project.UpdatedAt = DateTime.UtcNow;
        _workspaceStore.Save(_workspaceState);
        SelectComboItem(MapLayerCombo, source);
        SelectComboItem(MapSchematicAreaCombo, area);
        SetStatus($"Project map defaults selected: {source}, {area}");
    }

    // Persists the current project cache and offline-first map settings.
    private void SaveCurrentProjectSettings()
    {
        if (_isUpdatingWorkspaceControls)
        {
            return;
        }

        var project = _workspaceStore.CurrentProject(_workspaceState);
        project.Settings.CacheLayersWhenOnline = ProjectCacheLinzToggle.IsChecked == true;
        project.Settings.UseOfflineCacheFirst = ProjectUseOfflineFirstToggle.IsChecked == true;
        project.UpdatedAt = DateTime.UtcNow;
        _workspaceStore.Save(_workspaceState);
        SetStatus("Current project settings saved");
    }

    // Selects a combo-box item by text after normalizing legacy map source names.
    private static void SelectComboItem(ComboBox comboBox, string content)
    {
        content = NormalizeMapSource(content);
        foreach (var item in comboBox.Items.OfType<ComboBoxItem>())
        {
            if (string.Equals(item.Content?.ToString(), content, StringComparison.OrdinalIgnoreCase))
            {
                comboBox.SelectedItem = item;
                return;
            }
        }
    }

    // Maps older stored map mode labels onto the current map source dropdown labels.
    private static string NormalizeMapSource(string content)
    {
        return content switch
        {
            "Offline mode" => "Current project map",
            "Online map mode" => "Online mode",
            "Online satellite mode" => "Online mode",
            "Online topographic mode" => "Online mode",
            "Map mode" => "Online mode",
            "Satellite mode" => "Online mode",
            _ => content,
        };
    }

    // Returns the user to settings while full authentication is still a placeholder.
    private void Logout()
    {
        SetStatus("Logged out placeholder: choose another account to continue");
        ShowPage("Settings");
    }

    // Opens the account dropdown so the user can quickly change accounts.
    private void ShowAccountSwitch()
    {
        AccountCombo.IsDropDownOpen = true;
        SetStatus("Choose an account from the account dropdown");
    }

    // Creates a working copy of the active model so developer edits do not overwrite the original immediately.
    private void EnableDeveloperModelCopy()
    {
        EditTemplateButton.IsEnabled = true;
        var project = _workspaceStore.CurrentProject(_workspaceState);
        var activeModelId = project.Settings.ActiveModelId;
        if (string.IsNullOrWhiteSpace(activeModelId))
        {
            UpdateDeveloperMapModeVisibility();
            SetStatus("Developer mode enabled; no active model exists to copy yet");
            return;
        }

        var modelsPath = _workspaceStore.BuiltModelsPath(_workspaceState);
        var sourcePath = System.IO.Path.Combine(modelsPath, $"{activeModelId}.json");
        if (!System.IO.File.Exists(sourcePath))
        {
            UpdateDeveloperMapModeVisibility();
            SetStatus("Developer mode enabled; active model file was not found to copy");
            return;
        }

        _developerOriginalModelId = activeModelId;
        _developerCopyModelId = $"dev-copy-{System.DateTime.UtcNow:yyyyMMdd-HHmmss}";
        var copyPath = System.IO.Path.Combine(modelsPath, $"{_developerCopyModelId}.json");
        System.IO.File.Copy(sourcePath, copyPath, overwrite: true);

        project.Settings.ActiveModelId = _developerCopyModelId;
        project.UpdatedAt = System.DateTime.UtcNow;
        _workspaceStore.Save(_workspaceState);
        UpdateDeveloperMapModeVisibility();
        SetStatus($"Developer mode copied model {_developerOriginalModelId} to {_developerCopyModelId}");
    }

    // Prompts whether to save or keep the developer model copy when leaving developer mode.
    private void DisableDeveloperModelCopy()
    {
        EditTemplateButton.IsEnabled = false;
        if (string.IsNullOrWhiteSpace(_developerOriginalModelId) || string.IsNullOrWhiteSpace(_developerCopyModelId))
        {
            UpdateDeveloperMapModeVisibility();
            SetStatus("Developer mode disabled");
            return;
        }

        var choice = MessageBox.Show(
            this,
            "Save the developer copy over the original model? Choose No to keep the copy as a new model.",
            "Developer Model Copy",
            MessageBoxButton.YesNoCancel,
            MessageBoxImage.Question);

        if (choice == MessageBoxResult.Cancel)
        {
            DeveloperModeToggle.IsChecked = true;
            return;
        }

        var project = _workspaceStore.CurrentProject(_workspaceState);
        var modelsPath = _workspaceStore.BuiltModelsPath(_workspaceState);
        var copyPath = System.IO.Path.Combine(modelsPath, $"{_developerCopyModelId}.json");

        if (choice == MessageBoxResult.Yes)
        {
            var originalPath = System.IO.Path.Combine(modelsPath, $"{_developerOriginalModelId}.json");
            if (System.IO.File.Exists(copyPath))
            {
                System.IO.File.Copy(copyPath, originalPath, overwrite: true);
            }

            project.Settings.ActiveModelId = _developerOriginalModelId;
            SetStatus("Developer copy saved over the original model");
        }
        else
        {
            project.Settings.ActiveModelId = _developerCopyModelId;
            SetStatus("Developer copy kept as a new active model");
        }

        project.UpdatedAt = System.DateTime.UtcNow;
        _workspaceStore.Save(_workspaceState);
        _developerOriginalModelId = "";
        _developerCopyModelId = "";
        UpdateDeveloperMapModeVisibility();
    }
}
