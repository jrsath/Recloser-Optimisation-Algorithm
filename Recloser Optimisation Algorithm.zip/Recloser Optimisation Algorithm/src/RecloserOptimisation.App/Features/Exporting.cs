using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Exports manifests, source templates, and placeholder map overlays.

    // Exports the current project manifest, current project storage, and saved reports as a zip package.
    private void ExportManifest()
    {
        RefreshWorkingDirectoryStorage();
        var project = _workspaceStore.CurrentProject(_workspaceState);
        var manifest = new
        {
            project = "ROA",
            projectId = project.Id,
            projectName = project.Name,
            generatedAt = DateTimeOffset.UtcNow,
            scope = new
            {
                currentProjectStorage = "active build inputs, outage data, and active model files",
                savedReports = "generated SLDs, model exports, optimization outputs, reliability outputs, and error reports",
                map = "current project map with selectable saved model layers",
            },
            imports = _imports.ToArray(),
            currentProjectStorage = _workingDirectoryFiles.ToArray(),
            savedReports = _reports.ToArray(),
            models = _builtModels.ToArray(),
            map = new
            {
                centerLat = _centerLat,
                centerLng = _centerLng,
                zoom = _zoom,
                layer = _activeLayer,
                mapMode = SelectedComboText(MapModeCombo),
                model = SelectedComboText(MapModelCombo),
            },
        };

        var dialog = new SaveFileDialog
        {
            Title = "Export current project package",
            FileName = $"{SafeFileStem(project.Name)}-manifest.zip",
            Filter = "ZIP packages|*.zip|All files|*.*",
        };

        if (dialog.ShowDialog(this) != true)
        {
            return;
        }

        using var archive = ZipFile.Open(dialog.FileName, ZipArchiveMode.Create);
        var usedNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        AddTextToZip(archive, usedNames, "manifest.json", JsonSerializer.Serialize(manifest, _jsonOptions));

        foreach (var file in _workingDirectoryFiles)
        {
            AddFileToZip(archive, usedNames, ResolvePreviewPath(file.Path), "current-project-storage");
        }

        foreach (var report in _reports)
        {
            AddFileToZip(archive, usedNames, ResolvePreviewPath(report.Path), "saved-reports");
        }

        SetStatus($"Exported current project package: {Path.GetFileName(dialog.FileName)}");
    }

    // Exports the CSV source-import template used to shape incoming datasets.
    private void ExportTemplate()
    {
        var lines = new[]
        {
            "source_group,platform,file_name,asset_id,parent_id,asset_type,feeder_id,latitude,longitude,voltage_kv,customers,notes",
            "GIS / mapping,Esri ArcGIS,,,,line_section,,,,,,",
            "Electrical model,OpenDSS,,,,node,,,,,,",
            "PowerFactory files,DIgSILENT PowerFactory,,,,switch,,,,,,",
            "Protection settings,SEL / protection export,,,,recloser,,,,,,",
            "OMS / outage history,OMS,,,,outage_event,,,,,,",
        };

        SaveTextFile("Export import template", "recloser-import-template.csv", "CSV files|*.csv|All files|*.*", string.Join(Environment.NewLine, lines));
    }

    // Exports an empty GeoJSON feature collection as a starter feeder overlay.
    private void ExportGeoJson()
    {
        var geoJson = new
        {
            type = "FeatureCollection",
            name = "empty-feeder-overlay",
            features = Array.Empty<object>(),
        };

        SaveTextFile("Export empty feeder overlay", "empty-feeder-overlay.geojson", "GeoJSON files|*.geojson|JSON files|*.json|All files|*.*", JsonSerializer.Serialize(geoJson, _jsonOptions));
    }

    // Prompts for a save location and writes generated text content to disk.
    private void SaveTextFile(string title, string defaultFileName, string filter, string content)
    {
        var dialog = new SaveFileDialog
        {
            Title = title,
            FileName = defaultFileName,
            Filter = filter,
        };

        if (dialog.ShowDialog(this) == true)
        {
            File.WriteAllText(dialog.FileName, content);
            SetStatus($"Exported {Path.GetFileName(dialog.FileName)}");
        }
    }

    private static void AddTextToZip(ZipArchive archive, HashSet<string> usedNames, string entryName, string content)
    {
        var finalName = UniqueZipEntryName(usedNames, entryName);
        var entry = archive.CreateEntry(finalName);
        using var writer = new StreamWriter(entry.Open());
        writer.Write(content);
    }

    private static void AddFileToZip(ZipArchive archive, HashSet<string> usedNames, string path, string folder)
    {
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
        {
            return;
        }

        var entryName = UniqueZipEntryName(usedNames, $"{folder}/{Path.GetFileName(path)}");
        archive.CreateEntryFromFile(path, entryName, CompressionLevel.Optimal);
    }

    private static string UniqueZipEntryName(HashSet<string> usedNames, string entryName)
    {
        var cleanName = entryName.Replace('\\', '/');
        if (usedNames.Add(cleanName))
        {
            return cleanName;
        }

        var folder = Path.GetDirectoryName(cleanName)?.Replace('\\', '/');
        var stem = Path.GetFileNameWithoutExtension(cleanName);
        var extension = Path.GetExtension(cleanName);
        var index = 2;
        while (true)
        {
            var candidateFile = $"{stem}-{index}{extension}";
            var candidate = string.IsNullOrWhiteSpace(folder) ? candidateFile : $"{folder}/{candidateFile}";
            if (usedNames.Add(candidate))
            {
                return candidate;
            }

            index++;
        }
    }
}

