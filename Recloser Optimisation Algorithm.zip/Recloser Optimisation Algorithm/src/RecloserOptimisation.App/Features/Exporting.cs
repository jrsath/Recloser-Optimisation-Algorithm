using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Exports manifests, source templates, and placeholder map overlays.

    // Exports the current prototype project state as a JSON manifest.
    private void ExportManifest()
    {
        var manifest = new
        {
            project = "ROA",
            generatedAt = DateTimeOffset.UtcNow,
            scope = new
            {
                ingestion = "metadata staging only",
                processing = "prototype data-backed queue",
                validation = "example checks from processed data",
                optimisation = "hub placeholder with ablation controls",
                map = "offline schematic with optional online tile layers",
            },
            imports = _imports.ToArray(),
            adapters = _adapters.ToArray(),
            model = new
            {
                nodes = Array.Empty<object>(),
                lineSegments = Array.Empty<object>(),
                protectionDevices = Array.Empty<object>(),
                customerGroups = Array.Empty<object>(),
                outageEvents = Array.Empty<object>(),
                validationIssues = Array.Empty<object>(),
            },
            map = new
            {
                centerLat = _centerLat,
                centerLng = _centerLng,
                zoom = _zoom,
                layer = _activeLayer,
                mapMode = SelectedComboText(MapModeCombo),
                model = SelectedComboText(MapModelCombo),
            },
        };

        SaveTextFile("Export project state", "recloser-optimisation-manifest.json", "JSON files|*.json|All files|*.*", JsonSerializer.Serialize(manifest, _jsonOptions));
    }

    // Exports the CSV source-import template used to shape incoming datasets.
    private void ExportTemplate()
    {
        var lines = new[]
        {
            "source_group,platform,file_name,asset_id,parent_id,asset_type,feeder_id,latitude,longitude,voltage_kv,customers,notes",
            "GIS / mapping,Esri ArcGIS,,,,line_section,,,,,,",
            "Electrical model,OpenDSS,,,,node,,,,,,",
            "PowerFactory files,DIgSILENT PowerFactory,,,,switch,,,,,,",
            "Protection settings,SEL / protection export,,,,recloser,,,,,,",
            "OMS / outage history,OMS,,,,outage_event,,,,,,",
        };

        SaveTextFile("Export import template", "recloser-import-template.csv", "CSV files|*.csv|All files|*.*", string.Join(Environment.NewLine, lines));
    }

    // Exports an empty GeoJSON feature collection as a starter feeder overlay.
    private void ExportGeoJson()
    {
        var geoJson = new
        {
            type = "FeatureCollection",
            name = "empty-feeder-overlay",
            features = Array.Empty<object>(),
        };

        SaveTextFile("Export empty feeder overlay", "empty-feeder-overlay.geojson", "GeoJSON files|*.geojson|JSON files|*.json|All files|*.*", JsonSerializer.Serialize(geoJson, _jsonOptions));
    }

    // Prompts for a save location and writes generated text content to disk.
    private void SaveTextFile(string title, string defaultFileName, string filter, string content)
    {
        var dialog = new SaveFileDialog
        {
            Title = title,
            FileName = defaultFileName,
            Filter = filter,
        };

        if (dialog.ShowDialog(this) == true)
        {
            File.WriteAllText(dialog.FileName, content);
            SetStatus($"Exported {Path.GetFileName(dialog.FileName)}");
        }
    }
}

