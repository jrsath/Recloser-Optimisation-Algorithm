using System;
using System.Collections.Generic;
using System.Linq;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    private static IEnumerable<OptimizationRecommendationRecord> RunLinearProgrammingPlacement(
        CartesianMapRecord map,
        ReliabilityMetricsRecord baseline)
    {
        return BuildPlacementCandidates(map)
            .OrderByDescending(candidate =>
                candidate.ExpectedSaidiReduction * 100.0 +
                candidate.ExpectedSaifiReduction * 1000.0 +
                candidate.ProtectedCustomers * 2.0 +
                candidate.ProtectedKva * 0.05 +
                candidate.ExposureKm * 25.0)
            .Take(5)
            .Select(candidate => PlacementCandidateToRecommendation(candidate, "LP-RC"));
    }

    private static IEnumerable<OptimizationRecommendationRecord> RunLexicographicPlacement(
        CartesianMapRecord map,
        ReliabilityMetricsRecord baseline)
    {
        return BuildPlacementCandidates(map)
            .Where(candidate => !candidate.HasVehicleAccess.HasValue || candidate.HasVehicleAccess.Value)
            .OrderByDescending(candidate => candidate.ExpectedSaidiReduction)
            .ThenByDescending(candidate => candidate.ExpectedSaifiReduction)
            .ThenByDescending(candidate => candidate.ProtectedCustomers)
            .ThenBy(candidate => candidate.DeviceCost)
            .Take(5)
            .Select(candidate => PlacementCandidateToRecommendation(candidate, "LEX-RC"));
    }

    private static IEnumerable<OptimizationRecommendationRecord> RunRandomTreePlacement(
        CartesianMapRecord map,
        ReliabilityMetricsRecord baseline,
        int seed = 42)
    {
        const int maxDevices = 5;
        const int iterations = 10000;

        var random = new Random(seed);
        var candidates = BuildPlacementCandidates(map).ToList();
        var bestScore = double.MinValue;
        var bestPlacement = new List<PlacementCandidate>();

        for (var iteration = 0; iteration < iterations && candidates.Count > 0; iteration++)
        {
            var selected = candidates
                .OrderBy(_ => random.NextDouble())
                .Take(random.Next(1, Math.Min(maxDevices, candidates.Count) + 1))
                .ToList();

            if (selected.Any(candidate => candidate.HasVehicleAccess.HasValue && !candidate.HasVehicleAccess.Value))
            {
                continue;
            }

            var solutionScore = selected.Sum(candidate =>
                candidate.ExpectedSaidiReduction * 100.0 +
                candidate.ExpectedSaifiReduction * 1000.0 +
                candidate.ProtectedCustomers * 2.0 +
                candidate.ProtectedKva * 0.05 -
                candidate.DeviceCost * 0.00001);

            if (solutionScore > bestScore)
            {
                bestScore = solutionScore;
                bestPlacement = selected;
            }
        }

        return bestPlacement.Select(candidate => PlacementCandidateToRecommendation(candidate, "TREE-RC"));
    }

    private static OptimizationRecommendationRecord PlacementCandidateToRecommendation(
        PlacementCandidate candidate,
        string prefix)
    {
        return new OptimizationRecommendationRecord
        {
            Id = $"{prefix}-{candidate.NodeId}",
            Action = "Insert recloser",
            NodeId = candidate.NodeId,
            Score = Math.Round(
                candidate.ExpectedSaidiReduction * 100.0 +
                candidate.ExpectedSaifiReduction * 1000.0 +
                candidate.ProtectedCustomers * 2.0 +
                candidate.ProtectedKva * 0.05 +
                candidate.ExposureKm * 25.0,
                2),
            ProtectedCustomers = candidate.ProtectedCustomers,
            ExpectedSaidiReduction = Math.Round(candidate.ExpectedSaidiReduction, 2),
            ExpectedSaifiReduction = Math.Round(candidate.ExpectedSaifiReduction, 4),
        };
    }
}
