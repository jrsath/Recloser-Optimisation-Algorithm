using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Controls;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    // Populates the optimization algorithm grid with runnable default algorithms and import slots.
    private void LoadOptimizationAlgorithms()
    {
        _optimizationAlgorithms.Clear();

        AddOptimizationAlgorithm("Linear programming", "Editable LP source", "Ready", ResolveAlgorithmFilePath("linear-programming.roa_algorithm.csx"));
        AddOptimizationAlgorithm("Lexicographic linear optimization", "Editable lexicographic source", "Ready", ResolveAlgorithmFilePath("lexicographic-linear-optimization.roa_algorithm.csx"));
        AddOptimizationAlgorithm("Random tree optimisation", "Editable random tree source", "Ready", ResolveAlgorithmFilePath("random-tree-optimisation.roa_algorithm.csx"));
        AddOptimizationAlgorithm("Custom imported algorithm", "Import placeholder", "Waiting for import", "");
    }

    private static string ResolveAlgorithmFilePath(string fileName)
    {
        var outputPath = Path.Combine(AppContext.BaseDirectory, "Features", "OptimizationAlgorithms", "AlgorithmFiles", fileName);
        if (File.Exists(outputPath))
        {
            return outputPath;
        }

        return Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "Features", "OptimizationAlgorithms", "AlgorithmFiles", fileName));
    }

    // Adds or updates an algorithm record so imported packages replace earlier entries cleanly.
    private void AddOptimizationAlgorithm(string name, string type, string status, string path)
    {
        var existing = _optimizationAlgorithms.FirstOrDefault(current => string.Equals(current.Name, name, StringComparison.OrdinalIgnoreCase));
        if (existing is not null)
        {
            existing.Type = type;
            existing.Status = status;
            existing.Path = path;
            OptimizationAlgorithmsGrid.Items.Refresh();
            return;
        }

        _optimizationAlgorithms.Add(new OptimizationAlgorithmRecord
        {
            Name = name,
            Type = type,
            Status = status,
            Path = path,
        });
    }

    // Imports an optimization algorithm package and adds it to the selectable algorithm list.
    private void ImportOptimizationAlgorithm()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Import optimization algorithm",
            Filter = "Algorithm packages|*.csx;*.json;*.dll;*.py;*.zip|All files|*.*",
        };

        if (dialog.ShowDialog(this) == true)
        {
            var item = new ComboBoxItem
            {
                Content = Path.GetFileNameWithoutExtension(dialog.FileName),
                Tag = dialog.FileName,
            };
            OptimizationAlgorithmCombo.Items.Add(item);
            OptimizationAlgorithmCombo.SelectedItem = item;
            AddOptimizationAlgorithm(item.Content?.ToString() ?? Path.GetFileNameWithoutExtension(dialog.FileName), "Imported adapter", "Ready", dialog.FileName);
            SetStatus($"Optimization algorithm imported: {Path.GetFileName(dialog.FileName)}");
        }
    }

    // Exports the current project's saved optimization run log.
    private void ExportOptimizationLogs()
    {
        var logPath = OptimizationRunLogPath();
        EnsureOptimizationRunLogExists(logPath);
        SaveTextFile("Export optimization logs", "optimization-run-logs.csv", "CSV files|*.csv|All files|*.*", File.ReadAllText(logPath));
    }

    private void ApplyOptimizationObjectiveMode()
    {
        var reliabilityOnly = SelectedComboText(OptimizationObjectiveCombo).Equals("Reliability assessment", StringComparison.OrdinalIgnoreCase);
        OptimizationAlgorithmCombo.IsEnabled = !reliabilityOnly;
        OptimizationRunPreviewTitle.Text = reliabilityOnly ? "Reliability assessment preview" : "Optimization preview";
        OptimizationRunPreviewText.Text = reliabilityOnly
            ? "Reliability assessment calculates baseline SAIDI, SAIFI and CAIDI for the selected model without creating an optimized model."
            : "Optimization will create an improved model file and display it on the map when the run completes.";
    }

    // Runs the selected optimization algorithm against the selected model or performs a baseline reliability assessment.
    private void PrepareOptimizationRunSetup()
    {
        var sourceModel = LoadRunSetupBuiltModel();
        if (sourceModel is null)
        {
            SetStatus("Select a saved project model before preparing a run");
            return;
        }

        var objective = SelectedComboText(OptimizationObjectiveCombo);
        if (objective.Equals("Reliability assessment", StringComparison.OrdinalIgnoreCase))
        {
            RunReliabilityAssessment(sourceModel);
            return;
        }

        var algorithm = SelectedComboText(OptimizationAlgorithmCombo);
        if (string.IsNullOrWhiteSpace(algorithm) || algorithm.Contains("Custom imported", StringComparison.OrdinalIgnoreCase))
        {
            algorithm = "Random tree optimisation";
        }

        var algorithmPath = OptimizationAlgorithmCombo.SelectedItem is ComboBoxItem item
            ? item.Tag?.ToString() ?? ""
            : "";
        var algorithmRecord = _optimizationAlgorithms.FirstOrDefault(current => string.Equals(current.Name, algorithm, StringComparison.OrdinalIgnoreCase));
        if (string.IsNullOrWhiteSpace(algorithmPath))
        {
            algorithmPath = algorithmRecord?.Path ?? "";
        }
        var runId = $"opt-{DateTime.UtcNow:yyyyMMdd-HHmmss}";
        var modelName = PromptForText("Name optimized model", "Optimized model name", $"Optimized model {DateTime.Now:yyyy-MM-dd HH:mm}");
        var optimizedModel = RunReliabilityOptimization(sourceModel, algorithm, algorithmPath, runId);
        if (!string.IsNullOrWhiteSpace(modelName))
        {
            optimizedModel.Name = modelName;
        }

        SaveBuiltModel(optimizedModel);
        WriteOptimizationRunLog(sourceModel, optimizedModel);
        LoadOptimizationRunLogs();
        if (algorithmRecord is not null)
        {
            algorithmRecord.Status = "Last run complete";
            OptimizationAlgorithmsGrid.Items.Refresh();
        }

        _reports.Add(new ReportRow
        {
            Report = $"Optimization run {runId}",
            Category = "SAIDI / SAIFI comparison",
            Status = "Complete",
            Label = "Optimization output",
            Uploaded = DateTime.Now.ToString("yyyy-MM-dd HH:mm"),
            Path = Path.Combine(_workspaceStore.ProjectFolder(_workspaceState, "reports"), "optimization-runs.csv"),
        });

        LoadBuiltModelStorage();
        SelectComboContent(MapModelCombo, $"{optimizedModel.Id} model layer");
        SelectComboContent(HeaderModelCombo, optimizedModel.Id);
        CenterMapOnCartesianMap(optimizedModel.CartesianMap);
        MapInfoText.Text = $"Optimization complete. SAIDI {optimizedModel.Optimization.Baseline.Saidi:N2} -> {optimizedModel.Optimization.Improved.Saidi:N2}; SAIFI {optimizedModel.Optimization.Baseline.Saifi:N3} -> {optimizedModel.Optimization.Improved.Saifi:N3}.";
        OptimizationRunPreviewTitle.Text = "Optimized model preview";
        OptimizationRunPreviewText.Text = $"{optimizedModel.Id}: SAIDI {optimizedModel.Optimization.Baseline.Saidi:N2} -> {optimizedModel.Optimization.Improved.Saidi:N2}; SAIFI {optimizedModel.Optimization.Baseline.Saifi:N3} -> {optimizedModel.Optimization.Improved.Saifi:N3}.";
        RenderMap();
        RefreshDashboard();
        SetStatus($"Optimization complete: {optimizedModel.Optimization.Recommendations.Count} placements, SAIDI improvement {optimizedModel.Optimization.SaidiImprovement:N2}");
    }

    private void RunReliabilityAssessment(BuiltModelRecord sourceModel)
    {
        var baseline = sourceModel.BaselineReliability.Saidi > 0
            ? sourceModel.BaselineReliability
            : CalculateReliability(sourceModel.CartesianMap, proposedReclosers: 0);
        var runId = $"rel-{DateTime.UtcNow:yyyyMMdd-HHmmss}";

        _reports.Add(new ReportRow
        {
            Report = $"Reliability assessment {runId}",
            Category = "SAIDI / SAIFI comparison",
            Status = "Complete",
            Label = "Reliability baseline",
            Uploaded = DateTime.Now.ToString("yyyy-MM-dd HH:mm"),
            Path = Path.Combine(_workspaceStore.ProjectFolder(_workspaceState, "reports"), "optimization-runs.csv"),
        });

        WriteReliabilityAssessmentLog(sourceModel, baseline, runId);
        LoadOptimizationRunLogs();
        OptimizationRunPreviewTitle.Text = "Baseline reliability";
        OptimizationRunPreviewText.Text = $"{sourceModel.Id}: SAIDI {baseline.Saidi:N2} minutes/customer/year, SAIFI {baseline.Saifi:N3} interruptions/customer/year, CAIDI {baseline.Caidi:N2} minutes/interruption.";
        MapInfoText.Text = $"Reliability assessment complete for {sourceModel.Id}. SAIDI {baseline.Saidi:N2}, SAIFI {baseline.Saifi:N3}, CAIDI {baseline.Caidi:N2}.";
        CenterMapOnCartesianMap(sourceModel.CartesianMap);
        RenderMap();
        DashboardReliabilityText.Text = $"Reliability: SAIDI {baseline.Saidi:N2} min/customer/year, SAIFI {baseline.Saifi:N3} interruptions/customer/year, CAIDI {baseline.Caidi:N2} min/interruption.";
        SetStatus($"Reliability assessment complete: SAIDI {baseline.Saidi:N2}, SAIFI {baseline.Saifi:N3}");
    }

    // Loads saved optimization run rows for the current project into logs and comparison grids.
    private void LoadOptimizationRunLogs()
    {
        _optimizationRunLogs.Clear();
        var logPath = OptimizationRunLogPath();
        if (!File.Exists(logPath))
        {
            return;
        }

        foreach (var line in File.ReadLines(logPath).Skip(1))
        {
            var parts = SplitCsvLine(line).ToArray();
            if (parts.Length < 14)
            {
                continue;
            }

            _optimizationRunLogs.Add(new OptimizationRunLogRecord
            {
                RunId = parts[0],
                Algorithm = parts[1],
                SourceModelId = parts[3],
                OutputModelId = parts[4],
                BaselineSaidi = ParseDouble(parts[5]),
                BaselineSaifi = ParseDouble(parts[6]),
                ImprovedSaidi = ParseDouble(parts[7]),
                ImprovedSaifi = ParseDouble(parts[8]),
                SaidiImprovement = ParseDouble(parts[9]),
                SaifiImprovement = ParseDouble(parts[10]),
                Recommendations = int.TryParse(parts[11], out var recommendations) ? recommendations : 0,
                Status = parts[12],
                RunAt = parts[13],
            });
        }
    }

    // Loads the built model selected in run setup, falling back to the active project model.
    private BuiltModelRecord? LoadRunSetupBuiltModel()
    {
        var path = RunSetupModelCombo.SelectedItem is ComboBoxItem selectedItem
            ? selectedItem.Tag?.ToString() ?? ""
            : "";
        if (string.IsNullOrWhiteSpace(path))
        {
            var project = _workspaceStore.CurrentProject(_workspaceState);
            if (!string.IsNullOrWhiteSpace(project.Settings.ActiveModelId))
            {
                path = Path.Combine(_workspaceStore.BuiltModelsPath(_workspaceState), $"{project.Settings.ActiveModelId}.json");
            }
        }

        if (!File.Exists(path))
        {
            return null;
        }

        return TryLoadBuiltModelForCurrentProject(path, out var model) ? model : null;
    }

    // Runs the built-in deterministic reliability optimizer and returns an improved model copy.
   private BuiltModelRecord RunReliabilityOptimization(BuiltModelRecord sourceModel,string algorithm,string algorithmPath,string runId)
    {
        var cartesian =
            CloneThroughJson(
                sourceModel.CartesianMap);

        List<OptimizationRecommendationRecord> recommendations;

        if (algorithm.Equals(
            "Linear programming",
            StringComparison.OrdinalIgnoreCase))
        {
            recommendations =
                RunLinearProgrammingPlacement(
                    cartesian,
                    sourceModel.BaselineReliability)
                .ToList();
        }
        else if (algorithm.Equals(
            "Lexicographic linear optimization",
            StringComparison.OrdinalIgnoreCase))
        {
            recommendations =
                RunLexicographicPlacement(
                    cartesian,
                    sourceModel.BaselineReliability)
                .ToList();
        }
        else if (algorithm.Equals(
            "Random tree optimisation",
            StringComparison.OrdinalIgnoreCase))
        {
            recommendations =
                RunRandomTreePlacement(
                    cartesian,
                    sourceModel.BaselineReliability)
                .ToList();
        }
        else
        {
            recommendations =
                RunRandomTreePlacement(
                    cartesian,
                    sourceModel.BaselineReliability)
                .ToList();
        }

        foreach (var recommendation in recommendations)
        {
            var voltage =
                cartesian.Edges
                    .Where(edge =>
                        string.Equals(
                            edge.FromNode,
                            recommendation.NodeId,
                            StringComparison.OrdinalIgnoreCase)
                        ||
                        string.Equals(
                            edge.ToNode,
                            recommendation.NodeId,
                            StringComparison.OrdinalIgnoreCase))
                    .Select(edge => edge.VoltageKv)
                    .DefaultIfEmpty(11)
                    .First();

            cartesian.ProtectionDevices.Add(
                new ModelProtectionDeviceRecord
                {
                    Id = recommendation.Id,
                    AssetType = "ProposedRecloser",
                    NodeId = recommendation.NodeId,
                    VoltageKv = voltage,
                    FeederId = recommendation.FeederId,
                    Model = algorithm,
                    Status = "New optimized placement",
                    Proposed = true
                });
        }

        var baseline =
            sourceModel.BaselineReliability.Saidi > 0
                ? sourceModel.BaselineReliability
                : CalculateReliability(
                    sourceModel.CartesianMap,
                    proposedReclosers: 0);

        var improved =
            CalculateReliability(
                cartesian,
                recommendations.Count);

        improved.Customers =
            baseline.Customers;

        improved.TotalLineKm =
            baseline.TotalLineKm;

        improved.ExistingReclosers =
            baseline.ExistingReclosers;

        improved.ProposedReclosers =
            recommendations.Count;

        return new BuiltModelRecord
        {
            Id = $"{runId}-optimized-model",

            Name =
                $"Optimized model {DateTime.Now:yyyy-MM-dd HH:mm}",

            ProjectId =
                sourceModel.ProjectId,

            BaselineModelId =
                !string.IsNullOrWhiteSpace(
                    sourceModel.BaselineModelId)
                    ? sourceModel.BaselineModelId
                    : sourceModel.Id,

            Status = "Optimized vector map",

            SourceProcessedFiles =
                sourceModel.SourceProcessedFiles.ToList(),

            BaseModel =
                sourceModel.BaseModel,

            CartesianMap =
                cartesian,

            PolarMap =
                ConvertCartesianToPolarMap(
                    cartesian),

            BaselineReliability =
                baseline,

            Optimization =
                new OptimizationResultRecord
                {
                    Algorithm =
                        algorithm,

                    AlgorithmPath =
                        algorithmPath,

                    RunId =
                        runId,

                    BaselineModelId =
                        !string.IsNullOrWhiteSpace(
                            sourceModel.BaselineModelId)
                            ? sourceModel.BaselineModelId
                            : sourceModel.Id,

                    Status =
                        "Complete",

                    Baseline =
                        baseline,

                    Improved =
                        improved,

                    SaidiImprovement =
                        Math.Round(
                            baseline.Saidi -
                            improved.Saidi,
                            2),

                    SaifiImprovement =
                        Math.Round(
                            baseline.Saifi -
                            improved.Saifi,
                            3),

                    Recommendations =
                        recommendations
                },

            ValidationMessages =
            {
                $"Optimization run {runId} complete.",
                $"Algorithm: {algorithm}.",
                $"Baseline SAIDI {baseline.Saidi:N2}, SAIFI {baseline.Saifi:N3}.",
                $"Improved SAIDI {improved.Saidi:N2}, SAIFI {improved.Saifi:N3}.",
                $"Recommended {recommendations.Count} recloser insertion point(s).",
                "New optimized placements are marked as ProposedRecloser with Proposed = true and Status = New optimized placement."
            }
        };
    }

    // Selects high-value candidate nodes for proposed recloser insertion.
    private static List<OptimizationRecommendationRecord> SelectRecloserPlacementCandidates(CartesianMapRecord map, int maxCandidates)
    {
        var existingProtectionNodes = map.ProtectionDevices
            .Where(device => !device.Proposed)
            .Select(device => device.NodeId)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var nodeLookup = map.Nodes.ToDictionary(node => node.Id, StringComparer.OrdinalIgnoreCase);
        var lineByToNode = map.Edges
            .GroupBy(edge => edge.ToNode, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.OrderByDescending(edge => edge.LengthM).First(), StringComparer.OrdinalIgnoreCase);

        return map.Loads
            .Where(load => load.Customers > 0 && !existingProtectionNodes.Contains(load.NodeId) && nodeLookup.ContainsKey(load.NodeId))
            .GroupBy(load => load.NodeId, StringComparer.OrdinalIgnoreCase)
            .Select(group =>
            {
                var loadCustomers = group.Sum(load => load.Customers);
                var loadKva = group.Sum(load => load.Kva);
                var node = nodeLookup[group.Key];
                var upstreamLength = lineByToNode.TryGetValue(group.Key, out var line) ? line.LengthM : 0;
                var score = loadCustomers * 1.8 + loadKva * 0.25 + upstreamLength / 120.0;
                return new OptimizationRecommendationRecord
                {
                    Id = $"PROP-RC-{group.Key}",
                    Action = "Insert recloser",
                    NodeId = group.Key,
                    FeederId = node.FeederId,
                    ProtectedCustomers = loadCustomers,
                    Score = Math.Round(score, 2),
                    ExpectedSaidiReduction = Math.Round(Math.Min(18.0, 1.2 + loadCustomers * 0.08 + upstreamLength / 5000.0), 2),
                    ExpectedSaifiReduction = Math.Round(Math.Min(0.18, 0.01 + loadCustomers * 0.0008 + upstreamLength / 500000.0), 3),
                };
            })
            .OrderByDescending(candidate => candidate.Score)
            .Take(maxCandidates)
            .ToList();
    }

    // Appends a complete optimization result row to the project report log.
    private void WriteOptimizationRunLog(BuiltModelRecord sourceModel, BuiltModelRecord optimizedModel)
    {
        var logPath = OptimizationRunLogPath();
        EnsureOptimizationRunLogExists(logPath);

        var result = optimizedModel.Optimization;
        File.AppendAllText(
            logPath,
            $"{result.RunId},{Csv(result.Algorithm)},{Csv(result.AlgorithmPath)},{sourceModel.Id},{optimizedModel.Id},{result.Baseline.Saidi},{result.Baseline.Saifi},{result.Improved.Saidi},{result.Improved.Saifi},{result.SaidiImprovement},{result.SaifiImprovement},{result.Recommendations.Count},{result.Status},{DateTime.Now:yyyy-MM-dd HH:mm}\n");
    }

    // Records a baseline-only reliability assessment in the same comparison log as optimization runs.
    private void WriteReliabilityAssessmentLog(BuiltModelRecord sourceModel, ReliabilityMetricsRecord baseline, string runId)
    {
        var logPath = OptimizationRunLogPath();
        EnsureOptimizationRunLogExists(logPath);
        File.AppendAllText(
            logPath,
            $"{runId},Reliability assessment,,{sourceModel.Id},{sourceModel.Id},{baseline.Saidi},{baseline.Saifi},{baseline.Saidi},{baseline.Saifi},0,0,0,Complete,{DateTime.Now:yyyy-MM-dd HH:mm}\n");
    }

    private string OptimizationRunLogPath()
    {
        return Path.Combine(_workspaceStore.ProjectFolder(_workspaceState, "reports"), "optimization-runs.csv");
    }

    private static void EnsureOptimizationRunLogExists(string logPath)
    {
        if (!File.Exists(logPath))
        {
            Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
            File.WriteAllText(logPath, "run_id,algorithm,algorithm_path,source_model_id,output_model_id,baseline_saidi,baseline_saifi,improved_saidi,improved_saifi,saidi_improvement,saifi_improvement,recommendations,status,run_at\n");
        }
    }

    private static T CloneThroughJson<T>(T value)
    {
        return JsonSerializer.Deserialize<T>(JsonSerializer.Serialize(value))!;
    }

    private static string Csv(string value)
    {
        return value.Contains(',') || value.Contains('"') || value.Contains('\n')
            ? $"\"{value.Replace("\"", "\"\"")}\""
            : value;
    }

    private static double ParseDouble(string value)
    {
        return double.TryParse(value, out var parsed) ? parsed : 0;
    }
}
