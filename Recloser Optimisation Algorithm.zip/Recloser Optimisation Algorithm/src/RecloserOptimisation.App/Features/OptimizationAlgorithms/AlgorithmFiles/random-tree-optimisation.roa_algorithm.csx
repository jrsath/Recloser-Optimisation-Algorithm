IEnumerable<OptimizationRecommendationRecord> RunRandomTreePlacement(
    CartesianMapRecord map,
    ReliabilityMetricsRecord baseline,
    int seed = 42)
{
    const int maxDevices = 5;
    const int iterations = 10000;

    var random = new Random(seed);

    var polarMap = ConvertCartesianToPolarMap(map);

    var protectedNodes =
        map.ProtectionDevices
            .Select(device => device.NodeId)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

    var graph =
        polarMap.Edges
            .GroupBy(
                edge => edge.FromNode,
                StringComparer.OrdinalIgnoreCase)
            .ToDictionary(
                group => group.Key,
                group => group.Select(edge => edge.ToNode).ToList(),
                StringComparer.OrdinalIgnoreCase);

    var candidates =
        map.Loads
            .GroupBy(
                load => load.NodeId,
                StringComparer.OrdinalIgnoreCase)
            .Select(group =>
            {
                var nodeId = group.Key;

                if (protectedNodes.Contains(nodeId))
                {
                    return null;
                }

                var visited =
                    new HashSet<string>(
                        StringComparer.OrdinalIgnoreCase);

                var queue =
                    new Queue<string>();

                queue.Enqueue(nodeId);

                while (queue.Count > 0)
                {
                    var current = queue.Dequeue();

                    if (!visited.Add(current))
                    {
                        continue;
                    }

                    if (graph.TryGetValue(
                        current,
                        out var children))
                    {
                        foreach (var child in children)
                        {
                            queue.Enqueue(child);
                        }
                    }
                }

                var customers =
                    map.Loads
                        .Where(load =>
                            visited.Contains(load.NodeId))
                        .Sum(load =>
                            load.Customers);

                var kva =
                    map.Loads
                        .Where(load =>
                            visited.Contains(load.NodeId))
                        .Sum(load =>
                            load.Kva);

                var exposureKm =
                    polarMap.Edges
                        .Where(edge =>
                            visited.Contains(edge.FromNode))
                        .Sum(edge =>
                            edge.LengthM)
                        / 1000.0;

                var saidiReduction =
                    Math.Min(
                        30.0,
                        exposureKm * 5.0 +
                        customers * 0.01);

                var saifiReduction =
                    Math.Min(
                        0.30,
                        exposureKm * 0.01 +
                        customers * 0.00001);

                return new
                {
                    NodeId = nodeId,
                    ProtectedCustomers = customers,
                    ProtectedKva = kva,
                    ExposureKm = exposureKm,
                    ExpectedSaidiReduction = saidiReduction,
                    ExpectedSaifiReduction = saifiReduction
                };
            })
            .Where(candidate => candidate != null)
            .ToList();

    double bestScore = double.MinValue;

    List<dynamic> bestSolution = new();

    for (int i = 0; i < iterations; i++)
    {
        var sample =
            candidates
                .OrderBy(_ => random.NextDouble())
                .Take(
                    random.Next(
                        1,
                        Math.Min(
                            maxDevices,
                            candidates.Count) + 1))
                .ToList();

        var score =
            sample.Sum(candidate =>
                candidate.ExpectedSaidiReduction * 100.0 +
                candidate.ExpectedSaifiReduction * 1000.0 +
                candidate.ProtectedCustomers * 2.0 +
                candidate.ProtectedKva * 0.05 +
                candidate.ExposureKm * 25.0);

        if (score > bestScore)
        {
            bestScore = score;
            bestSolution = sample.Cast<dynamic>().ToList();
        }
    }

    return bestSolution
        .Select(candidate =>
            new OptimizationRecommendationRecord
            {
                Id = $"TREE-RC-{candidate.NodeId}",
                Action = "Insert recloser",
                NodeId = candidate.NodeId,

                Score =
                    candidate.ExpectedSaidiReduction * 100.0 +
                    candidate.ExpectedSaifiReduction * 1000.0 +
                    candidate.ProtectedCustomers * 2.0 +
                    candidate.ProtectedKva * 0.05 +
                    candidate.ExposureKm * 25.0,

                ProtectedCustomers =
                    candidate.ProtectedCustomers,

                ExpectedSaidiReduction =
                    Math.Round(
                        candidate.ExpectedSaidiReduction,
                        2),

                ExpectedSaifiReduction =
                    Math.Round(
                        candidate.ExpectedSaifiReduction,
                        4)
            })
        .OrderByDescending(x => x.Score)
        .ToList();
}