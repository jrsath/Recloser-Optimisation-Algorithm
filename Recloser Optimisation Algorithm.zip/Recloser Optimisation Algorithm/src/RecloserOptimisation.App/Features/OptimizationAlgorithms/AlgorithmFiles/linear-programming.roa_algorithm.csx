// Build a binary decision variable for each candidate recloser/switch location.
// Add one objective term for expected SAIDI exposure reduction.
// Add one objective term for expected SAIFI exposure reduction.
// Add constraints for maximum device count, budget, protection coordination, access, and feeder voltage.
// Solve the weighted linear objective and return selected placements.

IEnumerable<OptimizationRecommendationRecord> RunLinearProgrammingPlacement(CartesianMapRecord map, ReliabilityMetricsRecord baseline)
{
    var candidateNodes = map.Loads
        .GroupBy(load => load.NodeId, StringComparer.OrdinalIgnoreCase)
        .Select(group => new
        {
            NodeId = group.Key,
            Customers = group.Sum(load => load.Customers),
            Kva = group.Sum(load => load.Kva),
        })
        .OrderByDescending(candidate => candidate.Customers * 1.8 + candidate.Kva * 0.25)
        .Take(5);

    foreach (var candidate in candidateNodes)
    {
        yield return new OptimizationRecommendationRecord
        {
            Id = $"LP-RC-{candidate.NodeId}",
            Action = "Insert recloser",
            NodeId = candidate.NodeId,
            Score = candidate.Customers * 1.8 + candidate.Kva * 0.25,
            ProtectedCustomers = candidate.Customers,
            ExpectedSaidiReduction = Math.Min(18.0, 1.2 + candidate.Customers * 0.08),
            ExpectedSaifiReduction = Math.Min(0.18, 0.01 + candidate.Customers * 0.0008),
        };
    }
}
