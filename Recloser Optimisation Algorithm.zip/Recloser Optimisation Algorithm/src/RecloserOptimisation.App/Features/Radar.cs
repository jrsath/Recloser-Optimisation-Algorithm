using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Draws the compact validation/completeness radar widget.

    // Redraws the compact radar chart that summarizes data quality dimensions.
    private void RenderRadar()
    {
        RenderRadarOnCanvas(RadarCanvas);
    }

    // Draw data quality radar and outage/reliability bars whenever the dashboard is shown.
    private void RenderDashboardVisuals()
    {
        RenderRadarOnCanvas(DashboardRadarCanvas);
        RenderDashboardOutageSnapshot();
    }

    // Draw six data quality axes, then place a filled polygon using the selected model's score values.
    private void RenderRadarOnCanvas(Canvas canvas)
    {
        if (canvas.ActualWidth < 10 || canvas.ActualHeight < 10)
        {
            return;
        }

        var model = LoadSelectedMapModel(SelectedMapModelPath());
        var dataQuality = AnalyzeDataQuality(model);
        UpdateDataQualityIssueList(dataQuality);
        MapIntegrityBar.Value = Math.Round(dataQuality.Overall * 100.0, 0);

        canvas.Children.Clear();
        var values = new[] { dataQuality.Completeness, dataQuality.Quality, dataQuality.Integrity, dataQuality.DataSize, dataQuality.MapSize, dataQuality.Verification };
        var labels = new[] { "Completeness", "Quality", "Integrity", "Data size", "Map size", "Verification" };
        var descriptions = new[]
        {
            "Completeness: how many required model, outage and asset fields are present.",
            "Quality: whether values look plausible, labelled and internally consistent.",
            "Integrity: whether IDs, feeder links and required relationships can be joined.",
            "Data size: whether the dataset is large enough to support useful modelling.",
            "Map size: whether spatial coverage is broad enough for the selected feeder study.",
            "Verification: whether imported data has passed checks or needs review.",
        };
        var centerX = canvas.ActualWidth / 2.0;
        var centerY = canvas.ActualHeight / 2.0;
        var radius = Math.Min(centerX, centerY) * 0.72;
        var points = new PointCollection();

        for (var i = 0; i < values.Length; i++)
        {
            var angle = (2 * Math.PI * i / values.Length) - Math.PI / 2;
            var axisX = centerX + radius * Math.Cos(angle);
            var axisY = centerY + radius * Math.Sin(angle);
            var valueX = centerX + radius * values[i] * Math.Cos(angle);
            var valueY = centerY + radius * values[i] * Math.Sin(angle);
            points.Add(new Point(valueX, valueY));

            var line = new System.Windows.Shapes.Line { X1 = centerX, Y1 = centerY, X2 = axisX, Y2 = axisY, Stroke = BrushFrom("#C8D3E3"), StrokeThickness = 1 };
            canvas.Children.Add(line);
            var label = new TextBlock
            {
                Text = labels[i],
                Foreground = BrushFrom("#39475D"),
                FontSize = 11,
                ToolTip = descriptions[i],
            };
            ToolTipService.SetInitialShowDelay(label, 1500);
            ToolTipService.SetShowDuration(label, 12000);
            Canvas.SetLeft(label, axisX - 30);
            Canvas.SetTop(label, axisY - 10);
            canvas.Children.Add(label);
        }

        var polygon = new System.Windows.Shapes.Polygon { Points = points, Fill = BrushFrom("#553399FF"), Stroke = BrushFrom("#1559C9"), StrokeThickness = 2 };
        canvas.Children.Add(polygon);
    }

    // Refresh the dashboard issue list without replacing the collection instance used by the UI.
    private void UpdateDataQualityIssueList(DataQualityResultRecord dataQuality)
    {
        _dataQualityIssues.Clear();
        foreach (var issue in dataQuality.Issues.OrderBy(issue => issue.Severity).ThenBy(issue => issue.Category))
        {
            _dataQualityIssues.Add(issue);
        }
    }

    // Read the active model reliability, then draw baseline/optimized SAIDI and SAIFI as comparison bars.
    private void RenderDashboardOutageSnapshot()
    {
        if (DashboardOutageCanvas.ActualWidth < 10 || DashboardOutageCanvas.ActualHeight < 10)
        {
            return;
        }

        DashboardOutageCanvas.Children.Clear();
        var model = LoadSelectedMapModel(SelectedMapModelPath());
        var snapshot = ReliabilitySnapshotForModel(model);
        var baselineSaidi = snapshot.Baseline.Saidi;
        var optimizedSaidi = snapshot.Optimized.Saidi;
        var baselineSaifi = snapshot.Baseline.Saifi;
        var optimizedSaifi = snapshot.Optimized.Saifi;
        var max = Math.Max(1, Math.Max(baselineSaidi, optimizedSaidi) + Math.Max(baselineSaifi, optimizedSaifi) * 60);

        DrawDashboardBar("Baseline SAIDI", baselineSaidi, max, 22, "#D64545");
        DrawDashboardBar("Optimized SAIDI", optimizedSaidi, max, 62, "#2F9E44");
        DrawDashboardBar("Baseline SAIFI x60", baselineSaifi * 60, max, 120, "#F08C00");
        DrawDashboardBar("Optimized SAIFI x60", optimizedSaifi * 60, max, 160, "#1559C9");

        var note = new TextBlock
        {
            Text = model is null ? "Select a model to populate outage and reliability visuals." : $"Linked outage file: {(_workspaceStore.CurrentProject(_workspaceState).Settings.LinkedOutageFilePath.Length > 0 ? "yes" : "no")}",
            Foreground = BrushFrom("#667287"),
            FontSize = 12,
        };
        Canvas.SetLeft(note, 12);
        Canvas.SetTop(note, 200);
        DashboardOutageCanvas.Children.Add(note);
    }

    // Draw one labeled horizontal bar scaled against the largest reliability metric.
    private void DrawDashboardBar(string label, double value, double max, double top, string color)
    {
        var width = Math.Max(8, (DashboardOutageCanvas.ActualWidth - 160) * value / max);
        var labelBlock = new TextBlock { Text = label, Foreground = BrushFrom("#39475D"), FontSize = 12 };
        Canvas.SetLeft(labelBlock, 12);
        Canvas.SetTop(labelBlock, top);
        DashboardOutageCanvas.Children.Add(labelBlock);

        var bar = new System.Windows.Shapes.Rectangle
        {
            Width = width,
            Height = 18,
            RadiusX = 4,
            RadiusY = 4,
            Fill = BrushFrom(color),
            Opacity = 0.86,
        };
        Canvas.SetLeft(bar, 120);
        Canvas.SetTop(bar, top);
        DashboardOutageCanvas.Children.Add(bar);

        var valueBlock = new TextBlock { Text = value.ToString("N2"), Foreground = BrushFrom("#132033"), FontSize = 12, FontWeight = FontWeights.SemiBold };
        Canvas.SetLeft(valueBlock, 130 + width);
        Canvas.SetTop(valueBlock, top);
        DashboardOutageCanvas.Children.Add(valueBlock);
    }
}
