using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Draws the compact validation/completeness radar widget.

    // Redraws the compact radar chart that summarizes data readiness dimensions.
    private void RenderRadar()
    {
        if (RadarCanvas.ActualWidth < 10 || RadarCanvas.ActualHeight < 10)
        {
            return;
        }

        RadarCanvas.Children.Clear();
        var values = new[] { 0.82, 0.76, 0.88, 0.69, 0.73, 0.80 };
        var labels = new[] { "Completeness", "Quality", "Integrity", "Data size", "Map size", "Verification" };
        var centerX = RadarCanvas.ActualWidth / 2.0;
        var centerY = RadarCanvas.ActualHeight / 2.0;
        var radius = Math.Min(centerX, centerY) * 0.72;
        var points = new PointCollection();

        for (var i = 0; i < values.Length; i++)
        {
            var angle = (2 * Math.PI * i / values.Length) - Math.PI / 2;
            var axisX = centerX + radius * Math.Cos(angle);
            var axisY = centerY + radius * Math.Sin(angle);
            var valueX = centerX + radius * values[i] * Math.Cos(angle);
            var valueY = centerY + radius * values[i] * Math.Sin(angle);
            points.Add(new Point(valueX, valueY));

            var line = new System.Windows.Shapes.Line { X1 = centerX, Y1 = centerY, X2 = axisX, Y2 = axisY, Stroke = BrushFrom("#C8D3E3"), StrokeThickness = 1 };
            RadarCanvas.Children.Add(line);
            var label = new TextBlock { Text = labels[i], Foreground = BrushFrom("#39475D"), FontSize = 11 };
            Canvas.SetLeft(label, axisX - 30);
            Canvas.SetTop(label, axisY - 10);
            RadarCanvas.Children.Add(label);
        }

        var polygon = new System.Windows.Shapes.Polygon { Points = points, Fill = BrushFrom("#553399FF"), Stroke = BrushFrom("#1559C9"), StrokeThickness = 2 };
        RadarCanvas.Children.Add(polygon);
    }
}

