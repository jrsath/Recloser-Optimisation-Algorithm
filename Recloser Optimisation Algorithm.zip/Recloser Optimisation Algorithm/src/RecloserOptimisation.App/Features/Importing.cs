using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // File/folder import staging and source file metadata helpers.

    // Prompts for one or more source files and stages them into current project source storage.
    private void ChooseImportFiles()
    {
        var dialog = new OpenFileDialog
        {
            Multiselect = true,
            Title = "Import source files",
            Filter = "Supported source files|*.csv;*.xlsx;*.xls;*.json;*.geojson;*.shp;*.dbf;*.prj;*.shx;*.zip;*.gpkg;*.kml;*.kmz;*.tab;*.mif;*.mid;*.dxf;*.dwg;*.dxl;*.dss;*.glm;*.pfd;*.pf;*.dgs;*.dz;*.xml;*.rdf;*.raw;*.olr;*.cfg;*.dat;*.txt;*.m;*.mat;*.mdb;*.accdb|All files|*.*",
        };

        if (dialog.ShowDialog(this) != true)
        {
            return;
        }

        var importKind = PromptForImportKind();
        if (string.IsNullOrWhiteSpace(importKind))
        {
            return;
        }

        foreach (var fileName in dialog.FileNames)
        {
            AddImportPath(fileName, importKind);
        }

        SetStatus($"{dialog.FileNames.Length} import file(s) staged");
    }

    // Prompts for a source folder and stages it into current project source storage.
    private void ChooseImportFolder()
    {
        using var dialog = new WinForms.FolderBrowserDialog
        {
            Description = "Select a File Geodatabase, GIS export folder, model folder or platform project folder",
            UseDescriptionForTitle = true,
        };

        if (dialog.ShowDialog() == WinForms.DialogResult.OK)
        {
            var importKind = PromptForImportKind();
            if (string.IsNullOrWhiteSpace(importKind))
            {
                return;
            }

            AddImportPath(dialog.SelectedPath, importKind);
            SetStatus("Import folder staged");
        }
    }

    // Registers a file or folder as a staged source import and copies it into project storage.
    private void AddImportPath(string path, string importKind = "")
    {
        if (!File.Exists(path) && !Directory.Exists(path))
        {
            return;
        }

        if (importKind.Equals("Optimization algorithm", StringComparison.OrdinalIgnoreCase))
        {
            AddOptimizationAlgorithm(Path.GetFileNameWithoutExtension(path), "Imported editable algorithm", "Ready", path);
            OptimizationAlgorithmsGrid.Items.Refresh();
            SetStatus($"Optimization algorithm imported: {Path.GetFileName(path)}");
            return;
        }

        var isDirectory = Directory.Exists(path);
        FileSystemInfo info = isDirectory ? new DirectoryInfo(path) : new FileInfo(path);
        var length = isDirectory ? 0 : ((FileInfo)info).Length;
        var uploadedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
        var storedPath = CopyIntoProjectStorage(path, "source-files", uploadedAt);

        foreach (var import in _imports.Where(existing => string.Equals(existing.File, info.Name, StringComparison.OrdinalIgnoreCase)))
        {
            import.Active = false;
            import.Status = "Old version";
        }

        var hasOlderVersion = _imports.Any(existing => string.Equals(existing.File, info.Name, StringComparison.OrdinalIgnoreCase));

        _imports.Insert(0, new StagedImport
        {
            Active = false,
            File = info.Name,
            Source = string.IsNullOrWhiteSpace(importKind) ? SelectedSourceType() : importKind,
            Format = SourceFormat(info),
            Size = isDirectory ? "Folder" : FormatBytes(length),
            Imported = uploadedAt,
            Status = "Source file",
            Label = string.IsNullOrWhiteSpace(importKind) ? "Imported data" : importKind,
            Path = storedPath,
        });

        SaveProjectStorageMetadata();
        RefreshFileFilters();
    }

    // Asks the user what kind of source file is being imported so storage tabs can classify it.
    private string PromptForImportKind()
    {
        var dialog = new Window
        {
            Owner = this,
            Title = "Import file type",
            Width = 420,
            Height = 180,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
        };
        var combo = new ComboBox { Height = 34, Margin = new Thickness(0, 6, 0, 12), SelectedIndex = 0 };
        foreach (var kind in new[] { "Model", "Model part", "Outage", "Optimization algorithm" })
        {
            combo.Items.Add(new ComboBoxItem { Content = kind });
        }

        var ok = new Button { Content = "Import", Width = 90, HorizontalAlignment = HorizontalAlignment.Right };
        ok.Click += (_, _) => dialog.DialogResult = true;
        var panel = new StackPanel { Margin = new Thickness(16) };
        panel.Children.Add(new TextBlock { Text = "Choose the type of file being imported." });
        panel.Children.Add(combo);
        panel.Children.Add(ok);
        dialog.Content = panel;
        return dialog.ShowDialog() == true ? SelectedComboText(combo) : "";
    }

    // Copies an imported file or folder into the requested current-project storage folder.
    private string CopyIntoProjectStorage(string sourcePath, string folderName, string uploadedAt)
    {
        var targetFolder = _workspaceStore.ProjectFolder(_workspaceState, folderName);
        var safeStamp = uploadedAt.Replace("-", "").Replace(":", "").Replace(" ", "-");
        var sourceName = Path.GetFileName(sourcePath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        var targetName = $"{safeStamp}-{sourceName}";
        var targetPath = Path.Combine(targetFolder, targetName);

        if (File.Exists(sourcePath))
        {
            Directory.CreateDirectory(targetFolder);
            File.Copy(sourcePath, targetPath, overwrite: true);
            return targetPath;
        }

        if (Directory.Exists(sourcePath))
        {
            CopyDirectory(sourcePath, targetPath);
            return targetPath;
        }

        return sourcePath;
    }

    // Recursively copies a staged source folder while preserving its internal folder layout.
    private static void CopyDirectory(string sourcePath, string targetPath)
    {
        Directory.CreateDirectory(targetPath);
        foreach (var directory in Directory.EnumerateDirectories(sourcePath, "*", SearchOption.AllDirectories))
        {
            var relative = Path.GetRelativePath(sourcePath, directory);
            Directory.CreateDirectory(Path.Combine(targetPath, relative));
        }

        foreach (var file in Directory.EnumerateFiles(sourcePath, "*", SearchOption.AllDirectories))
        {
            var relative = Path.GetRelativePath(sourcePath, file);
            var destination = Path.Combine(targetPath, relative);
            Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
            File.Copy(file, destination, overwrite: true);
        }
    }

    // Reads the selected source classification used for newly staged imports.
    private string SelectedSourceType()
    {
        var value = SourceTypeCombo.SelectedItem is ComboBoxItem item
            ? item.Content.ToString() ?? "Unknown"
            : SourceTypeCombo.Text;

        return value == "All file types" ? "Unclassified" : value;
    }

    // Converts an imported file extension or folder shape into a user-facing source format.
    private static string SourceFormat(FileSystemInfo item)
    {
        if (item is DirectoryInfo)
        {
            return item.Name.EndsWith(".gdb", StringComparison.OrdinalIgnoreCase) ? "File Geodatabase" : "Folder";
        }

        return item.Extension.TrimStart('.').ToLowerInvariant() switch
        {
            "csv" => "CSV",
            "xlsx" or "xls" => "Excel",
            "json" => "JSON",
            "geojson" => "GeoJSON",
            "shp" => "Esri Shapefile",
            "gpkg" => "GeoPackage",
            "kml" => "KML",
            "kmz" => "KMZ",
            "tab" => "MapInfo TAB",
            "mif" => "MapInfo MIF",
            "mid" => "MapInfo MID",
            "dxf" => "DXF",
            "dwg" => "DWG",
            "dxl" => "DXL",
            "dss" => "OpenDSS",
            "glm" => "GridLAB-D",
            "pfd" or "pf" or "dgs" or "dz" => "PowerFactory",
            "xml" => "XML / CIM",
            "rdf" => "CIM RDF",
            "raw" => "PSS/E RAW",
            "olr" => "ASPEN OneLiner",
            "cfg" => "COMTRADE CFG",
            "dat" => "COMTRADE DAT",
            "zip" => "Archive",
            var extension when !string.IsNullOrWhiteSpace(extension) => extension.ToUpperInvariant(),
            _ => "Unknown",
        };
    }

    // Formats file sizes for display in the source-file storage grid.
    private static string FormatBytes(long bytes)
    {
        if (bytes < 1024) return $"{bytes} B";
        if (bytes < 1024 * 1024) return $"{bytes / 1024.0:N1} KB";
        if (bytes < 1024 * 1024 * 1024) return $"{bytes / 1024.0 / 1024.0:N1} MB";
        return $"{bytes / 1024.0 / 1024.0 / 1024.0:N1} GB";
    }
}
