using System;
using System.Collections.Generic;
using System.Linq;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    // Review the selected model and return radar scores plus clickable data issues.
    private static DataQualityResultRecord AnalyzeDataQuality(BuiltModelRecord? model)
    {
        var result = new DataQualityResultRecord();
        if (model is null)
        {
            result.Issues.Add(new DataQualityIssueRecord
            {
                Category = "Verification",
                Severity = "Info",
                Summary = "No model selected",
                Detail = "Select or build a model to calculate data quality.",
            });
            return result;
        }

        var nodes = model.CartesianMap.Nodes;
        var edges = model.CartesianMap.Edges;
        var nodeIds = nodes.Select(node => node.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var missingEdgeRefs = edges.Where(edge => !nodeIds.Contains(edge.FromNode) || !nodeIds.Contains(edge.ToNode)).ToList();
        var missingCoordinates = nodes.Where(node => Math.Abs(node.Latitude) < 0.001 && Math.Abs(node.Longitude) < 0.001).ToList();
        var missingFeederNodes = nodes.Where(node => string.IsNullOrWhiteSpace(node.FeederId)).ToList();
        var missingFeederEdges = edges.Where(edge => string.IsNullOrWhiteSpace(edge.FeederId)).ToList();
        var zeroLengthEdges = edges.Where(edge => edge.LengthM <= 0).ToList();
        var orphanLoads = model.CartesianMap.Loads.Where(load => !nodeIds.Contains(load.NodeId)).ToList();
        var orphanSwitches = model.CartesianMap.Switches.Where(item => !nodeIds.Contains(item.NodeId)).ToList();
        var orphanProtection = model.CartesianMap.ProtectionDevices.Where(item => !nodeIds.Contains(item.NodeId)).ToList();
        var connectedNodeIds = edges.Select(edge => edge.FromNode).Concat(edges.Select(edge => edge.ToNode)).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var isolatedNodes = nodes.Where(node => !connectedNodeIds.Contains(node.Id)).ToList();

        AddIssueRows(result.Issues, "Integrity", "Error", "Line references missing nodes", missingEdgeRefs.Select(edge => edge.FromNode).Concat(missingEdgeRefs.Select(edge => edge.ToNode)).Where(id => !nodeIds.Contains(id)).Distinct(), "Some lines point to node IDs that are not present in nodes.csv.");
        AddIssueRows(result.Issues, "Completeness", "Warning", "Missing node coordinates", missingCoordinates.Select(node => node.Id), "Coordinates are required for map display. These nodes were skipped or placed by assumption.");
        AddIssueRows(result.Issues, "Completeness", "Warning", "Missing feeder IDs", missingFeederNodes.Select(node => node.Id).Concat(missingFeederEdges.Select(edge => edge.FromNode)), "Feeder IDs are used for filtering, optimization areas and reporting.");
        AddIssueRows(result.Issues, "Quality", "Assumption", "Line length inferred", zeroLengthEdges.Select(edge => edge.FromNode), "Line length was missing or zero and has been estimated from node coordinates.");
        AddIssueRows(result.Issues, "Integrity", "Error", "Loads reference missing nodes", orphanLoads.Select(load => load.NodeId), "Loads need a matching node to be represented on the model.");
        AddIssueRows(result.Issues, "Integrity", "Error", "Switch/protection reference missing nodes", orphanSwitches.Select(item => item.NodeId).Concat(orphanProtection.Select(item => item.NodeId)), "Protection and switching devices need matching nodes.");
        AddIssueRows(result.Issues, "Quality", "Warning", "Isolated nodes found", isolatedNodes.Take(20).Select(node => node.Id), "These nodes are not connected by any line and may indicate import or connectivity issues.");

        result.Completeness = ScoreFromProblems(nodes.Count + edges.Count + model.CartesianMap.Loads.Count, missingCoordinates.Count + missingFeederNodes.Count + missingFeederEdges.Count);
        result.Quality = ScoreFromProblems(edges.Count + nodes.Count, zeroLengthEdges.Count + isolatedNodes.Count);
        result.Integrity = ScoreFromProblems(edges.Count + model.CartesianMap.Loads.Count + model.CartesianMap.Switches.Count + model.CartesianMap.ProtectionDevices.Count, missingEdgeRefs.Count + orphanLoads.Count + orphanSwitches.Count + orphanProtection.Count);
        result.DataSize = Math.Clamp((nodes.Count / 2500.0 + edges.Count / 2500.0 + Math.Max(1, model.CartesianMap.Feeders.Count) / 12.0) / 3.0, 0.05, 1.0);
        result.MapSize = ScoreMapCoverage(nodes);
        result.Verification = Math.Clamp(1.0 - model.ValidationMessages.Count(message => message.Contains("missing", StringComparison.OrdinalIgnoreCase) || message.Contains("error", StringComparison.OrdinalIgnoreCase)) / 20.0, 0.1, 1.0);

        if (result.Issues.Count == 0)
        {
            result.Issues.Add(new DataQualityIssueRecord
            {
                Category = "Verification",
                Severity = "OK",
                Summary = "No blocking data issues found",
                Detail = "The selected model passed the current prototype quality checks.",
            });
        }

        return result;
    }

    // Convert problem counts into a bounded 0-1 score for a radar axis.
    private static double ScoreFromProblems(int total, int problems)
    {
        if (total <= 0)
        {
            return 0;
        }

        return Math.Clamp(1.0 - (double)problems / Math.Max(1, total), 0.05, 1.0);
    }

    // Score spatial spread so a model with enough geographic coverage produces a stronger map-size axis.
    private static double ScoreMapCoverage(List<CartesianNodeRecord> nodes)
    {
        var valid = nodes.Where(node => Math.Abs(node.Latitude) > 0.001 || Math.Abs(node.Longitude) > 0.001).ToList();
        if (valid.Count == 0)
        {
            return 0;
        }

        var latSpan = valid.Max(node => node.Latitude) - valid.Min(node => node.Latitude);
        var lngSpan = valid.Max(node => node.Longitude) - valid.Min(node => node.Longitude);
        return Math.Clamp((latSpan + lngSpan) * 8.0, 0.05, 1.0);
    }

    // Create issue rows and keep the list readable by grouping repeated issues.
    private static void AddIssueRows(List<DataQualityIssueRecord> issues, string category, string severity, string summary, IEnumerable<string> nodeIds, string detail)
    {
        foreach (var nodeId in nodeIds.Where(id => !string.IsNullOrWhiteSpace(id)).Distinct(StringComparer.OrdinalIgnoreCase).Take(25))
        {
            issues.Add(new DataQualityIssueRecord
            {
                Category = category,
                Severity = severity,
                Summary = summary,
                Detail = detail,
                NodeId = nodeId,
                FixedWithAssumption = severity.Equals("Assumption", StringComparison.OrdinalIgnoreCase),
            });
        }
    }
}
