using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;
using System.Diagnostics;
using System.Globalization;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Filtering and previews for staged source files, processed files, models, and reports.
    private string _lastPreviewedStoragePath = "";
    private object? _lastPreviewedStorageItem;

    // Applies the database source-type and text filters to staged source-file rows.
    private bool FilterImport(object item)
    {
        if (item is not StagedImport import)
        {
            return false;
        }

        var typeFilter = SelectedComboText(SourceTypeCombo);
        var textFilter = SearchFilterText(FileNameFilterBox);

        var typeMatches = typeFilter == "All file types"
            || string.IsNullOrWhiteSpace(typeFilter)
            || import.Source.Contains(typeFilter, StringComparison.OrdinalIgnoreCase)
            || import.Format.Contains(typeFilter, StringComparison.OrdinalIgnoreCase)
            || import.File.Contains(typeFilter, StringComparison.OrdinalIgnoreCase);

        if (!typeMatches)
        {
            return false;
        }

        if (string.IsNullOrWhiteSpace(textFilter))
        {
            return true;
        }

        return import.File.Contains(textFilter, StringComparison.OrdinalIgnoreCase)
            || import.Source.Contains(textFilter, StringComparison.OrdinalIgnoreCase)
            || import.Format.Contains(textFilter, StringComparison.OrdinalIgnoreCase)
            || import.Status.Contains(textFilter, StringComparison.OrdinalIgnoreCase);
    }

    // Applies the database text filter to processed file and model storage rows.
    private bool FilterProcessedFile(object item)
    {
        if (item is not ProcessedFile file)
        {
            return false;
        }

        var textFilter = SearchFilterText(FileNameFilterBox);

        if (string.IsNullOrWhiteSpace(textFilter))
        {
            return true;
        }

        return file.File.Contains(textFilter, StringComparison.OrdinalIgnoreCase)
            || file.Type.Contains(textFilter, StringComparison.OrdinalIgnoreCase)
            || file.Feeds.Contains(textFilter, StringComparison.OrdinalIgnoreCase)
            || file.Status.Contains(textFilter, StringComparison.OrdinalIgnoreCase);
    }

    // Refreshes the collection views behind the source and processed storage grids.
    private void RefreshFileFilters()
    {
        _importsView.Refresh();
        _processedFilesView.Refresh();
        RefreshWorkingDirectoryStorage();
    }

    // Opens the currently previewed database file or folder using the Windows shell.
    private void OpenSelectedDatabaseFile()
    {
        var path = ResolvePreviewPath(_lastPreviewedStoragePath);

        if (string.IsNullOrWhiteSpace(path) || (!File.Exists(path) && !Directory.Exists(path)))
        {
            SetStatus("Select a storage row with an existing local file first");
            return;
        }

        Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        SetStatus($"Opened {Path.GetFileName(path)}");
    }

    // Tracks the selected storage row for open, activate, rename, lock, and delete actions.
    private void PreviewDatabaseFile(object? selectedItem)
    {
        switch (selectedItem)
        {
            case StagedImport import:
                _lastPreviewedStorageItem = import;
                _lastPreviewedStoragePath = import.Path;
                SetStatus($"Selected {import.File}");
                break;
            case ProcessedFile file:
                _lastPreviewedStorageItem = file;
                _lastPreviewedStoragePath = file.Path;
                SetStatus($"Selected {file.File}");
                break;
            case ReportRow report:
                _lastPreviewedStorageItem = report;
                _lastPreviewedStoragePath = report.Path;
                SetStatus($"Selected {report.Report}");
                break;
            case OptimizationAlgorithmRecord algorithm:
                _lastPreviewedStorageItem = algorithm;
                _lastPreviewedStoragePath = algorithm.Path;
                SetStatus($"Selected algorithm file: {algorithm.Name}");
                break;
        }
    }

    // Routes report-grid selection changes through the shared database preview panel.
    private void PreviewSelectedReport()
    {
        if (ReportsGrid.SelectedItem is not ReportRow report)
        {
            return;
        }

        PreviewDatabaseFile(report);
        SetStatus($"Report type selected: {report.Report}");
    }

    // Keeps old report-file preview actions from opening removed processed-file report previews.
    private void PreviewSelectedReportFile()
    {
        SetStatus("Processed file previews were removed from Reports");
    }

    // Resolves stored relative paths against both the published output and source checkout layouts.
    private static string ResolvePreviewPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return "";
        }

        if (Path.IsPathRooted(path))
        {
            return path;
        }

        var outputPath = Path.Combine(AppContext.BaseDirectory, path.Replace('/', Path.DirectorySeparatorChar));
        if (File.Exists(outputPath) || Directory.Exists(outputPath))
        {
            return outputPath;
        }

        return Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", path.Replace('/', Path.DirectorySeparatorChar)));
    }

    // Kept for compatibility with older event wiring; file preview is no longer shown.
    private void ExpandDatabasePreview()
    {
        SetStatus("File preview has been removed; use right-click Open file");
    }

    // Kept for compatibility with older event wiring; file preview is no longer shown.
    private void ShowCompactDatabasePreview()
    {
    }

    // Reloads source, processed, and model storage rows for the current account/project selection.
    private void ReloadProjectStorage()
    {
        _imports.Clear();
        _selectedProcessingFiles.Clear();
        LoadProcessedData();
        LoadProjectStorageMetadata();
        RefreshFileFilters();
        RefreshSelectedProcessingFilesFromActiveSources();
        ImportsGrid.Items.Refresh();
        ProcessedFilesGrid.Items.Refresh();
        ProjectModelStorageGrid.Items.Refresh();
        WorkingDirectoryGrid.Items.Refresh();
        BuildMenuGrid.Items.Refresh();
        OutageDataGrid.Items.Refresh();
        SavedReportsGrid.Items.Refresh();
    }

    // Merges persisted per-project source and processed file metadata into the current grids.
    private void LoadProjectStorageMetadata()
    {
        if (_workspaceStore.CurrentAccount(_workspaceState).Id.Equals("guest", StringComparison.OrdinalIgnoreCase))
        {
            AddExampleSourceRows();
            LoadBuiltModelStorage();
            return;
        }

        var project = _workspaceStore.CurrentProject(_workspaceState);
        foreach (var sourceFile in project.SourceFiles)
        {
            sourceFile.Status = "Source file";
            if (_imports.All(current => !string.Equals(current.Path, sourceFile.Path, StringComparison.OrdinalIgnoreCase)))
            {
                _imports.Add(sourceFile);
            }
        }

        foreach (var processedFile in project.ProcessedFiles)
        {
            AddOrReplaceProcessedFile(processedFile);
        }

        LoadBuiltModelStorage();
    }

    // Adds source-file examples that can later be processed by PowerFactory/ETAP adapters.
    private void AddExampleSourceRows()
    {
        var uploaded = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
        foreach (var example in new[]
                 {
                     ("example-powerfactory-model.pfd", "Model", "PowerFactory"),
                     ("example-etap-model.oti", "Model", "ETAP"),
                 })
        {
            if (_imports.Any(import => import.File.Equals(example.Item1, StringComparison.OrdinalIgnoreCase)))
            {
                continue;
            }

            _imports.Add(new StagedImport
            {
                Active = false,
                File = example.Item1,
                Source = example.Item2,
                Format = example.Item3,
                Size = "Example",
                Imported = uploaded,
                Status = "Source file",
                Label = "Example",
                Path = "",
            });
        }
    }

    // Persists current source and processed storage metadata into the active project record.
    private void SaveProjectStorageMetadata()
    {
        var project = _workspaceStore.CurrentProject(_workspaceState);
        project.SourceFiles = _imports.ToList();
        foreach (var sourceFile in project.SourceFiles)
        {
            sourceFile.Status = "Source file";
        }

        project.ProcessedFiles = _processedFiles
            .Where(file => file.Status.Equals("Processed", StringComparison.OrdinalIgnoreCase)
                || file.Status.Equals("Built", StringComparison.OrdinalIgnoreCase)
                || file.Status.Equals("Active", StringComparison.OrdinalIgnoreCase)
                || file.Status.Equals("Saved", StringComparison.OrdinalIgnoreCase))
            .Where(file => !file.Status.Equals("Example", StringComparison.OrdinalIgnoreCase))
            .ToList();
        project.UpdatedAt = DateTime.UtcNow;
        _workspaceStore.Save(_workspaceState);
    }

    // Activates the selected storage row in one click.
    private void ActivateSelectedStorageItem()
    {
        var item = CurrentStorageItem();
        switch (item)
        {
            case ProcessedFile file when _builtModels.Contains(file):
                ActivateBuiltModel(file);
                break;
            case ProcessedFile file:
                file.Active = true;
                ProcessedFilesGrid.Items.Refresh();
                SaveProjectStorageMetadata();
                RefreshWorkingDirectoryStorage();
                SetStatus($"Activated processed file: {file.File}");
                break;
            case StagedImport import:
                import.Active = true;
                ImportsGrid.Items.Refresh();
                SaveProjectStorageMetadata();
                RefreshWorkingDirectoryStorage();
                SetStatus($"Activated source file: {import.File}");
                break;
            default:
                SetStatus("Select a source, processed, or model row to activate");
                break;
        }
    }

    // Makes the selected built model active for map and optimization workflows.
    private void ActivateBuiltModel(ProcessedFile file)
    {
        var modelId = Path.GetFileNameWithoutExtension(file.File);
        var project = _workspaceStore.CurrentProject(_workspaceState);
        project.Settings.ActiveModelId = modelId;
        project.UpdatedAt = DateTime.UtcNow;
        _workspaceStore.Save(_workspaceState);
        LoadBuiltModelStorage();
        SelectComboContent(MapModelCombo, $"{modelId} model layer");
        SelectComboContent(HeaderModelCombo, modelId);
        CenterMapOnSelectedModel();
        RenderMap();
        SetStatus($"Activated model: {modelId}");
    }

    // Renames the selected project-storage file or model file.
    private void RenameSelectedStorageItem()
    {
        var item = CurrentStorageItem();
        if (item is null)
        {
            SetStatus("Select a storage row to rename");
            return;
        }

        if (IsStorageLocked(item))
        {
            SetStatus("Unlock this row before renaming it");
            return;
        }

        var currentName = StorageDisplayName(item);
        var newName = PromptForText("Rename storage item", "New name", currentName);
        if (string.IsNullOrWhiteSpace(newName) || string.Equals(newName, currentName, StringComparison.Ordinal))
        {
            return;
        }

        switch (item)
        {
            case ProcessedFile file when _builtModels.Contains(file):
                RenameBuiltModel(file, newName);
                break;
            case ProcessedFile file:
                RenameStorageFile(file, newName);
                ProcessedFilesGrid.Items.Refresh();
                SaveProjectStorageMetadata();
                break;
            case StagedImport import:
                RenameStorageFile(import, newName);
                ImportsGrid.Items.Refresh();
                SaveProjectStorageMetadata();
                break;
            case ReportRow report:
                RenameStorageFile(report, newName);
                break;
        }
    }

    // Toggles the locked flag and read-only file attribute for the selected storage row.
    private void ToggleSelectedStorageLock()
    {
        var item = CurrentStorageItem();
        if (item is null)
        {
            SetStatus("Select a storage row to lock or unlock");
            return;
        }

        var locked = !IsStorageLocked(item);
        SetStorageLocked(item, locked);
        SetReadOnlyAttribute(StoragePath(item), locked);
        RefreshStorageGrids();
        SaveProjectStorageMetadata();
        SetStatus(locked ? "Storage row locked" : "Storage row unlocked");
    }

    // Permanently deletes the selected unlocked workspace file and removes its storage row.
    private void DeleteSelectedStorageItem()
    {
        var item = CurrentStorageItem();
        if (item is null)
        {
            SetStatus("Select a storage row to delete");
            return;
        }

        if (IsStorageLocked(item))
        {
            SetStatus("Unlock this row before deleting it");
            return;
        }

        var path = ResolvePreviewPath(StoragePath(item));
        if (!IsWorkspacePath(path))
        {
            SetStatus("Only files inside the ROA workspace can be permanently deleted from here");
            return;
        }

        var name = StorageDisplayName(item);
        var choice = MessageBox.Show(
            this,
            $"Permanently delete '{name}' from disk and remove it from storage?",
            "Delete Storage File",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);
        if (choice != MessageBoxResult.Yes)
        {
            return;
        }

        if (Directory.Exists(path))
        {
            Directory.Delete(path, recursive: true);
        }
        else if (File.Exists(path))
        {
            File.Delete(path);
        }

        RemoveStorageRow(item);
        SaveProjectStorageMetadata();
        LoadBuiltModelStorage();
        RefreshStorageGrids();
        _lastPreviewedStorageItem = null;
        _lastPreviewedStoragePath = "";
        SetStatus($"Deleted {name}");
    }

    private object? CurrentStorageItem()
    {
        return ProjectModelStorageGrid.SelectedItem
            ?? WorkingDirectoryGrid.SelectedItem
            ?? BuildMenuGrid.SelectedItem
            ?? ProcessedFilesGrid.SelectedItem
            ?? ImportsGrid.SelectedItem
            ?? _lastPreviewedStorageItem;
    }

    // Selects the row under the pointer before a storage context menu opens.
    private void SelectStorageRowOnRightClick(object sender, MouseButtonEventArgs e)
    {
        if (sender is not DataGrid grid)
        {
            return;
        }

        var dependencyObject = e.OriginalSource as DependencyObject;
        while (dependencyObject is not null and not DataGridRow)
        {
            dependencyObject = VisualTreeHelper.GetParent(dependencyObject);
        }

        if (dependencyObject is DataGridRow row)
        {
            row.IsSelected = true;
            grid.SelectedItem = row.Item;
            PreviewDatabaseFile(row.Item);
        }
    }

    private string StorageDisplayName(object item)
    {
        return item switch
        {
            StagedImport import => import.File,
            ProcessedFile file => file.File,
            ReportRow report => report.Report,
            _ => "",
        };
    }

    private string StoragePath(object item)
    {
        return item switch
        {
            StagedImport import => import.Path,
            ProcessedFile file => file.Path,
            ReportRow report => report.Path,
            _ => "",
        };
    }

    private bool IsStorageLocked(object item)
    {
        return item switch
        {
            StagedImport import => import.Locked,
            ProcessedFile file => file.Locked || IsReadOnlyFile(file.Path),
            ReportRow report => report.Locked || IsReadOnlyFile(report.Path),
            _ => false,
        };
    }

    private void SetStorageLocked(object item, bool locked)
    {
        switch (item)
        {
            case StagedImport import:
                import.Locked = locked;
                break;
            case ProcessedFile file:
                file.Locked = locked;
                break;
            case ReportRow report:
                report.Locked = locked;
                break;
        }
    }

    private static bool IsReadOnlyFile(string path)
    {
        var resolved = ResolvePreviewPath(path);
        return File.Exists(resolved) && File.GetAttributes(resolved).HasFlag(FileAttributes.ReadOnly);
    }

    private static void SetReadOnlyAttribute(string path, bool readOnly)
    {
        var resolved = ResolvePreviewPath(path);
        if (!File.Exists(resolved))
        {
            return;
        }

        var attributes = File.GetAttributes(resolved);
        File.SetAttributes(resolved, readOnly ? attributes | FileAttributes.ReadOnly : attributes & ~FileAttributes.ReadOnly);
    }

    private bool IsWorkspacePath(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return false;
        }

        var fullPath = Path.GetFullPath(path);
        var workspaceRoot = Path.GetFullPath(_workspaceStore.RootPath);
        return fullPath.StartsWith(workspaceRoot, StringComparison.OrdinalIgnoreCase);
    }

    private void RenameStorageFile(ProcessedFile file, string newName)
    {
        var oldPath = ResolvePreviewPath(file.Path);
        if (TryMoveWorkspaceItem(oldPath, newName, out var newPath))
        {
            file.Path = newPath;
        }

        file.File = Path.GetFileName(newPath);
        SetStatus($"Renamed file to {file.File}");
    }

    private void RenameStorageFile(StagedImport import, string newName)
    {
        var oldPath = ResolvePreviewPath(import.Path);
        if (TryMoveWorkspaceItem(oldPath, newName, out var newPath))
        {
            import.Path = newPath;
        }

        import.File = Path.GetFileName(newPath);
        SetStatus($"Renamed file to {import.File}");
    }

    private void RenameStorageFile(ReportRow report, string newName)
    {
        var oldPath = ResolvePreviewPath(report.Path);
        if (TryMoveWorkspaceItem(oldPath, newName, out var newPath))
        {
            report.Path = newPath;
        }

        report.Report = Path.GetFileName(newPath);
        SetStatus($"Renamed output to {report.Report}");
    }

    private void RenameBuiltModel(ProcessedFile file, string newName)
    {
        var oldPath = ResolvePreviewPath(file.Path);
        if (!IsWorkspacePath(oldPath) || !File.Exists(oldPath))
        {
            SetStatus("Only saved project model files can be renamed");
            return;
        }

        var newId = SafeFileStem(newName);
        var newPath = Path.Combine(Path.GetDirectoryName(oldPath)!, $"{newId}.json");
        if (File.Exists(newPath))
        {
            SetStatus("A model with that name already exists");
            return;
        }

        var model = JsonSerializer.Deserialize<BuiltModelRecord>(File.ReadAllText(oldPath), _jsonOptions);
        if (model is not null)
        {
            model.Id = newId;
            model.Name = newName.Trim();
            File.WriteAllText(oldPath, JsonSerializer.Serialize(model, _jsonOptions));
        }

        File.Move(oldPath, newPath);
        var project = _workspaceStore.CurrentProject(_workspaceState);
        if (Path.GetFileNameWithoutExtension(file.File).Equals(project.Settings.ActiveModelId, StringComparison.OrdinalIgnoreCase))
        {
            project.Settings.ActiveModelId = newId;
            _workspaceStore.Save(_workspaceState);
        }

        LoadBuiltModelStorage();
        SetStatus($"Renamed model to {newId}");
    }

    private bool TryMoveWorkspaceItem(string oldPath, string newName, out string newPath)
    {
        newPath = oldPath;
        if (!IsWorkspacePath(oldPath) || (!File.Exists(oldPath) && !Directory.Exists(oldPath)))
        {
            SetStatus("Only files inside the ROA workspace can be renamed from here");
            return false;
        }

        var extension = Directory.Exists(oldPath) ? "" : Path.GetExtension(oldPath);
        var requested = Path.GetFileName(newName.Trim());
        var finalName = string.IsNullOrWhiteSpace(Path.GetExtension(requested)) ? $"{requested}{extension}" : requested;
        finalName = string.Join("-", finalName.Split(Path.GetInvalidFileNameChars(), StringSplitOptions.RemoveEmptyEntries));
        newPath = Path.Combine(Path.GetDirectoryName(oldPath)!, finalName);
        if (File.Exists(newPath) || Directory.Exists(newPath))
        {
            SetStatus("A file with that name already exists");
            newPath = oldPath;
            return false;
        }

        if (Directory.Exists(oldPath))
        {
            Directory.Move(oldPath, newPath);
        }
        else
        {
            File.Move(oldPath, newPath);
        }

        return true;
    }

    private void RemoveStorageRow(object item)
    {
        switch (item)
        {
            case StagedImport import:
                _imports.Remove(import);
                break;
            case ProcessedFile file when _builtModels.Contains(file):
                _builtModels.Remove(file);
                break;
            case ProcessedFile file:
                _processedFiles.Remove(file);
                break;
            case ReportRow report:
                _reports.Remove(report);
                break;
        }
    }

    private void RefreshStorageGrids()
    {
        ImportsGrid.Items.Refresh();
        ProcessedFilesGrid.Items.Refresh();
        ProjectModelStorageGrid.Items.Refresh();
        WorkingDirectoryGrid.Items.Refresh();
        BuildMenuGrid.Items.Refresh();
        RefreshWorkingDirectoryStorage();
    }

    // Links the selected/available outage data file to the selected model and saves that project association.
    private void LinkOutagesToCurrentModel()
    {
        var model = LoadSelectedMapModel(SelectedMapModelPath());
        if (model is null)
        {
            SetStatus("Select or activate a project model before linking outage data");
            return;
        }

        var outage = OutageDataGrid.SelectedItem as ProcessedFile
            ?? _outageDataFiles.FirstOrDefault()
            ?? _processedFiles.FirstOrDefault(file => file.Feeds.Contains("Outage", StringComparison.OrdinalIgnoreCase)
                || file.File.Contains("outage", StringComparison.OrdinalIgnoreCase));
        if (outage is null)
        {
            SetStatus("No outage data file is available to link to the selected model");
            return;
        }

        var project = _workspaceStore.CurrentProject(_workspaceState);
        project.Settings.LinkedOutageFilePath = outage.Path;
        project.Settings.LinkedOutageModelId = model.Id;
        project.UpdatedAt = DateTime.UtcNow;
        _workspaceStore.Save(_workspaceState);
        RequestMapRender();
        SetStatus($"Linked {outage.File} to model {model.Id}");
    }

    private void RefreshWorkingDirectoryStorage()
    {
        _workingDirectoryFiles.Clear();
        _buildMenuFiles.Clear();
        _outageDataFiles.Clear();

        foreach (var file in _processedFiles)
        {
            _buildMenuFiles.Add(file);
        }

        foreach (var file in _processedFiles.Where(file => file.Active || file.Feeds.Contains("Outage", StringComparison.OrdinalIgnoreCase)))
        {
            _workingDirectoryFiles.Add(file);

            if (file.Feeds.Contains("Outage", StringComparison.OrdinalIgnoreCase)
                || file.File.Contains("outage", StringComparison.OrdinalIgnoreCase))
            {
                _outageDataFiles.Add(file);
            }
        }

        foreach (var model in _builtModels.Where(model => model.Status.Equals("Active", StringComparison.OrdinalIgnoreCase)))
        {
            _workingDirectoryFiles.Add(model);
        }
    }

    private static string SearchFilterText(TextBox box)
    {
        var value = box.Text?.Trim() ?? "";
        return value.Equals("Search...", StringComparison.OrdinalIgnoreCase) ? "" : value;
    }

    private static void ClearSearchPlaceholder(TextBox box)
    {
        if (box.Text.Equals("Search...", StringComparison.OrdinalIgnoreCase))
        {
            box.Text = "";
            box.Foreground = BrushFrom("#132033");
        }
    }

    private static void RestoreSearchPlaceholder(TextBox box)
    {
        if (string.IsNullOrWhiteSpace(box.Text))
        {
            box.Text = "Search...";
            box.Foreground = BrushFrom("#667287");
        }
    }

    private string PromptForText(string title, string label, string value)
    {
        var dialog = new Window
        {
            Owner = this,
            Title = title,
            Width = 420,
            Height = 160,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
        };
        var input = new TextBox { Text = value, Height = 30, Margin = new Thickness(0, 6, 0, 12) };
        var ok = new Button { Content = "Save", Width = 90, HorizontalAlignment = HorizontalAlignment.Right };
        ok.Click += (_, _) => dialog.DialogResult = true;
        var panel = new StackPanel { Margin = new Thickness(16) };
        panel.Children.Add(new TextBlock { Text = label });
        panel.Children.Add(input);
        panel.Children.Add(ok);
        dialog.Content = panel;
        input.SelectAll();
        return dialog.ShowDialog() == true ? input.Text : "";
    }

    private static string SafeFileStem(string value)
    {
        var stem = Path.GetFileNameWithoutExtension(value.Trim());
        var safe = string.Join("-", stem.Split(Path.GetInvalidFileNameChars(), StringSplitOptions.RemoveEmptyEntries)).Trim();
        return string.IsNullOrWhiteSpace(safe) ? $"model-{DateTime.UtcNow:yyyyMMdd-HHmmss}" : safe;
    }

}
