using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Map rendering, panning, tile caching, schematic areas, and map asset search.

    // Coalesces frequent pan, zoom, resize, and layer events into one redraw.
    private void RequestMapRender()
    {
        if (_isDragging)
        {
            return;
        }

        if (_mapRenderTimer.IsEnabled)
        {
            return;
        }

        _mapRenderTimer.Start();
    }

    // Resets the map camera to a New Zealand overview.
    private void CenterMap()
    {
        _centerLat = -41.2865;
        _centerLng = 174.7762;
        _zoom = 6;
        RenderMap();
        SetStatus("Map centered on New Zealand");
    }

    // Handles mouse-wheel zooming and redraws the current map view.
    private void MapHostOnMouseWheel(object sender, MouseWheelEventArgs e)
    {
        _zoom = e.Delta > 0 ? Math.Min(18, _zoom + 1) : Math.Max(3, _zoom - 1);
        RequestMapRender();
        e.Handled = true;
    }

    // Starts map dragging from the current mouse position.
    private void MapHostOnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        _isDragging = true;
        _dragStartPoint = e.GetPosition(MapHost);
        _lastDragPoint = _dragStartPoint;
        _mapDragTransform.X = 0;
        _mapDragTransform.Y = 0;
        MapHost.CaptureMouse();
    }

    // Stops map dragging when the left mouse button is released.
    private void MapHostOnMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        StopMapDrag();
    }

    // Stores the point used by context-menu coordinate actions.
    private void MapHostOnMouseRightButtonDown(object sender, MouseButtonEventArgs e)
    {
        _lastMapPoint = e.GetPosition(MapHost);
        _hasLastMapPoint = true;
    }

    // Ends an active drag operation and releases mouse capture.
    private void StopMapDrag()
    {
        if (!_isDragging)
        {
            return;
        }

        _isDragging = false;
        MapHost.ReleaseMouseCapture();
        _mapDragTransform.X = 0;
        _mapDragTransform.Y = 0;
        RenderMap();
    }

    // Updates coordinate readouts and pans the map while dragging.
    private void MapHostOnMouseMove(object sender, MouseEventArgs e)
    {
        UpdateMapMouseReadout(e.GetPosition(MapHost));

        if (!_isDragging)
        {
            return;
        }

        var point = e.GetPosition(MapHost);
        var dx = point.X - _lastDragPoint.X;
        var dy = point.Y - _lastDragPoint.Y;
        var scale = MapScale(_zoom);
        var centerX = WorldPixelX(_centerLng, _zoom) - dx;
        var centerY = Math.Clamp(WorldPixelY(_centerLat, _zoom) - dy, 0, scale);

        _centerLng = LongitudeFromWorldPixel(centerX, _zoom);
        _centerLat = Math.Clamp(LatitudeFromWorldPixel(centerY, _zoom), -85.0511, 85.0511);
        _mapDragTransform.X += dx;
        _mapDragTransform.Y += dy;
        _lastDragPoint = point;
    }

    // Converts the current mouse position to coordinates and updates the map readout.
    private void UpdateMapMouseReadout(Point point)
    {
        if (MapHost.ActualWidth < 10 || MapHost.ActualHeight < 10)
        {
            return;
        }

        var now = DateTime.UtcNow;
        if ((now - _lastMapReadoutUpdateUtc).TotalMilliseconds < 60)
        {
            return;
        }

        _lastMapReadoutUpdateUtc = now;
        _lastMapPoint = point;
        _hasLastMapPoint = true;
        var (latitude, longitude) = CoordinatesFromMapPoint(point);
        UpdateMapPointInformation(latitude, longitude);
    }

    // Converts a screen point on the map canvas into latitude and longitude.
    private (double Latitude, double Longitude) CoordinatesFromMapPoint(Point point)
    {
        var centerX = WorldPixelX(_centerLng, _zoom);
        var centerY = WorldPixelY(_centerLat, _zoom);
        var worldX = centerX - MapHost.ActualWidth / 2.0 + point.X;
        var worldY = centerY - MapHost.ActualHeight / 2.0 + point.Y;
        var longitude = LongitudeFromWorldPixel(worldX, _zoom);
        var latitude = LatitudeFromWorldPixel(worldY, _zoom);
        return (latitude, longitude);
    }

    // Opens an external map lookup for the supplied map-canvas point.
    private void OpenMapLookup(Point point)
    {
        var (latitude, longitude) = CoordinatesFromMapPoint(point);
        OpenCoordinatesInMaps(latitude, longitude);
        MapAddressText.Text = $"Address: opened online lookup for {latitude:N5}, {longitude:N5}.";
        SetStatus("Opened map address lookup");
    }

    // Opens an external map lookup for the last known map point or the map centre.
    private void OpenCurrentMapPoint()
    {
        var point = _hasLastMapPoint
            ? _lastMapPoint
            : new Point(MapHost.ActualWidth / 2.0, MapHost.ActualHeight / 2.0);
        OpenMapLookup(point);
    }

    // Copies the last known map coordinates, or the map centre, to the clipboard.
    private void CopyCurrentMapCoordinates()
    {
        var point = _hasLastMapPoint
            ? _lastMapPoint
            : new Point(MapHost.ActualWidth / 2.0, MapHost.ActualHeight / 2.0);
        var (latitude, longitude) = CoordinatesFromMapPoint(point);
        var text = string.Create(CultureInfo.InvariantCulture, $"{latitude:0.000000}, {longitude:0.000000}");
        Clipboard.SetText(text);
        SetStatus($"Copied coordinates {text}");
    }

    // Opens the supplied coordinates in Google Maps using the default browser.
    private void OpenCoordinatesInMaps(double latitude, double longitude)
    {
        var query = string.Create(CultureInfo.InvariantCulture, $"{latitude:0.000000},{longitude:0.000000}");
        var url = $"https://www.google.com/maps/search/?api=1&query={query}";

        Process.Start(new ProcessStartInfo(url)
        {
            UseShellExecute = true,
        });
    }

    // Formats the current height/elevation readout based on layer availability.
    private string HeightReadout()
    {
        return LayerHeightToggle.IsChecked == true
            ? "Height DEM not loaded"
            : "Height -- m";
    }

    private void UpdateMapPointInformation(double latitude, double longitude)
    {
        var nearest = NearestModelNode(latitude, longitude);
        MapCoordinateText.Text = $"Latitude {latitude:N5}, Longitude {longitude:N5}, Zoom {_zoom}.";
        MapHeightText.Text = nearest.Node is not null
            ? $"Height from sea level: {nearest.Node.ElevationM:N0} m from nearest model node {nearest.Node.Id} ({nearest.DistanceM:N0} m away)."
            : "Height from sea level: no DEM/model elevation found at this point.";
        MapAddressText.Text = $"Address: use right-click > Search on Google Maps for {latitude:N5}, {longitude:N5}.";
        MapPointAssetText.Text = nearest.Node is not null
            ? $"Nearest asset: {nearest.Node.Id}, {nearest.Node.Type}, feeder {nearest.Node.FeederId}."
            : $"Nearest asset: none. Active layers: {_activeLayer}, {_activeBaseLayer}.";
    }

    private (CartesianNodeRecord? Node, double DistanceM) NearestModelNode(double latitude, double longitude)
    {
        var modelPath = SelectedMapModelPath();
        if (string.IsNullOrWhiteSpace(modelPath) || !File.Exists(modelPath))
        {
            return (null, 0);
        }

        var model = LoadSelectedMapModel(modelPath);
        if (model is null || model.CartesianMap.Nodes.Count == 0)
        {
            return (null, 0);
        }

        CartesianNodeRecord? nearest = null;
        var best = double.MaxValue;
        foreach (var node in model.CartesianMap.Nodes)
        {
            var distance = ApproxDistanceMetres(latitude, longitude, node.Latitude, node.Longitude);
            if (distance < best)
            {
                best = distance;
                nearest = node;
            }
        }

        return best <= 2000 ? (nearest, best) : (null, best);
    }

    // Clears and redraws the base map, selected model overlay, active layers, and render errors.
    private void RenderMap()
    {
        if (MapHost.ActualWidth < 10 || MapHost.ActualHeight < 10)
        {
            return;
        }

        TileCanvas.Children.Clear();
        ClearMapRenderErrors();

        DrawOfflineMap();

        var onlineMode = _activeLayer.Equals("Online mode", StringComparison.OrdinalIgnoreCase);
        var drewBaseTiles = DrawBaseTiles(_activeBaseLayer, allowDownload: onlineMode, opacity: 1.0);
        MapAttribution.Text = drewBaseTiles
            ? $"{_activeLayer}: {_activeBaseLayer} layer shown"
            : $"{_activeLayer}: showing saved complete map until {_activeBaseLayer.ToLowerInvariant()} tiles are cached";
        if (LayerHeightToggle.IsChecked == true)
        {
            DrawHeightHeatMap();
        }

        UpdateMapPointInformation(_centerLat, _centerLng);
        if (OverlayToggle.IsChecked == true)
        {
            DrawSelectedModelLayer();
        }

        if (LayerOutagesToggle.IsChecked == true)
        {
            DrawLinkedOutageLayer();
        }

        if (LayerDataErrorsToggle.IsChecked == true)
        {
            DrawDataQualityErrorLayer();
        }

        DrawActiveLayers();
    }

    // Draws cached or downloadable map tiles for the selected base layer.
    private bool DrawBaseTiles(string layer, bool allowDownload, double opacity)
    {
        const double tileSize = 256.0;
        var tileCount = (int)Math.Pow(2, _zoom);
        var centerX = WorldPixelX(_centerLng, _zoom);
        var centerY = WorldPixelY(_centerLat, _zoom);
        var left = centerX - MapHost.ActualWidth / 2.0;
        var top = centerY - MapHost.ActualHeight / 2.0;
        var startTileX = (int)Math.Floor(left / tileSize);
        var endTileX = (int)Math.Floor((left + MapHost.ActualWidth) / tileSize);
        var startTileY = (int)Math.Floor(top / tileSize);
        var endTileY = (int)Math.Floor((top + MapHost.ActualHeight) / tileSize);
        var drewAny = false;

        for (var tx = startTileX; tx <= endTileX; tx++)
        {
            for (var ty = startTileY; ty <= endTileY; ty++)
            {
                if (ty < 0 || ty >= tileCount)
                {
                    continue;
                }

                var wrappedX = ((tx % tileCount) + tileCount) % tileCount;
                var cachedTilePath = allowDownload
                    ? GetOrDownloadTile(layer, wrappedX, ty, _zoom)
                    : TileCachePath(layer, wrappedX, ty, _zoom);
                if (cachedTilePath is null || !File.Exists(cachedTilePath))
                {
                    continue;
                }

                var image = new Image
                {
                    Width = tileSize,
                    Height = tileSize,
                    Stretch = Stretch.Fill,
                    Opacity = opacity,
                    Source = TileBitmapForPath(cachedTilePath),
                };

                Canvas.SetLeft(image, tx * tileSize - left);
                Canvas.SetTop(image, ty * tileSize - top);
                TileCanvas.Children.Add(image);
                drewAny = true;
            }
        }

        return drewAny;
    }

    // Draws the saved/current-project map fallback when online tiles are unavailable.
    private void DrawOfflineMap()
    {
        var width = MapHost.ActualWidth;
        var height = MapHost.ActualHeight;
        TileCanvas.Children.Add(new System.Windows.Shapes.Rectangle
        {
            Width = width,
            Height = height,
            Fill = BrushFrom("#E6EDF4"),
        });

        for (var x = 0.0; x < width; x += 64)
        {
            TileCanvas.Children.Add(new System.Windows.Shapes.Line { X1 = x, Y1 = 0, X2 = x, Y2 = height, Stroke = BrushFrom("#D3DEE9"), StrokeThickness = 1 });
        }

        for (var y = 0.0; y < height; y += 64)
        {
            TileCanvas.Children.Add(new System.Windows.Shapes.Line { X1 = 0, Y1 = y, X2 = width, Y2 = y, Stroke = BrushFrom("#D3DEE9"), StrokeThickness = 1 });
        }

    }

    // Placeholder for future selectable map overlays that can be drawn above the base map.
    private bool DrawSelectedMapOverlays(bool allowDownload)
    {
        return false;
    }

    // Draws a mostly opaque elevation heat layer from model node elevations until a DEM raster is imported.
    private void DrawHeightHeatMap()
    {
        var model = LoadSelectedMapModel(SelectedMapModelPath());
        var elevationNodes = model?.CartesianMap.Nodes
            .Where(node => Math.Abs(node.Latitude) > 0.001 || Math.Abs(node.Longitude) > 0.001)
            .Where(node => node.ElevationM > 0)
            .ToList() ?? new List<CartesianNodeRecord>();

        var rows = 8;
        var columns = 12;
        var cellWidth = Math.Max(1, MapHost.ActualWidth / columns);
        var cellHeight = Math.Max(1, MapHost.ActualHeight / rows);
        var minElevation = elevationNodes.Count > 0 ? elevationNodes.Min(node => node.ElevationM) : 0;
        var maxElevation = elevationNodes.Count > 0 ? elevationNodes.Max(node => node.ElevationM) : 900;
        var range = Math.Max(1, maxElevation - minElevation);

        for (var row = 0; row < rows; row++)
        {
            for (var column = 0; column < columns; column++)
            {
                var center = new Point(column * cellWidth + cellWidth / 2, row * cellHeight + cellHeight / 2);
                var elevation = elevationNodes.Count > 0
                    ? NearestElevationFromNodes(center, elevationNodes)
                    : minElevation + range * (1.0 - row / (double)Math.Max(1, rows - 1));
                var normalized = Math.Clamp((elevation - minElevation) / range, 0, 1);

                var cell = new System.Windows.Shapes.Rectangle
                {
                    Width = cellWidth + 1,
                    Height = cellHeight + 1,
                    Fill = TerrainHeatBrush(normalized),
                    Opacity = 0.58,
                    IsHitTestVisible = false,
                };

                Canvas.SetLeft(cell, column * cellWidth);
                Canvas.SetTop(cell, row * cellHeight);
                TileCanvas.Children.Add(cell);
            }
        }

        AddMapRenderError(elevationNodes.Count > 0
            ? "Height heatmap is using model node elevations. Import a DEM layer later for full terrain precision."
            : "Height heatmap is schematic because no DEM/model elevations are loaded.");
    }

    // Samples the nearest visible model node elevation for a heatmap cell.
    private double NearestElevationFromNodes(Point point, List<CartesianNodeRecord> nodes)
    {
        var bestDistance = double.MaxValue;
        var elevation = nodes[0].ElevationM;
        foreach (var node in nodes)
        {
            var nodePoint = MapPointFromLatLng(node.Latitude, node.Longitude);
            var dx = nodePoint.X - point.X;
            var dy = nodePoint.Y - point.Y;
            var distance = dx * dx + dy * dy;
            if (distance < bestDistance)
            {
                bestDistance = distance;
                elevation = node.ElevationM;
            }
        }

        return elevation;
    }

    // Converts a normalized terrain height into green-yellow-brown heat colors.
    private static Brush TerrainHeatBrush(double normalized)
    {
        normalized = Math.Clamp(normalized, 0, 1);
        byte red;
        byte green;
        byte blue;
        if (normalized < 0.45)
        {
            var t = normalized / 0.45;
            red = (byte)(55 + 105 * t);
            green = (byte)(126 + 80 * t);
            blue = (byte)(78 - 35 * t);
        }
        else
        {
            var t = (normalized - 0.45) / 0.55;
            red = (byte)(160 + 65 * t);
            green = (byte)(206 - 95 * t);
            blue = (byte)(43 - 25 * t);
        }

        return new SolidColorBrush(Color.FromArgb(210, red, green, blue));
    }

    // Downloads and stores visible base-layer tiles for the current map view.
    private void CacheSelectedMapOverlays()
    {
        var drewAny = DrawBaseTiles(_activeBaseLayer, allowDownload: true, opacity: 1.0);
        SetStatus(drewAny
            ? $"{_activeBaseLayer} tiles cached for the current view"
            : $"No {_activeBaseLayer.ToLowerInvariant()} tiles were available to cache for the current view");
    }

    // Draws a semi-transparent tile overlay above the current base layer.
    private bool DrawTileOverlay(string layer, double opacity, bool allowDownload)
    {
        const double tileSize = 256.0;
        var tileCount = (int)Math.Pow(2, _zoom);
        var centerX = WorldPixelX(_centerLng, _zoom);
        var centerY = WorldPixelY(_centerLat, _zoom);
        var left = centerX - MapHost.ActualWidth / 2.0;
        var top = centerY - MapHost.ActualHeight / 2.0;
        var startTileX = (int)Math.Floor(left / tileSize);
        var endTileX = (int)Math.Floor((left + MapHost.ActualWidth) / tileSize);
        var startTileY = (int)Math.Floor(top / tileSize);
        var endTileY = (int)Math.Floor((top + MapHost.ActualHeight) / tileSize);
        var drewAny = false;

        for (var tx = startTileX; tx <= endTileX; tx++)
        {
            for (var ty = startTileY; ty <= endTileY; ty++)
            {
                if (ty < 0 || ty >= tileCount)
                {
                    continue;
                }

                var wrappedX = ((tx % tileCount) + tileCount) % tileCount;
                var cachedTilePath = allowDownload
                    ? GetOrDownloadTile(layer, wrappedX, ty, _zoom)
                    : TileCachePath(layer, wrappedX, ty, _zoom);
                if (cachedTilePath is null || !File.Exists(cachedTilePath))
                {
                    continue;
                }

                var image = new Image
                {
                    Width = tileSize,
                    Height = tileSize,
                    Stretch = Stretch.Fill,
                    Opacity = opacity,
                    Source = TileBitmapForPath(cachedTilePath),
                };

                Canvas.SetLeft(image, tx * tileSize - left);
                Canvas.SetTop(image, ty * tileSize - top);
                TileCanvas.Children.Add(image);
                drewAny = true;
            }
        }

        return drewAny;
    }

    // Summarizes the enabled map layers in the map information panel.
    private void DrawActiveLayers()
    {
        var activeLayers = new List<string>();
        activeLayers.Add($"{_activeLayer}: {_activeBaseLayer}");
        if (LayerTopologyToggle.IsChecked == true) activeLayers.Add("topology");
        if (LayerModelLinesToggle.IsChecked == true) activeLayers.Add("model lines");
        if (LayerModelNodesToggle.IsChecked == true) activeLayers.Add("model nodes");
        if (LayerModelSubstationsToggle.IsChecked == true) activeLayers.Add("zone substations");
        if (LayerModel11KvToggle.IsChecked == true) activeLayers.Add("11 kV");
        if (LayerModel33KvToggle.IsChecked == true) activeLayers.Add("33 kV");
        if (LayerModelLoadsToggle.IsChecked == true) activeLayers.Add("loads");
        if (LayerModelTransformersToggle.IsChecked == true) activeLayers.Add("transformers");
        if (LayerModelSwitchesToggle.IsChecked == true) activeLayers.Add("switches");
        if (LayerModelProtectionToggle.IsChecked == true) activeLayers.Add("protection/reclosers");
        if (LayerOutagesToggle.IsChecked == true) activeLayers.Add("outages");
        if (LayerDataErrorsToggle.IsChecked == true) activeLayers.Add("data errors");
        if (LayerLinzParcelsToggle.IsChecked == true) activeLayers.Add("LINZ parcels");
        if (LayerLinzAddressesToggle.IsChecked == true) activeLayers.Add("LINZ addresses");
        if (LayerHeightToggle.IsChecked == true) activeLayers.Add("height/DEM");
        if (OverlayToggle.IsChecked == true) activeLayers.Add($"model layer: {SelectedComboText(HeaderModelCombo)}");

        MapInfoText.Text = activeLayers.Count == 0
            ? "No overlays selected. Click the map to open an address lookup."
            : $"Active layers: {string.Join(", ", activeLayers)}. Model files are selectable map layers. Height requires an imported DEM/elevation layer.";
    }

    // Draws a label for future LINZ overlay annotations.
    private void DrawLinzLabel(string text, double x, double y)
    {
        var label = new TextBlock
        {
            Text = text,
            Foreground = BrushFrom("#7C5C00"),
            FontSize = 12,
            FontWeight = FontWeights.SemiBold,
        };
        Canvas.SetLeft(label, x);
        Canvas.SetTop(label, y);
        TileCanvas.Children.Add(label);
    }

    // Reserved hook for restoring study-area topology once the model overlay path is settled.
    private void DrawStudyOverlay()
    {
        // Topology drawing is intentionally disabled until the map/model pass.
    }

    // Draws a dashed schematic branch for manual or placeholder topology views.
    private void DrawBranch(Point from, Point to, string color)
    {
        TileCanvas.Children.Add(new System.Windows.Shapes.Line
        {
            X1 = from.X,
            Y1 = from.Y,
            X2 = to.X,
            Y2 = to.Y,
            Stroke = BrushFrom(color),
            StrokeThickness = 3,
            StrokeDashArray = new DoubleCollection { 5, 4 },
        });
    }

    // Draws a circular schematic zone marker on the map canvas.
    private void DrawZone(double x, double y, double diameter, string color)
    {
        var ellipse = new System.Windows.Shapes.Ellipse
        {
            Width = diameter,
            Height = diameter,
            Fill = BrushFrom(color),
            Stroke = BrushFrom("#FFFFFF"),
            StrokeThickness = 1,
        };
        Canvas.SetLeft(ellipse, x - diameter / 2);
        Canvas.SetTop(ellipse, y - diameter / 2);
        TileCanvas.Children.Add(ellipse);
    }

    // Draws an interactive map asset marker and wires its click behavior.
    private void DrawMarker(double x, double y, string color, string label)
    {
        var button = new Button
        {
            Width = 34,
            Height = 34,
            Content = label,
            FontSize = 11,
            FontWeight = FontWeights.SemiBold,
            Foreground = Brushes.White,
            Background = BrushFrom(color),
            BorderBrush = Brushes.White,
            ToolTip = $"Asset {label}",
        };

        button.Click += (_, _) =>
        {
            MapInfoText.Text = SelectedComboText(MapModeCombo).Contains("Optimization", StringComparison.OrdinalIgnoreCase)
                ? $"{label}: candidate grade loaded. Expected SAIDI 128.7, SAIFI 1.48, calculation error +/- 7.5%."
                : $"{label}: recloser candidate on the active study model. Source layers: GIS, PowerFactory and protection settings.";
            SetStatus($"Selected map asset {label}");
        };

        Canvas.SetLeft(button, x - button.Width / 2);
        Canvas.SetTop(button, y - button.Height / 2);
        TileCanvas.Children.Add(button);
    }

    // Returns a cached tile path and queues a background download when it is missing.
    private string? GetOrDownloadTile(string layer, int x, int y, int zoom)
    {
        var tilePath = TileCachePath(layer, x, y, zoom);
        if (File.Exists(tilePath))
        {
            return tilePath;
        }

        QueueTileDownload(layer, x, y, zoom, tilePath);
        return null;
    }

    // Downloads one missing tile off the UI thread and asks the map to refresh when ready.
    private void QueueTileDownload(string layer, int x, int y, int zoom, string tilePath)
    {
        if (!_pendingTileDownloads.Add(tilePath))
        {
            return;
        }

        _ = System.Threading.Tasks.Task.Run(async () =>
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(tilePath)!);
                var bytes = await _tileHttpClient.GetByteArrayAsync(TileUrl(layer, x, y, zoom));
                await File.WriteAllBytesAsync(tilePath, bytes);
            }
            catch
            {
                // Tile servers can be offline or rate-limited; the saved map remains visible underneath.
            }
            finally
            {
                _ = Dispatcher.BeginInvoke(() =>
                {
                    _pendingTileDownloads.Remove(tilePath);
                    _tileBitmapCache.Remove(tilePath);
                    RequestMapRender();
                }, DispatcherPriority.Background);
            }
        });
    }

    // Reuses decoded tile bitmaps so panning does not keep reloading the same files.
    private BitmapImage? TileBitmapForPath(string path)
    {
        if (_tileBitmapCache.TryGetValue(path, out var bitmap))
        {
            return bitmap;
        }

        bitmap = CreateTileBitmap(path);
        _tileBitmapCache[path] = bitmap;
        return bitmap;
    }

    // Builds the local cache path for a map tile coordinate.
    private string TileCachePath(string layer, int x, int y, int zoom)
    {
        var layerFolder = layer.Replace(" ", "-").Replace("/", "-");
        return Path.Combine(_tileCacheRoot, layerFolder, zoom.ToString(), x.ToString(), $"{y}.png");
    }

    // Loads a cached tile image without keeping the file locked.
    private static BitmapImage? CreateTileBitmap(string path)
    {
        try
        {
            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri(path, UriKind.Absolute);
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
            bitmap.EndInit();
            return bitmap;
        }
        catch
        {
            return null;
        }
    }

    // Builds the online tile URL for map, satellite, or topographic layers.
    private static string TileUrl(string layer, int x, int y, int zoom)
    {
        var subdomains = new[] { "a", "b", "c" };
        var sub = subdomains[(x + y) % subdomains.Length];

        return layer switch
        {
            "Topography" => $"https://{sub}.tile.opentopomap.org/{zoom}/{x}/{y}.png",
            "Satellite" => $"https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{zoom}/{y}/{x}",
            _ => $"https://{sub}.tile.openstreetmap.org/{zoom}/{x}/{y}.png",
        };
    }

    // Returns the Web Mercator world size in pixels for a zoom level.
    private static double MapScale(int zoom) => 256.0 * Math.Pow(2, zoom);

    // Converts longitude to a Web Mercator world-pixel X coordinate.
    private static double WorldPixelX(double longitude, int zoom) => (longitude + 180.0) / 360.0 * MapScale(zoom);

    // Converts latitude to a Web Mercator world-pixel Y coordinate.
    private static double WorldPixelY(double latitude, int zoom)
    {
        var sinY = Math.Sin(latitude * Math.PI / 180.0);
        sinY = Math.Clamp(sinY, -0.9999, 0.9999);
        return (0.5 - Math.Log((1 + sinY) / (1 - sinY)) / (4 * Math.PI)) * MapScale(zoom);
    }

    // Converts a Web Mercator world-pixel X coordinate back to longitude.
    private static double LongitudeFromWorldPixel(double x, int zoom) => x / MapScale(zoom) * 360.0 - 180.0;

    private static double ApproxDistanceMetres(double lat1, double lng1, double lat2, double lng2)
    {
        var meanLat = (lat1 + lat2) * Math.PI / 360.0;
        var dy = (lat2 - lat1) * 111_320.0;
        var dx = (lng2 - lng1) * 111_320.0 * Math.Cos(meanLat);
        return Math.Sqrt(dx * dx + dy * dy);
    }

    // Converts a Web Mercator world-pixel Y coordinate back to latitude.
    private static double LatitudeFromWorldPixel(double y, int zoom)
    {
        var n = Math.PI - 2.0 * Math.PI * y / MapScale(zoom);
        return Math.Atan(Math.Sinh(n)) * 180.0 / Math.PI;
    }

    // Applies information, optimization, or manual topology mode to map side-panel controls.
    private void ApplyMapViewMode()
    {
        var mode = SelectedComboText(MapModeCombo);
        var model = SelectedComboText(HeaderModelCombo);

        var optimization = mode.Contains("Optimization", StringComparison.OrdinalIgnoreCase)
            || model.Contains("Optimized", StringComparison.OrdinalIgnoreCase);

        MapPanelTitle.Text = optimization ? "Optimization mode" : "Information mode";
        OptimizationMapPanel.Visibility = optimization ? Visibility.Visible : Visibility.Collapsed;
        MapEmptyBadge.Visibility = Visibility.Visible;
        MapInfoText.Text = mode switch
        {
            "Optimization mode" => "Optimized model mode active. Review conservative, expected and worst-case SAIDI/SAIFI outputs and run optimization actions below.",
            _ when model.Contains("Optimized", StringComparison.OrdinalIgnoreCase) => "Optimized model selected. SAIDI/SAIFI information is shown below for comparison.",
            _ => "Information mode active. Search or select an asset ID to inspect source layers, model attributes and validation notes.",
        };
        RenderMap();
    }

    // Shows developer-only map modes when developer mode is enabled.
    private void UpdateDeveloperMapModeVisibility()
    {
        ApplyMapViewMode();
    }

    // Moves the map camera to the selected project/study area.
    private void ApplySchematicArea()
    {
        switch (SelectedComboText(MapSchematicAreaCombo))
        {
            case "King Country study area":
                _centerLat = -38.3350;
                _centerLng = 175.1650;
                _zoom = 10;
                break;
            case var projectArea when _workspaceStore.CurrentAccount(_workspaceState).Projects.Any(project => project.Name.Equals(projectArea, StringComparison.OrdinalIgnoreCase)):
                CenterMapOnSelectedModel();
                if (string.IsNullOrWhiteSpace(SelectedMapModelPath()))
                {
                    _centerLat = -38.3350;
                    _centerLng = 175.1650;
                    _zoom = 10;
                }
                break;
            default:
                _centerLat = -41.2865;
                _centerLng = 174.7762;
                _zoom = 6;
                break;
        }

        RenderMap();
        SetStatus($"Offline schematic area: {SelectedComboText(MapSchematicAreaCombo)}");
    }

    // Filters and expands the map asset tree for the search query.
    private void SearchMapAssets()
    {
        var query = MapAssetSearchBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(query))
        {
            ExpandTreeMatches(MapAssetTree.Items, "");
            MapInfoText.Text = "Asset groups are shown by count. Expand an area group to view asset IDs.";
            SetStatus("Showing all map asset groups");
            return;
        }

        var matchCount = ExpandTreeMatches(MapAssetTree.Items, query);
        MapInfoText.Text = matchCount > 0
            ? $"Search matched {matchCount} asset/group item(s) for '{query}'. Expand highlighted groups to inspect recorded information."
            : $"No asset IDs matched '{query}'. Try a feeder ID such as KC-FDR-001 or a recloser ID such as REC-KC-012.";
        SetStatus($"Map asset search: {query}");
    }

    // Recursively searches tree items and returns the number of matching headers.
    private int ExpandTreeMatches(ItemCollection items, string query)
    {
        var matches = 0;
        foreach (var item in items.OfType<TreeViewItem>())
        {
            matches += ExpandTreeItemForQuery(item, query);
        }

        return matches;
    }

    // Expands and selects a tree item when it or any child matches the search query.
    private int ExpandTreeItemForQuery(TreeViewItem item, string query)
    {
        var text = item.Header?.ToString() ?? "";
        var ownMatch = string.IsNullOrWhiteSpace(query) || text.Contains(query, StringComparison.OrdinalIgnoreCase);
        var childMatches = 0;

        foreach (var child in item.Items.OfType<TreeViewItem>())
        {
            childMatches += ExpandTreeItemForQuery(child, query);
        }

        item.IsExpanded = string.IsNullOrWhiteSpace(query) ? item.Items.Count > 0 && text.Contains("(") : ownMatch || childMatches > 0;
        if (ownMatch && !string.IsNullOrWhiteSpace(query))
        {
            item.IsSelected = true;
            item.BringIntoView();
        }

        return (ownMatch && !string.IsNullOrWhiteSpace(query) ? 1 : 0) + childMatches;
    }
}
