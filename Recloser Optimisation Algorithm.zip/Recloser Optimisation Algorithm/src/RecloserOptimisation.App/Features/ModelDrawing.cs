using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    // Model drawing renders saved Cartesian model JSON onto the map canvas.

    // Draws the selected built model's Cartesian nodes and edges as map overlay components.
    private void DrawSelectedModelLayer()
    {
        var modelPath = SelectedMapModelPath();
        if (string.IsNullOrWhiteSpace(modelPath) || !File.Exists(modelPath))
        {
            AddMapRenderError("No saved model JSON is selected for the model overlay.");
            return;
        }

        var model = LoadSelectedMapModel(modelPath);
        if (model is null)
        {
            AddMapRenderError("Selected model layer could not be read as a built model JSON file.");
            return;
        }

        if (model?.CartesianMap.Nodes.Count is null or 0)
        {
            AddMapRenderError("Selected model has no Cartesian geometry yet. Rebuild it from processed node/line files.");
            return;
        }

        var nodeLookup = model.CartesianMap.Nodes.ToDictionary(node => node.Id, StringComparer.OrdinalIgnoreCase);
        if (model.CartesianMap.Edges.Count == 0)
        {
            AddMapRenderError("Selected model has nodes but no line edges. Include and process lines.csv before building the model.");
        }

        var drawnEdges = 0;
        var missingEdgeNodes = 0;
        foreach (var edge in model.CartesianMap.Edges.Where(ShouldDrawModelEdge))
        {
            if (drawnEdges >= 2500)
            {
                break;
            }

            if (!nodeLookup.TryGetValue(edge.FromNode, out var from) || !nodeLookup.TryGetValue(edge.ToNode, out var to))
            {
                missingEdgeNodes++;
                continue;
            }

            var fromPoint = MapPointFromLatLng(from.Latitude, from.Longitude);
            var toPoint = MapPointFromLatLng(to.Latitude, to.Longitude);
            if (!IsMapSegmentVisible(fromPoint, toPoint))
            {
                continue;
            }

            DrawModelEdge(fromPoint, toPoint, edge.VoltageKv >= 33 ? "#2458D6" : "#D64545", edge.NormallyEnergised);
            drawnEdges++;
        }

        if (missingEdgeNodes > 0)
        {
            AddMapRenderError($"{missingEdgeNodes} line(s) could not draw because FromNode/ToNode was not found in Cartesian nodes.");
        }

        var drawnNodes = 0;
        foreach (var node in model.CartesianMap.Nodes.Where(ShouldDrawModelNode))
        {
            if (drawnNodes >= 800)
            {
                break;
            }

            var point = MapPointFromLatLng(node.Latitude, node.Longitude);
            if (!IsMapPointVisible(point))
            {
                continue;
            }

            DrawModelNode(point, node.Type.Contains("substation", StringComparison.OrdinalIgnoreCase) ? "#132033" : "#19A974");
            drawnNodes++;
        }

        var drawnComponents = DrawModelComponents(model, nodeLookup);

        if (drawnEdges == 0 && LayerModelLinesToggle.IsChecked == true && model.CartesianMap.Edges.Count > 0)
        {
            AddMapRenderError("Model has line edges, but none matched the enabled line component filters.");
        }

        if (drawnNodes == 0 && LayerModelNodesToggle.IsChecked == true && model.CartesianMap.Nodes.Count > 0)
        {
            AddMapRenderError("Model has nodes, but none matched the enabled node component filters.");
        }

        MapAttribution.Text = $"{model.Name}: drew {drawnNodes}/{model.CartesianMap.Nodes.Count} nodes, {drawnEdges}/{model.CartesianMap.Edges.Count} edges, {drawnComponents} components";
    }

    // Draws load, transformer, switch, and protection component overlays from the selected model.
    private int DrawModelComponents(BuiltModelRecord model, Dictionary<string, CartesianNodeRecord> nodeLookup)
    {
        var count = 0;
        if (LayerModelLoadsToggle.IsChecked == true)
        {
            foreach (var load in model.CartesianMap.Loads)
            {
                if (count >= 600)
                {
                    break;
                }

                count += DrawComponentAtNode(nodeLookup, load.NodeId, "#F59F00", "L", 10) ? 1 : 0;
            }
        }

        if (LayerModelTransformersToggle.IsChecked == true)
        {
            foreach (var transformer in model.CartesianMap.Transformers)
            {
                if (count >= 600)
                {
                    break;
                }

                count += DrawComponentAtNode(nodeLookup, transformer.NodeId, "#7950F2", "T", 12) ? 1 : 0;
            }
        }

        if (LayerModelSwitchesToggle.IsChecked == true)
        {
            foreach (var switchRecord in model.CartesianMap.Switches)
            {
                if (count >= 600)
                {
                    break;
                }

                count += DrawComponentAtNode(nodeLookup, switchRecord.NodeId, "#0B7285", "S", 12) ? 1 : 0;
            }
        }

        if (LayerModelProtectionToggle.IsChecked == true)
        {
            foreach (var protection in model.CartesianMap.ProtectionDevices)
            {
                if (count >= 600)
                {
                    break;
                }

                count += DrawComponentAtNode(nodeLookup, protection.NodeId, protection.Proposed ? "#E03131" : "#2F9E44", protection.Proposed ? "P" : "R", protection.Proposed ? 18 : 14) ? 1 : 0;
            }
        }

        return count;
    }

    // Checks whether an edge passes the enabled model-line and voltage layer filters.
    private bool ShouldDrawModelEdge(CartesianEdgeRecord edge)
    {
        if (LayerModelLinesToggle.IsChecked != true)
        {
            return false;
        }

        if (edge.VoltageKv >= 33)
        {
            return LayerModel33KvToggle.IsChecked == true;
        }

        return LayerModel11KvToggle.IsChecked == true;
    }

    // Checks whether a node passes the enabled node or substation layer filters.
    private bool ShouldDrawModelNode(CartesianNodeRecord node)
    {
        var isSubstation = node.Type.Contains("substation", StringComparison.OrdinalIgnoreCase);
        return isSubstation
            ? LayerModelSubstationsToggle.IsChecked == true
            : LayerModelNodesToggle.IsChecked == true;
    }

    // Resets the map render error dropdown before a new render pass.
    private void ClearMapRenderErrors()
    {
        MapRenderErrorsList.Items.Clear();
        MapRenderErrorsList.Items.Add("No display errors for the latest render.");
    }

    // Adds a timestamped model/map display error to the render error dropdown.
    private void AddMapRenderError(string error)
    {
        if (MapRenderErrorsList.Items.Count == 1 && string.Equals(MapRenderErrorsList.Items[0]?.ToString(), "No display errors for the latest render.", StringComparison.Ordinal))
        {
            MapRenderErrorsList.Items.Clear();
        }

        MapRenderErrorsList.Items.Add($"{DateTime.Now:HH:mm:ss} - {error}");
    }

    // Reads the saved model path attached to the selected map model dropdown item.
    private string SelectedMapModelPath()
    {
        return MapModelCombo.SelectedItem is ComboBoxItem item
            ? item.Tag?.ToString() ?? ""
            : "";
    }

    // Loads the selected map model once and reuses it until the source file changes.
    private BuiltModelRecord? LoadSelectedMapModel(string modelPath)
    {
        try
        {
            var writeTime = File.GetLastWriteTimeUtc(modelPath);
            if (_cachedMapModel is not null
                && string.Equals(_cachedMapModelPath, modelPath, StringComparison.OrdinalIgnoreCase)
                && _cachedMapModelWriteTime == writeTime)
            {
                return _cachedMapModel;
            }

            _cachedMapModel = JsonSerializer.Deserialize<BuiltModelRecord>(File.ReadAllText(modelPath), _jsonOptions);
            _cachedMapModelPath = modelPath;
            _cachedMapModelWriteTime = writeTime;
            return _cachedMapModel;
        }
        catch
        {
            _cachedMapModel = null;
            _cachedMapModelPath = "";
            _cachedMapModelWriteTime = default;
            return null;
        }
    }

    // Centers the map on the currently selected model layer when it has saved geometry.
    private void CenterMapOnSelectedModel()
    {
        var modelPath = SelectedMapModelPath();
        if (string.IsNullOrWhiteSpace(modelPath) || !File.Exists(modelPath))
        {
            return;
        }

        try
        {
            var model = LoadSelectedMapModel(modelPath);
            if (model is not null)
            {
                CenterMapOnCartesianMap(model.CartesianMap);
            }
        }
        catch
        {
            AddMapRenderError("Selected model could not be centered because its JSON could not be read.");
        }
    }

    // Centers the map camera on the average position of a Cartesian model.
    private void CenterMapOnCartesianMap(CartesianMapRecord map)
    {
        var nodes = map.Nodes
            .Where(node => Math.Abs(node.Latitude) > 0.001 || Math.Abs(node.Longitude) > 0.001)
            .ToList();
        if (nodes.Count == 0)
        {
            return;
        }

        _centerLat = nodes.Average(node => node.Latitude);
        _centerLng = nodes.Average(node => node.Longitude);
        _zoom = nodes.Count > 100 ? 10 : 12;
    }

    // Converts latitude and longitude into a point on the current map canvas.
    private Point MapPointFromLatLng(double latitude, double longitude)
    {
        var centerX = WorldPixelX(_centerLng, _zoom);
        var centerY = WorldPixelY(_centerLat, _zoom);
        var x = WorldPixelX(longitude, _zoom) - centerX + MapHost.ActualWidth / 2.0;
        var y = WorldPixelY(latitude, _zoom) - centerY + MapHost.ActualHeight / 2.0;
        return new Point(x, y);
    }

    // Draws one Cartesian model edge between two projected canvas points.
    private void DrawModelEdge(Point from, Point to, string color, bool normallyEnergised)
    {
        TileCanvas.Children.Add(new System.Windows.Shapes.Line
        {
            X1 = from.X,
            Y1 = from.Y,
            X2 = to.X,
            Y2 = to.Y,
            Stroke = BrushFrom(color),
            StrokeThickness = 1.8,
            Opacity = 0.72,
            StrokeDashArray = normallyEnergised ? null : new DoubleCollection { 7, 6 },
        });
    }

    // Draws one Cartesian model node marker at a projected canvas point.
    private void DrawModelNode(Point point, string color)
    {
        const double diameter = 7;
        var ellipse = new System.Windows.Shapes.Ellipse
        {
            Width = diameter,
            Height = diameter,
            Fill = BrushFrom(color),
            Stroke = Brushes.White,
            StrokeThickness = 1,
            Opacity = 0.92,
        };

        Canvas.SetLeft(ellipse, point.X - diameter / 2);
        Canvas.SetTop(ellipse, point.Y - diameter / 2);
        TileCanvas.Children.Add(ellipse);
    }

    // Draws a small component badge at a model node if the node exists in the Cartesian map.
    private bool DrawComponentAtNode(Dictionary<string, CartesianNodeRecord> nodeLookup, string nodeId, string color, string label, double diameter)
    {
        if (!nodeLookup.TryGetValue(nodeId, out var node))
        {
            return false;
        }

        var point = MapPointFromLatLng(node.Latitude, node.Longitude);
        if (!IsMapPointVisible(point, diameter + 24))
        {
            return false;
        }

        var badge = new Border
        {
            Width = diameter,
            Height = diameter,
            CornerRadius = new CornerRadius(diameter / 2),
            Background = BrushFrom(color),
            BorderBrush = Brushes.White,
            BorderThickness = new Thickness(1),
            Child = new TextBlock
            {
                Text = label,
                Foreground = Brushes.White,
                FontSize = Math.Max(7, diameter - 6),
                FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
            },
        };

        Canvas.SetLeft(badge, point.X - diameter / 2);
        Canvas.SetTop(badge, point.Y - diameter / 2);
        TileCanvas.Children.Add(badge);
        return true;
    }

    // Keeps off-screen model geometry out of the visual tree during pan and zoom.
    private bool IsMapPointVisible(Point point, double margin = 48)
    {
        return point.X >= -margin
            && point.Y >= -margin
            && point.X <= MapHost.ActualWidth + margin
            && point.Y <= MapHost.ActualHeight + margin;
    }

    // Checks whether a line's bounding box intersects the visible map viewport.
    private bool IsMapSegmentVisible(Point from, Point to, double margin = 96)
    {
        var minX = Math.Min(from.X, to.X);
        var maxX = Math.Max(from.X, to.X);
        var minY = Math.Min(from.Y, to.Y);
        var maxY = Math.Max(from.Y, to.Y);

        return maxX >= -margin
            && maxY >= -margin
            && minX <= MapHost.ActualWidth + margin
            && minY <= MapHost.ActualHeight + margin;
    }
}
