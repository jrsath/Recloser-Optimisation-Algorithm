using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    // Model drawing renders saved Cartesian model JSON onto the map canvas.

    // Draws the selected built model's Cartesian nodes and edges as map overlay components.
    private void DrawSelectedModelLayer()
    {
        var modelPath = SelectedMapModelPath();
        if (string.IsNullOrWhiteSpace(modelPath) || !File.Exists(modelPath))
        {
            AddMapRenderError("No saved model JSON is selected for the model overlay.");
            return;
        }

        var model = LoadSelectedMapModel(modelPath);
        if (model is null)
        {
            AddMapRenderError("Selected model layer could not be read as a built model JSON file.");
            return;
        }

        if (model?.CartesianMap.Nodes.Count is null or 0)
        {
            AddMapRenderError("Selected model has no Cartesian geometry yet. Rebuild it from processed node/line files.");
            return;
        }

        var nodeLookup = model.CartesianMap.Nodes.ToDictionary(node => node.Id, StringComparer.OrdinalIgnoreCase);
        _componentBadgeCells.Clear();
        if (model.CartesianMap.Edges.Count == 0)
        {
            AddMapRenderError("Selected model has nodes but no line edges. Include and process lines.csv before building the model.");
        }

        var drawnEdges = 0;
        var missingEdgeNodes = 0;
        var edgeLimit = _zoom >= 13 ? 6000 : 3500;
        foreach (var edge in model.CartesianMap.Edges.Where(ShouldDrawModelEdge))
        {
            if (drawnEdges >= edgeLimit)
            {
                break;
            }

            if (!nodeLookup.TryGetValue(edge.FromNode, out var from) || !nodeLookup.TryGetValue(edge.ToNode, out var to))
            {
                missingEdgeNodes++;
                continue;
            }

            var fromPoint = MapPointFromLatLng(from.Latitude, from.Longitude);
            var toPoint = MapPointFromLatLng(to.Latitude, to.Longitude);
            if (!IsMapSegmentVisible(fromPoint, toPoint))
            {
                continue;
            }

            DrawModelEdge(fromPoint, toPoint, edge, edge.VoltageKv >= 33 ? "#2458D6" : "#D64545");
            drawnEdges++;
        }

        if (missingEdgeNodes > 0)
        {
            AddMapRenderError($"{missingEdgeNodes} line(s) could not draw because FromNode/ToNode was not found in Cartesian nodes.");
        }

        var drawnNodes = 0;
        var nodeLimit = _zoom >= 15 ? 5000 : 1200;
        foreach (var node in model.CartesianMap.Nodes.Where(ShouldDrawModelNode))
        {
            if (drawnNodes >= nodeLimit)
            {
                break;
            }

            var point = MapPointFromLatLng(node.Latitude, node.Longitude);
            if (!IsMapPointVisible(point))
            {
                continue;
            }

            DrawModelNode(point, node, node.Type.Contains("substation", StringComparison.OrdinalIgnoreCase) ? "#132033" : "#19A974");
            drawnNodes++;
        }

        var drawnComponents = DrawModelComponents(model, nodeLookup);

        if (drawnEdges == 0 && LayerModelLinesToggle.IsChecked == true && model.CartesianMap.Edges.Count > 0)
        {
            AddMapRenderError("Model has line edges, but none matched the enabled line component filters.");
        }

        if (drawnNodes == 0 && LayerModelNodesToggle.IsChecked == true && model.CartesianMap.Nodes.Count > 0)
        {
            AddMapRenderError("Model has nodes, but none matched the enabled node component filters.");
        }

        MapAttribution.Text = $"{model.Name}: drew {drawnNodes}/{model.CartesianMap.Nodes.Count} nodes, {drawnEdges}/{model.CartesianMap.Edges.Count} edges, {drawnComponents} components";
    }

    // Draws outage markers from the outage file linked to the currently selected model.
    private void DrawLinkedOutageLayer()
    {
        var project = _workspaceStore.CurrentProject(_workspaceState);
        if (string.IsNullOrWhiteSpace(project.Settings.LinkedOutageFilePath))
        {
            AddMapRenderError("No outage data file is linked to this project model yet.");
            return;
        }

        var model = LoadSelectedMapModel(SelectedMapModelPath());
        if (model is null)
        {
            AddMapRenderError("Outages cannot draw because no selected project model is loaded.");
            return;
        }

        if (!string.IsNullOrWhiteSpace(project.Settings.LinkedOutageModelId)
            && !project.Settings.LinkedOutageModelId.Equals(model.Id, StringComparison.OrdinalIgnoreCase))
        {
            AddMapRenderError($"Linked outage data belongs to {project.Settings.LinkedOutageModelId}; select that model to view outages.");
            return;
        }

        var outagePath = ResolvePreviewPath(project.Settings.LinkedOutageFilePath);
        var outageNodes = LoadOutageNodeIds(outagePath);
        var candidateNodes = outageNodes.Count > 0
            ? model.CartesianMap.Nodes.Where(node => outageNodes.Contains(node.Id)).ToList()
            : model.CartesianMap.Nodes.Where((_, index) => index % Math.Max(1, model.CartesianMap.Nodes.Count / 18) == 0).Take(18).ToList();
        var drawn = 0;
        foreach (var node in candidateNodes)
        {
            var point = MapPointFromLatLng(node.Latitude, node.Longitude);
            if (!IsMapPointVisible(point, 36))
            {
                continue;
            }

            DrawOutageMarker(point, node.Id);
            drawn++;
        }

        if (drawn == 0)
        {
            AddMapRenderError("Linked outage data was found, but no outage markers were visible in the current map view.");
        }
    }

    // Draws data quality issues at their linked model nodes when the data errors layer is enabled.
    private void DrawDataQualityErrorLayer()
    {
        var model = LoadSelectedMapModel(SelectedMapModelPath());
        if (model is null)
        {
            AddMapRenderError("Data errors cannot draw because no selected project model is loaded.");
            return;
        }

        var dataQuality = AnalyzeDataQuality(model);
        MapIntegrityBar.Value = Math.Round(dataQuality.Overall * 100.0, 0);
        var nodeLookup = model.CartesianMap.Nodes.ToDictionary(node => node.Id, StringComparer.OrdinalIgnoreCase);
        var drawn = 0;
        foreach (var issue in dataQuality.Issues.Where(issue => !string.IsNullOrWhiteSpace(issue.NodeId)))
        {
            if (!nodeLookup.TryGetValue(issue.NodeId, out var node))
            {
                continue;
            }

            var point = MapPointFromLatLng(node.Latitude, node.Longitude);
            if (!IsMapPointVisible(point, 36))
            {
                continue;
            }

            DrawDataQualityMarker(point, issue);
            drawn++;
        }

        if (drawn == 0 && dataQuality.Issues.Any(issue => !string.IsNullOrWhiteSpace(issue.NodeId)))
        {
            AddMapRenderError("Data quality issues exist, but none are visible in the current map view.");
        }
    }

    // Draws one clickable data quality marker and writes its details into the map information panel.
    private void DrawDataQualityMarker(Point point, DataQualityIssueRecord issue)
    {
        var color = issue.Severity.Equals("Error", StringComparison.OrdinalIgnoreCase) ? "#D00000" : "#F08C00";
        var size = issue.Severity.Equals("Error", StringComparison.OrdinalIgnoreCase) ? 16.0 : 12.0;
        var marker = new Border
        {
            Width = size,
            Height = size,
            Background = BrushFrom(color),
            BorderBrush = Brushes.White,
            BorderThickness = new Thickness(1),
            ToolTip = $"{issue.Summary}: {issue.Detail}",
        };

        marker.MouseLeftButtonDown += (_, e) =>
        {
            MapInfoText.Text = $"{issue.Category} {issue.Severity}: {issue.Summary}. {issue.Detail} Node: {issue.NodeId}.";
            e.Handled = true;
        };

        Canvas.SetLeft(marker, point.X - size / 2);
        Canvas.SetTop(marker, point.Y - size / 2);
        TileCanvas.Children.Add(marker);
    }

    // Centers the map on the node attached to the selected data-quality issue.
    private void GoToSelectedDataQualityIssue()
    {
        if (DashboardDataQualityIssuesList.SelectedItem is not DataQualityIssueRecord issue || string.IsNullOrWhiteSpace(issue.NodeId))
        {
            return;
        }

        var model = LoadSelectedMapModel(SelectedMapModelPath());
        var node = model?.CartesianMap.Nodes.FirstOrDefault(node => node.Id.Equals(issue.NodeId, StringComparison.OrdinalIgnoreCase));
        if (node is null)
        {
            SetStatus("Selected data issue is not linked to a visible model node");
            return;
        }

        _centerLat = node.Latitude;
        _centerLng = node.Longitude;
        _zoom = Math.Max(_zoom, 15);
        LayerDataErrorsToggle.IsChecked = true;
        ShowPage("Map");
        RenderMap();
        MapInfoText.Text = $"{issue.Category} {issue.Severity}: {issue.Summary}. {issue.Detail} Node: {issue.NodeId}.";
        SetStatus($"Centered map on data issue at {issue.NodeId}");
    }

    // Reads outage node references from common OMS CSV columns; unknown formats fall back to model sample markers.
    private static HashSet<string> LoadOutageNodeIds(string outagePath)
    {
        var nodeIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (!File.Exists(outagePath) || !Path.GetExtension(outagePath).Equals(".csv", StringComparison.OrdinalIgnoreCase))
        {
            return nodeIds;
        }

        foreach (var row in ReadCsvRows(outagePath))
        {
            foreach (var key in new[] { "NodeID", "NodeId", "Node", "AssetID", "AssetId", "FromNode", "ToNode" })
            {
                if (row.TryGetValue(key, out var nodeId) && !string.IsNullOrWhiteSpace(nodeId))
                {
                    nodeIds.Add(nodeId);
                }
            }
        }

        return nodeIds;
    }

    // Draws one outage marker with a red square so faults stand apart from normal device circles.
    private void DrawOutageMarker(Point point, string nodeId)
    {
        var size = _zoom >= 13 ? 14.0 : 10.0;
        var marker = new Border
        {
            Width = size,
            Height = size,
            Background = BrushFrom("#D00000"),
            BorderBrush = Brushes.White,
            BorderThickness = new Thickness(1),
            ToolTip = $"Linked outage near {nodeId}",
        };
        marker.MouseLeftButtonDown += (_, e) =>
        {
            MapInfoText.Text = $"Outage marker linked to node {nodeId}. Use the Outages page to change the linked file.";
            e.Handled = true;
        };

        Canvas.SetLeft(marker, point.X - size / 2);
        Canvas.SetTop(marker, point.Y - size / 2);
        TileCanvas.Children.Add(marker);
    }

    // Draws load, transformer, switch, and protection component overlays from the selected model.
    private int DrawModelComponents(BuiltModelRecord model, Dictionary<string, CartesianNodeRecord> nodeLookup)
    {
        var count = 0;
        var downstreamLoads = BuildDownstreamLoadSummary(model.CartesianMap);
        if (LayerModelTransformersToggle.IsChecked == true)
        {
            foreach (var transformer in model.CartesianMap.Transformers)
            {
                if (count >= 600)
                {
                    break;
                }

                count += DrawTransformerAtNode(nodeLookup, transformer, model.CartesianMap.Loads) ? 1 : 0;
            }
        }

        if (LayerModelSwitchesToggle.IsChecked == true)
        {
            foreach (var switchRecord in model.CartesianMap.Switches)
            {
                if (count >= 600)
                {
                    break;
                }

                count += DrawSwitchAtNode(nodeLookup, switchRecord, downstreamLoads) ? 1 : 0;
            }
        }

        if (LayerModelProtectionToggle.IsChecked == true)
        {
            foreach (var protection in model.CartesianMap.ProtectionDevices)
            {
                if (count >= 600)
                {
                    break;
                }

                count += DrawProtectionAtNode(nodeLookup, protection, downstreamLoads) ? 1 : 0;
            }
        }

        if (LayerModelLoadsToggle.IsChecked == true)
        {
            foreach (var load in model.CartesianMap.Loads)
            {
                if (count >= 800)
                {
                    break;
                }

                count += DrawLoadAtNode(nodeLookup, load) ? 1 : 0;
            }
        }

        return count;
    }

    // Checks whether an edge passes the enabled model-line and voltage layer filters.
    private bool ShouldDrawModelEdge(CartesianEdgeRecord edge)
    {
        if (LayerModelLinesToggle.IsChecked != true)
        {
            return false;
        }

        if (edge.VoltageKv >= 33)
        {
            return LayerModel33KvToggle.IsChecked == true;
        }

        return LayerModel11KvToggle.IsChecked == true;
    }

    // Checks whether a node passes the enabled node/substation filters and zoom-level simplification.
    private bool ShouldDrawModelNode(CartesianNodeRecord node)
    {
        var isSubstation = node.Type.Contains("substation", StringComparison.OrdinalIgnoreCase);
        if (isSubstation)
        {
            return LayerModelSubstationsToggle.IsChecked == true;
        }

        if (LayerModelNodesToggle.IsChecked != true)
        {
            return false;
        }

        if (IsPrimaryDisplayNode(node))
        {
            return _zoom >= 14;
        }

        return _zoom >= 16;
    }

    private readonly record struct DownstreamLoadSummary(int LoadCount, int Customers, double Kva);

    // Builds downstream load and ICP/customer totals for switch and protection device information.
    private static Dictionary<string, DownstreamLoadSummary> BuildDownstreamLoadSummary(CartesianMapRecord map)
    {
        var children = map.Edges
            .Where(edge => edge.NormallyEnergised)
            .GroupBy(edge => edge.FromNode, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.Select(edge => edge.ToNode).Distinct(StringComparer.OrdinalIgnoreCase).ToList(), StringComparer.OrdinalIgnoreCase);
        var directLoads = map.Loads
            .GroupBy(load => load.NodeId, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(
                group => group.Key,
                group => new DownstreamLoadSummary(group.Count(), group.Sum(load => load.Customers), group.Sum(load => load.Kva)),
                StringComparer.OrdinalIgnoreCase);
        var memo = new Dictionary<string, DownstreamLoadSummary>(StringComparer.OrdinalIgnoreCase);
        var visiting = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        DownstreamLoadSummary Visit(string nodeId)
        {
            if (memo.TryGetValue(nodeId, out var cached))
            {
                return cached;
            }

            if (!visiting.Add(nodeId))
            {
                return default;
            }

            directLoads.TryGetValue(nodeId, out var total);
            if (children.TryGetValue(nodeId, out var childNodes))
            {
                foreach (var child in childNodes)
                {
                    var childTotal = Visit(child);
                    total = new DownstreamLoadSummary(total.LoadCount + childTotal.LoadCount, total.Customers + childTotal.Customers, total.Kva + childTotal.Kva);
                }
            }

            visiting.Remove(nodeId);
            memo[nodeId] = total;
            return total;
        }

        foreach (var node in map.Nodes)
        {
            Visit(node.Id);
        }

        return memo;
    }

    // Treats pole-only detail nodes as close-zoom details so the regional map stays readable.
    private static bool IsPoleDetailNode(CartesianNodeRecord node)
    {
        return node.Type.Contains("Pole", StringComparison.OrdinalIgnoreCase)
            && !node.Type.Contains("MainFeeder", StringComparison.OrdinalIgnoreCase);
    }

    // Keeps backbone, feeder trunk, protection, and junction nodes visible at normal zoom levels.
    private static bool IsPrimaryDisplayNode(CartesianNodeRecord node)
    {
        return node.Type.Contains("Junction", StringComparison.OrdinalIgnoreCase)
            || node.Type.Contains("MainFeeder", StringComparison.OrdinalIgnoreCase)
            || node.Type.Contains("Recloser", StringComparison.OrdinalIgnoreCase)
            || node.Type.Contains("Switch", StringComparison.OrdinalIgnoreCase)
            || node.Type.Contains("Transformer", StringComparison.OrdinalIgnoreCase)
            || node.Type.Contains("Substation", StringComparison.OrdinalIgnoreCase);
    }

    // Resets the map render error dropdown before a new render pass.
    private void ClearMapRenderErrors()
    {
        MapRenderErrorsList.Items.Clear();
        MapRenderErrorsList.Items.Add("No display errors for the latest render.");
    }

    // Adds a timestamped model/map display error to the render error dropdown.
    private void AddMapRenderError(string error)
    {
        if (MapRenderErrorsList.Items.Count == 1 && string.Equals(MapRenderErrorsList.Items[0]?.ToString(), "No display errors for the latest render.", StringComparison.Ordinal))
        {
            MapRenderErrorsList.Items.Clear();
        }

        MapRenderErrorsList.Items.Add($"{DateTime.Now:HH:mm:ss} - {error}");
    }

    // Reads the saved model path attached to the selected map model dropdown item.
    private string SelectedMapModelPath()
    {
        if (HeaderModelCombo.SelectedItem is ComboBoxItem headerItem && !string.IsNullOrWhiteSpace(headerItem.Tag?.ToString()))
        {
            return headerItem.Tag?.ToString() ?? "";
        }

        return MapModelCombo.SelectedItem is ComboBoxItem item
            ? item.Tag?.ToString() ?? ""
            : "";
    }

    // Loads the selected map model once and reuses it until the source file changes.
    private BuiltModelRecord? LoadSelectedMapModel(string modelPath)
    {
        try
        {
            var writeTime = File.GetLastWriteTimeUtc(modelPath);
            if (_cachedMapModel is not null
                && string.Equals(_cachedMapModelPath, modelPath, StringComparison.OrdinalIgnoreCase)
                && _cachedMapModelWriteTime == writeTime)
            {
                return _cachedMapModel;
            }

            _cachedMapModel = JsonSerializer.Deserialize<BuiltModelRecord>(File.ReadAllText(modelPath), _jsonOptions);
            if (_cachedMapModel is null
                || !_cachedMapModel.ProjectId.Equals(_workspaceStore.CurrentProject(_workspaceState).Id, StringComparison.OrdinalIgnoreCase))
            {
                _cachedMapModel = null;
                _cachedMapModelPath = "";
                _cachedMapModelWriteTime = default;
                return null;
            }

            _cachedMapModelPath = modelPath;
            _cachedMapModelWriteTime = writeTime;
            return _cachedMapModel;
        }
        catch
        {
            _cachedMapModel = null;
            _cachedMapModelPath = "";
            _cachedMapModelWriteTime = default;
            return null;
        }
    }

    // Centers the map on the currently selected model layer when it has saved geometry.
    private void CenterMapOnSelectedModel()
    {
        var modelPath = SelectedMapModelPath();
        if (string.IsNullOrWhiteSpace(modelPath) || !File.Exists(modelPath))
        {
            return;
        }

        try
        {
            var model = LoadSelectedMapModel(modelPath);
            if (model is not null)
            {
                CenterMapOnCartesianMap(model.CartesianMap);
            }
        }
        catch
        {
            AddMapRenderError("Selected model could not be centered because its JSON could not be read.");
        }
    }

    // Centers the map camera on the average position of a Cartesian model.
    private void CenterMapOnCartesianMap(CartesianMapRecord map)
    {
        var nodes = map.Nodes
            .Where(node => Math.Abs(node.Latitude) > 0.001 || Math.Abs(node.Longitude) > 0.001)
            .ToList();
        if (nodes.Count == 0)
        {
            return;
        }

        _centerLat = nodes.Average(node => node.Latitude);
        _centerLng = nodes.Average(node => node.Longitude);
        _zoom = nodes.Count > 100 ? 10 : 12;
    }

    // Converts latitude and longitude into a point on the current map canvas.
    private Point MapPointFromLatLng(double latitude, double longitude)
    {
        var centerX = WorldPixelX(_centerLng, _zoom);
        var centerY = WorldPixelY(_centerLat, _zoom);
        var x = WorldPixelX(longitude, _zoom) - centerX + MapHost.ActualWidth / 2.0;
        var y = WorldPixelY(latitude, _zoom) - centerY + MapHost.ActualHeight / 2.0;
        return new Point(x, y);
    }

    // Draws one Cartesian model edge between two projected canvas points.
    private void DrawModelEdge(Point from, Point to, CartesianEdgeRecord edge, string color)
    {
        var summary = $"Line {ValueOrNa(edge.Id)}: {ValueOrNa(edge.FromNode)} to {ValueOrNa(edge.ToNode)}. Feeder {ValueOrNa(edge.FeederId)}, voltage {edge.VoltageKv:N1} kV, length {edge.LengthM:N0} m, conductor {ValueOrNa(edge.Conductor)}, phase {ValueOrNa(edge.Phase)}, status {ValueOrNa(edge.Status)}.";
        var line = new System.Windows.Shapes.Line
        {
            X1 = from.X,
            Y1 = from.Y,
            X2 = to.X,
            Y2 = to.Y,
            Stroke = BrushFrom(color),
            StrokeThickness = _zoom >= 13 ? 2.2 : 1.8,
            Opacity = 0.72,
            StrokeDashArray = edge.NormallyEnergised ? null : new DoubleCollection { 7, 6 },
            ToolTip = summary,
        };

        line.MouseLeftButtonDown += (_, e) =>
        {
            MapInfoText.Text = summary;
            e.Handled = true;
        };

        TileCanvas.Children.Add(line);
    }

    // Draws one Cartesian model node marker at a projected canvas point.
    private void DrawModelNode(Point point, CartesianNodeRecord node, string color)
    {
        const double diameter = 7;
        var ellipse = new System.Windows.Shapes.Ellipse
        {
            Width = diameter,
            Height = diameter,
            Fill = BrushFrom(color),
            Stroke = Brushes.White,
            StrokeThickness = 1,
            Opacity = 0.92,
            ToolTip = ModelNodeSummary(node),
        };

        ellipse.MouseLeftButtonDown += (_, e) =>
        {
            MapInfoText.Text = ModelNodeSummary(node);
            e.Handled = true;
        };

        Canvas.SetLeft(ellipse, point.X - diameter / 2);
        Canvas.SetTop(ellipse, point.Y - diameter / 2);
        TileCanvas.Children.Add(ellipse);
    }

    // Draws a small component badge at a model node if the node exists in the Cartesian map.
    private bool DrawComponentAtNode(Dictionary<string, CartesianNodeRecord> nodeLookup, string nodeId, string color, string label, double diameter)
    {
        if (!nodeLookup.TryGetValue(nodeId, out var node))
        {
            return false;
        }

        var point = MapPointFromLatLng(node.Latitude, node.Longitude);
        if (!IsMapPointVisible(point, diameter + 24))
        {
            return false;
        }

        var badge = new Border
        {
            Width = diameter,
            Height = diameter,
            CornerRadius = new CornerRadius(diameter / 2),
            Background = BrushFrom(color),
            BorderBrush = Brushes.White,
            BorderThickness = new Thickness(1),
            Child = new TextBlock
            {
                Text = label,
                Foreground = Brushes.White,
                FontSize = Math.Max(7, diameter - 6),
                FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
            },
        };

        Canvas.SetLeft(badge, point.X - diameter / 2);
        Canvas.SetTop(badge, point.Y - diameter / 2);
        TileCanvas.Children.Add(badge);
        return true;
    }

    // Draws a transformer badge that exposes associated load and ICP/customer totals on click.
    private bool DrawTransformerAtNode(Dictionary<string, CartesianNodeRecord> nodeLookup, ModelTransformerRecord transformer, List<ModelLoadRecord> loads)
    {
        if (!nodeLookup.TryGetValue(transformer.NodeId, out var node))
        {
            return false;
        }

        var point = MapPointFromLatLng(node.Latitude, node.Longitude);
        if (!IsMapPointVisible(point, 36))
        {
            return false;
        }

        var attachedLoads = loads.Where(load => load.NodeId.Equals(transformer.NodeId, StringComparison.OrdinalIgnoreCase)).ToList();
        var customerCount = attachedLoads.Sum(load => load.Customers);
        var kva = attachedLoads.Sum(load => load.Kva);
        var summary = $"{ValueOrNa(transformer.Id)}: {transformer.Kva:N0} kVA transformer. Primary {FormatKv(transformer.PrimaryKv)}, secondary {FormatKv(transformer.SecondaryKv)}, phase {ValueOrNa(transformer.Phase)}, feeder {ValueOrNa(transformer.FeederId)}, status {ValueOrNa(transformer.Status)}. Attached loads: {attachedLoads.Count:N0}, downstream ICP/customers: {customerCount:N0}, connected load: {kva:N1} kVA.";
        if (_zoom < 14 && TryDrawAggregatedComponentBadge(point, "#F2C94C", "T", 14, summary))
        {
            return true;
        }

        DrawAssetBadge(point, "Transformer", "#F2C94C", "T", 14, summary);
        return true;
    }

    // Draws a switch badge with downstream load and ICP/customer totals in the click information.
    private bool DrawSwitchAtNode(Dictionary<string, CartesianNodeRecord> nodeLookup, ModelSwitchRecord switchRecord, Dictionary<string, DownstreamLoadSummary> downstreamLoads)
    {
        var summary = downstreamLoads.TryGetValue(switchRecord.NodeId, out var load)
            ? $"{ValueOrNa(switchRecord.Id)}: {ValueOrNa(switchRecord.SwitchType)} switch. Normally {ValueOrNa(switchRecord.Normally)}, voltage {FormatKv(switchRecord.VoltageKv)}, feeder {ValueOrNa(switchRecord.FeederId)}, status {ValueOrNa(switchRecord.Status)}. Downstream loads: {load.LoadCount:N0}, downstream ICP/customers: {load.Customers:N0}, downstream kVA: {load.Kva:N1}."
            : $"{ValueOrNa(switchRecord.Id)}: {ValueOrNa(switchRecord.SwitchType)} switch. Normally {ValueOrNa(switchRecord.Normally)}, voltage {FormatKv(switchRecord.VoltageKv)}, feeder {ValueOrNa(switchRecord.FeederId)}, status {ValueOrNa(switchRecord.Status)}. Downstream load information is unavailable.";
        return DrawInformationBadgeAtNode(nodeLookup, switchRecord.NodeId, "#9C36B5", "S", "Switch", 14, summary);
    }

    // Draws a recloser/protection badge with downstream load and ICP/customer totals.
    private bool DrawProtectionAtNode(Dictionary<string, CartesianNodeRecord> nodeLookup, ModelProtectionDeviceRecord protection, Dictionary<string, DownstreamLoadSummary> downstreamLoads)
    {
        var summary = downstreamLoads.TryGetValue(protection.NodeId, out var load)
            ? $"{ValueOrNa(protection.Id)}: {ValueOrNa(protection.AssetType)}. Voltage {FormatKv(protection.VoltageKv)}, feeder {ValueOrNa(protection.FeederId)}, model {ValueOrNa(protection.Model)}, status {ValueOrNa(protection.Status)}, proposed {protection.Proposed}. Downstream loads: {load.LoadCount:N0}, downstream ICP/customers: {load.Customers:N0}, downstream kVA: {load.Kva:N1}."
            : $"{ValueOrNa(protection.Id)}: {ValueOrNa(protection.AssetType)}. Voltage {FormatKv(protection.VoltageKv)}, feeder {ValueOrNa(protection.FeederId)}, model {ValueOrNa(protection.Model)}, status {ValueOrNa(protection.Status)}, proposed {protection.Proposed}. Downstream load information is unavailable.";
        return DrawInformationBadgeAtNode(nodeLookup, protection.NodeId, protection.Proposed ? "#E03131" : "#2F9E44", protection.Proposed ? "P" : "R", "Recloser", protection.Proposed ? 18 : 16, summary);
    }

    // Draws a load only when the explicit loads layer is enabled.
    private bool DrawLoadAtNode(Dictionary<string, CartesianNodeRecord> nodeLookup, ModelLoadRecord load)
    {
        if (!nodeLookup.TryGetValue(load.NodeId, out var node))
        {
            return false;
        }

        var point = MapPointFromLatLng(node.Latitude, node.Longitude);
        if (!IsMapPointVisible(point, 36))
        {
            return false;
        }

        var summary = $"{ValueOrNa(load.Id)}: load at {ValueOrNa(load.NodeId)}. {load.Kva:N1} kVA, {load.Customers:N0} ICP/customers, phase {ValueOrNa(load.Phase)}, feeder {ValueOrNa(load.FeederId)}, status {ValueOrNa(load.Status)}.";
        if (_zoom < 15 && TryDrawAggregatedComponentBadge(point, "#FFD43B", "L", 12, summary))
        {
            return true;
        }

        DrawAssetBadge(point, "Load", "#FFD43B", "L", 12, summary);
        return true;
    }

    // Draws a clickable component badge and writes its information to the map information panel.
    private bool DrawInformationBadgeAtNode(Dictionary<string, CartesianNodeRecord> nodeLookup, string nodeId, string color, string label, string shape, double diameter, string summary)
    {
        if (!nodeLookup.TryGetValue(nodeId, out var node))
        {
            return false;
        }

        var point = MapPointFromLatLng(node.Latitude, node.Longitude);
        if (!IsMapPointVisible(point, diameter + 24))
        {
            return false;
        }

        if (_zoom < 14 && TryDrawAggregatedComponentBadge(point, color, label, diameter, summary))
        {
            return true;
        }

        DrawAssetBadge(point, shape, color, label, diameter, summary);
        return true;
    }

    // Draws a distinct asset shape so switches, reclosers, transformers, and loads do not all look alike.
    private void DrawAssetBadge(Point point, string shape, string color, string label, double diameter, string summary)
    {
        FrameworkElement badge = shape switch
        {
            "Transformer" => new Border
            {
                Width = diameter,
                Height = diameter,
                CornerRadius = new CornerRadius(2),
                Background = BrushFrom(color),
                BorderBrush = BrushFrom("#132033"),
                BorderThickness = new Thickness(1),
                Child = CenteredBadgeText(label, Brushes.Black, Math.Max(8, diameter - 5)),
            },
            "Load" => new Grid
            {
                Width = diameter + 2,
                Height = diameter + 2,
                Children =
                {
                    new System.Windows.Shapes.Polygon
                    {
                        Points = new PointCollection { new(diameter / 2 + 1, 1), new(diameter + 1, diameter + 1), new(1, diameter + 1) },
                        Fill = BrushFrom(color),
                        Stroke = BrushFrom("#132033"),
                        StrokeThickness = 1,
                    },
                },
            },
            "Switch" => new Grid
            {
                Width = diameter,
                Height = diameter,
                Children =
                {
                    new System.Windows.Shapes.Line { X1 = 1, Y1 = diameter / 2, X2 = diameter - 1, Y2 = diameter / 2, Stroke = BrushFrom(color), StrokeThickness = 3, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round },
                    new System.Windows.Shapes.Line { X1 = diameter / 2, Y1 = diameter / 2, X2 = diameter - 2, Y2 = 2, Stroke = BrushFrom(color), StrokeThickness = 3, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round },
                },
            },
            "Recloser" => new Grid
            {
                Width = diameter,
                Height = diameter,
                Children =
                {
                    new System.Windows.Shapes.Ellipse { Width = diameter, Height = diameter, Fill = BrushFrom(color), Stroke = Brushes.White, StrokeThickness = 1 },
                    CenteredBadgeText(label, Brushes.White, Math.Max(8, diameter - 6)),
                },
            },
            _ => new Border
            {
                Width = diameter,
                Height = diameter,
                CornerRadius = new CornerRadius(diameter / 2),
                Background = BrushFrom(color),
                BorderBrush = Brushes.White,
                BorderThickness = new Thickness(1),
                Child = CenteredBadgeText(label, Brushes.White, Math.Max(7, diameter - 6)),
            },
        };

        badge.ToolTip = summary;
        badge.MouseLeftButtonDown += (_, e) =>
        {
            MapInfoText.Text = summary;
            e.Handled = true;
        };

        Canvas.SetLeft(badge, point.X - badge.Width / 2);
        Canvas.SetTop(badge, point.Y - badge.Height / 2);
        TileCanvas.Children.Add(badge);
    }

    // Creates the centered text used by compact map badges.
    private static TextBlock CenteredBadgeText(string label, Brush foreground, double fontSize)
    {
        return new TextBlock
        {
            Text = label,
            Foreground = foreground,
            FontSize = fontSize,
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
        };
    }

    // Merges overlapping same-component symbols at wider zooms so switches, reclosers, and transformers remain readable.
    private bool TryDrawAggregatedComponentBadge(Point point, string color, string label, double diameter, string summary)
    {
        var cellSize = _zoom < 12 ? 38.0 : 28.0;
        var key = $"{label}:{color}:{(int)(point.X / cellSize)}:{(int)(point.Y / cellSize)}";
        if (!_componentBadgeCells.TryGetValue(key, out var count))
        {
            _componentBadgeCells[key] = 1;
            return false;
        }

        _componentBadgeCells[key] = count + 1;
        return true;
    }

    // Provides node details while using N/A for attributes missing from the processed files.
    private static string ModelNodeSummary(CartesianNodeRecord node)
    {
        return $"Node {ValueOrNa(node.Id)}: type {ValueOrNa(node.Type)}, feeder {ValueOrNa(node.FeederId)}, elevation {node.ElevationM:N0} m, source {ValueOrNa(node.Source)}, status {ValueOrNa(node.Status)}.";
    }

    // Uses N/A consistently in map information panels when source datasets omit optional attributes.
    private static string ValueOrNa(string? value)
    {
        return string.IsNullOrWhiteSpace(value) ? "N/A" : value;
    }

    // Formats missing voltage values as N/A instead of misleading zeroes.
    private static string FormatKv(double value)
    {
        return value > 0 ? $"{value:N1} kV" : "N/A";
    }

    // Keeps off-screen model geometry out of the visual tree during pan and zoom.
    private bool IsMapPointVisible(Point point, double margin = 48)
    {
        return point.X >= -margin
            && point.Y >= -margin
            && point.X <= MapHost.ActualWidth + margin
            && point.Y <= MapHost.ActualHeight + margin;
    }

    // Checks whether a line's bounding box intersects the visible map viewport.
    private bool IsMapSegmentVisible(Point from, Point to, double margin = 96)
    {
        var minX = Math.Min(from.X, to.X);
        var maxX = Math.Max(from.X, to.X);
        var minY = Math.Min(from.Y, to.Y);
        var maxY = Math.Max(from.Y, to.Y);

        return maxX >= -margin
            && maxY >= -margin
            && minX <= MapHost.ActualWidth + margin
            && minY <= MapHost.ActualHeight + margin;
    }
}
