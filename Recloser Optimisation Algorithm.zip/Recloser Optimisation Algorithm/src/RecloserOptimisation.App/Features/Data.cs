using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Loads prototype configuration, adapter plans, processed files, and reports.

    // Loads import adapter definitions from configuration, with a GIS fallback if no file is available.
    private void LoadAdapters()
    {
        _adapters.Clear();
        var path = Path.Combine(AppContext.BaseDirectory, "Config", "import-adapters.json");

        if (!File.Exists(path))
        {
            path = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "config", "import-adapters.json"));
        }

        if (File.Exists(path))
        {
            var json = File.ReadAllText(path);
            var adapters = JsonSerializer.Deserialize<List<ImportAdapter>>(json) ?? new List<ImportAdapter>();
            foreach (var adapter in adapters)
            {
                adapter.Status = "Planned";
                _adapters.Add(adapter);
            }
        }

        if (_adapters.Count == 0)
        {
            _adapters.Add(new ImportAdapter
            {
                Category = "GIS",
                Platform = "Esri ArcGIS",
                Formats = "SHP, FileGDB, GeoJSON",
                Status = "Planned",
                Purpose = "Spatial network and asset layers",
            });
        }

        AdapterFilesGrid.SelectedIndex = _adapters.Count > 0 ? 0 : -1;
    }

    // Mirrors the selected adapter row into the readable adapter-plan detail panel.
    private void UpdateAdapterPlanDetail()
    {
        if (AdapterFilesGrid.SelectedItem is not ImportAdapter adapter)
        {
            AdapterPlanDetailText.Text = "Select an adapter in the list to view formats, purpose and readiness.";
            return;
        }

        AdapterPlanDetailText.Text = $"{adapter.Category} - {adapter.Platform}{Environment.NewLine}Formats: {adapter.Formats}{Environment.NewLine}Status: {adapter.Status}{Environment.NewLine}{adapter.Purpose}";
    }

    // Applies the selected adapter category and starts file import for that adapter.
    private void ImportSelectedAdapterPlan()
    {
        if (AdapterFilesGrid.SelectedItem is not ImportAdapter adapter)
        {
            SetStatus("Select an adapter first");
            return;
        }

        SourceTypeCombo.Text = adapter.Category;
        SetStatus($"Adapter plan selected: {adapter.Platform}");
        ChooseImportFiles();
    }

    // Lets the user select a custom adapter-plan file before staging matching source files.
    private void UploadCustomAdapterPlan()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Upload custom adapter plan",
            Filter = "Adapter plans|*.json;*.xml;*.csv|All files|*.*",
        };

        if (dialog.ShowDialog(this) != true)
        {
            return;
        }

        SetStatus($"Custom adapter loaded: {Path.GetFileName(dialog.FileName)}");
        ChooseImportFiles();
    }

    // Announces the future adapter-plan creation flow.
    private void CreateAdapterPlan()
    {
        SetStatus("Create adapter plan: select adapter files, name the plan, then save it to project adapter storage");
    }

    // Seeds the report grid with the known report slots when no reports have been created yet.
    private void LoadReports()
    {
        if (_reports.Count > 0)
        {
            return;
        }

        _reports.Add(new ReportRow { Report = "Network model summary", Category = "Model", Status = "Unavailable" });
        _reports.Add(new ReportRow { Report = "SAIDI / SAIFI comparison", Category = "Analysis", Status = "Unavailable" });
        _reports.Add(new ReportRow { Report = "Validation issue register", Category = "Validation", Status = "Unavailable" });
    }

    // Loads bundled processed-data examples and report metadata into the database grids.
    private void LoadProcessedData()
    {
        _processedFiles.Clear();
        var path = ResolveConfigPath("processed-data.json");
        if (!File.Exists(path))
        {
            AddExampleProcessedDatasetFiles();
            LoadBuiltModelStorage();
            return;
        }

        using var document = JsonDocument.Parse(File.ReadAllText(path));
        var root = document.RootElement;

        if (root.TryGetProperty("reports", out var reports) && reports.ValueKind == JsonValueKind.Array)
        {
            _reports.Clear();
            foreach (var report in reports.EnumerateArray())
            {
                _reports.Add(new ReportRow
                {
                    Report = GetJsonString(report, "Report"),
                    Category = GetJsonString(report, "Category"),
                    Status = GetJsonString(report, "Status"),
                    Uploaded = File.GetLastWriteTime(path).ToString("yyyy-MM-dd HH:mm"),
                    Path = path,
                });
            }
        }

        if (root.TryGetProperty("processedFiles", out var processedFiles) && processedFiles.ValueKind == JsonValueKind.Array)
        {
            foreach (var file in processedFiles.EnumerateArray())
            {
                AddOrReplaceProcessedFile(new ProcessedFile
                {
                    Active = GetJsonBool(file, "Active"),
                    File = GetJsonString(file, "File"),
                    Type = GetJsonString(file, "Type"),
                    Feeds = GetJsonString(file, "Feeds"),
                    Status = GetJsonString(file, "Status"),
                    Label = GetJsonString(file, "Label"),
                    Locked = GetJsonBool(file, "Locked"),
                    Uploaded = File.Exists(ResolvePreviewPath(GetJsonString(file, "Path")))
                        ? File.GetLastWriteTime(ResolvePreviewPath(GetJsonString(file, "Path"))).ToString("yyyy-MM-dd HH:mm")
                        : "",
                    Path = GetJsonString(file, "Path"),
                });
            }
        }

        AddExampleProcessedDatasetFiles();
        LoadBuiltModelStorage();
    }

    // Adds a processed-file row after filtering out staged or unprocessed source files.
    private void AddOrReplaceProcessedFile(ProcessedFile file)
    {
        if (!IsProcessedStorageFile(file))
        {
            return;
        }

        var existing = _processedFiles.FirstOrDefault(current => string.Equals(current.File, file.File, StringComparison.OrdinalIgnoreCase));
        if (existing is not null)
        {
            _processedFiles.Remove(existing);
        }

        _processedFiles.Add(file);
    }

    // Keeps the processed storage free of example model files; model JSON belongs in model storage.
    private void AddDefaultProcessedFiles()
    {
    }

    // Determines whether a row belongs in processed storage rather than source-file storage.
    private static bool IsProcessedStorageFile(ProcessedFile file)
    {
        if (string.IsNullOrWhiteSpace(file.File))
        {
            return false;
        }

        if ((file.File.Equals("example-processed-feeder-model.json", StringComparison.OrdinalIgnoreCase)
                || file.File.Equals("example.roa_model.json", StringComparison.OrdinalIgnoreCase))
            && (file.Status.Equals("Example", StringComparison.OrdinalIgnoreCase)
                || file.Uploaded.Contains("example", StringComparison.OrdinalIgnoreCase)
                || file.Path.Contains("example", StringComparison.OrdinalIgnoreCase)
                || file.Path.Contains("config", StringComparison.OrdinalIgnoreCase)))
        {
            return false;
        }

        if (file.Status.Contains("unprocessed", StringComparison.OrdinalIgnoreCase)
            || file.Status.Contains("staged", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        if (file.File.EndsWith(".roa_model.json", StringComparison.OrdinalIgnoreCase)
            || file.File.Contains("model-", StringComparison.OrdinalIgnoreCase) && file.File.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        return file.Type.Contains("processed", StringComparison.OrdinalIgnoreCase)
            || file.Feeds.Contains("model", StringComparison.OrdinalIgnoreCase)
            || file.Feeds.Contains("map", StringComparison.OrdinalIgnoreCase);
    }

    // Adds optional large example dataset files from the local example-data folder.
    private void AddExampleProcessedDatasetFiles()
    {
        var folder = Path.Combine(AppContext.BaseDirectory, "data", "example", "ROA_large_processed_dataset");
        if (!Directory.Exists(folder))
        {
            folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "..", "data", "example", "ROA_large_processed_dataset");
            folder = Path.GetFullPath(folder);
        }

        if (!Directory.Exists(folder))
        {
            folder = Path.Combine(Environment.CurrentDirectory, "data", "example", "ROA_large_processed_dataset");
        }

        if (!Directory.Exists(folder))
        {
            return;
        }

        foreach (var entry in new[]
                 {
                     ("nodes.csv", "Processed nodes", "Model, Map"),
                     ("lines.csv", "Processed lines", "Model, Map"),
                     ("loads.csv", "Processed loads", "Model, SAIDI/SAIFI"),
                     ("transformers.csv", "Processed transformers", "Model"),
                     ("switches.csv", "Processed switches", "Model"),
                     ("protection.csv", "Processed protection devices", "Protection, Optimization"),
                     ("feeders.csv", "Processed feeders", "Model"),
                     ("network.geojson", "Processed network geometry", "Map"),
                 })
        {
            var path = Path.Combine(folder, entry.Item1);
            if (!File.Exists(path))
            {
                continue;
            }

            var isModelInput = entry.Item1.Equals("nodes.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("lines.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("loads.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("transformers.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("switches.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("protection.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("feeders.csv", StringComparison.OrdinalIgnoreCase);

            AddOrReplaceProcessedFile(new ProcessedFile
            {
                Active = isModelInput,
                File = entry.Item1,
                Type = entry.Item2,
                Feeds = entry.Item3,
                Status = "Example",
                Label = _workspaceStore.CurrentProject(_workspaceState).Settings.ExampleDataLabel,
                Uploaded = File.GetLastWriteTime(path).ToString("yyyy-MM-dd HH:mm"),
                Path = path,
            });
        }
    }

    // Reads built model JSON files for the current project and refreshes model selectors.
    private void LoadBuiltModelStorage()
    {
        _builtModels.Clear();
        var builtModelsPath = _workspaceStore.BuiltModelsPath(_workspaceState);
        foreach (var file in Directory.EnumerateFiles(builtModelsPath, "*.json").OrderByDescending(File.GetLastWriteTimeUtc))
        {
            _builtModels.Add(new ProcessedFile
            {
                Active = false,
                File = Path.GetFileName(file),
                Type = "Built model",
                Feeds = "Map, Optimization, Reports",
                Status = Path.GetFileNameWithoutExtension(file) == _workspaceStore.CurrentProject(_workspaceState).Settings.ActiveModelId ? "Active" : "Saved",
                Label = "Project model",
                Locked = File.GetAttributes(file).HasFlag(FileAttributes.ReadOnly),
                Uploaded = File.GetLastWriteTime(file).ToString("yyyy-MM-dd HH:mm"),
                Path = file,
            });
        }

        RefreshModelLayerSelectors();
        RefreshWorkingDirectoryStorage();
    }

    // Rebuilds the header and map model dropdowns from saved built-model storage.
    private void RefreshModelLayerSelectors()
    {
        var selectedMapModel = SelectedComboText(MapModelCombo);
        var selectedHeaderModel = SelectedComboText(HeaderModelCombo);
        var selectedRunSetupModel = SelectedComboText(RunSetupModelCombo);
        var activeModelId = _workspaceStore.CurrentProject(_workspaceState).Settings.ActiveModelId;

        MapModelCombo.Items.Clear();
        MapModelCombo.Items.Add(new ComboBoxItem { Content = "Baseline processed model layer" });

        HeaderModelCombo.Items.Clear();
        HeaderModelCombo.Items.Add(new ComboBoxItem { Content = "Baseline processed model" });
        HeaderModelCombo.Items.Add(new ComboBoxItem { Content = "Custom model" });

        RunSetupModelCombo.Items.Clear();

        foreach (var modelFile in _builtModels)
        {
            var name = Path.GetFileNameWithoutExtension(modelFile.File);
            var display = $"{name} model layer";
            MapModelCombo.Items.Add(new ComboBoxItem { Content = display, Tag = modelFile.Path });
            HeaderModelCombo.Items.Add(new ComboBoxItem { Content = name, Tag = modelFile.Path });
            RunSetupModelCombo.Items.Add(new ComboBoxItem { Content = name, Tag = modelFile.Path });
        }

        var preferredMapModel = !string.IsNullOrWhiteSpace(activeModelId)
            && (string.IsNullOrWhiteSpace(selectedMapModel)
                || selectedMapModel.Equals("Baseline processed model layer", StringComparison.OrdinalIgnoreCase)
                || selectedMapModel.Equals("Optimized vector map layer", StringComparison.OrdinalIgnoreCase))
            ? $"{activeModelId} model layer"
            : selectedMapModel;
        var preferredHeaderModel = !string.IsNullOrWhiteSpace(activeModelId)
            && (string.IsNullOrWhiteSpace(selectedHeaderModel)
                || selectedHeaderModel.Equals("Baseline processed model", StringComparison.OrdinalIgnoreCase)
                || selectedHeaderModel.Equals("Optimized model draft", StringComparison.OrdinalIgnoreCase)
                || selectedHeaderModel.Equals("Custom model", StringComparison.OrdinalIgnoreCase))
            ? activeModelId
            : selectedHeaderModel;
        var preferredRunSetupModel = !string.IsNullOrWhiteSpace(activeModelId)
            && (string.IsNullOrWhiteSpace(selectedRunSetupModel) || selectedRunSetupModel.Equals("Baseline processed model", StringComparison.OrdinalIgnoreCase))
            ? activeModelId
            : selectedRunSetupModel;

        SelectComboContent(MapModelCombo, preferredMapModel);
        SelectComboContent(HeaderModelCombo, preferredHeaderModel);
        SelectComboContent(RunSetupModelCombo, preferredRunSetupModel);
    }

    // Selects the matching combo item by displayed text, defaulting to the first item.
    private static void SelectComboContent(ComboBox combo, string preferred)
    {
        for (var i = 0; i < combo.Items.Count; i++)
        {
            if (combo.Items[i] is ComboBoxItem item && string.Equals(item.Content?.ToString(), preferred, StringComparison.OrdinalIgnoreCase))
            {
                combo.SelectedIndex = i;
                return;
            }
        }

        combo.SelectedIndex = combo.Items.Count > 0 ? 0 : -1;
    }

    // Reads an optional JSON property as a string without throwing on missing values.
    private static string GetJsonString(JsonElement element, string propertyName)
    {
        return element.TryGetProperty(propertyName, out var property) ? property.ToString() : "";
    }

    // Reads an optional JSON property as a strict true/false flag.
    private static bool GetJsonBool(JsonElement element, string propertyName)
    {
        return element.TryGetProperty(propertyName, out var property) && property.ValueKind == JsonValueKind.True;
    }

    // Resolves config files from either the published output folder or the source checkout.
    private static string ResolveConfigPath(string fileName)
    {
        var outputPath = Path.Combine(AppContext.BaseDirectory, "Config", fileName);
        if (File.Exists(outputPath))
        {
            return outputPath;
        }

        return Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "config", fileName));
    }
}
