using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Loads prototype configuration, adapter plans, processed files, and reports.

    // Loads import adapter definitions from configuration, with a GIS fallback if no file is available.
    private void LoadAdapters()
    {
        _adapters.Clear();
        var path = Path.Combine(AppContext.BaseDirectory, "Config", "import-adapters.json");

        if (!File.Exists(path))
        {
            path = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "config", "import-adapters.json"));
        }

        if (File.Exists(path))
        {
            var json = File.ReadAllText(path);
            var adapters = JsonSerializer.Deserialize<List<ImportAdapter>>(json) ?? new List<ImportAdapter>();
            foreach (var adapter in adapters)
            {
                adapter.Status = "Planned";
                _adapters.Add(adapter);
            }
        }

        if (_adapters.Count == 0)
        {
            _adapters.Add(new ImportAdapter
            {
                Category = "GIS",
                Platform = "Esri ArcGIS",
                Formats = "SHP, FileGDB, GeoJSON",
                Status = "Planned",
                Purpose = "Spatial network and asset layers",
            });
        }

        AdapterFilesGrid.SelectedIndex = _adapters.Count > 0 ? 0 : -1;
    }

    // Mirrors the selected adapter row into the readable adapter-plan detail panel.
    private void UpdateAdapterPlanDetail()
    {
        if (AdapterFilesGrid.SelectedItem is not ImportAdapter adapter)
        {
            AdapterPlanDetailText.Text = "Select an adapter in the list to view formats, purpose and readiness.";
            return;
        }

        AdapterPlanDetailText.Text = $"{adapter.Category} - {adapter.Platform}{Environment.NewLine}Formats: {adapter.Formats}{Environment.NewLine}Status: {adapter.Status}{Environment.NewLine}{adapter.Purpose}";
    }

    // Applies the selected adapter category and starts file import for that adapter.
    private void ImportSelectedAdapterPlan()
    {
        if (AdapterFilesGrid.SelectedItem is not ImportAdapter adapter)
        {
            SetStatus("Select an adapter first");
            return;
        }

        SourceTypeCombo.Text = adapter.Category;
        SetStatus($"Adapter plan selected: {adapter.Platform}");
        ChooseImportFiles();
    }

    // Lets the user select a custom adapter-plan file before staging matching source files.
    private void UploadCustomAdapterPlan()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Upload custom adapter plan",
            Filter = "Adapter plans|*.json;*.xml;*.csv|All files|*.*",
        };

        if (dialog.ShowDialog(this) != true)
        {
            return;
        }

        SetStatus($"Custom adapter loaded: {Path.GetFileName(dialog.FileName)}");
        ChooseImportFiles();
    }

    // Announces the future adapter-plan creation flow.
    private void CreateAdapterPlan()
    {
        SetStatus("Create adapter plan: select adapter files, name the plan, then save it to project adapter storage");
    }

    // Seeds the report grid with the known report slots when no reports have been created yet.
    private void LoadReports()
    {
        if (_reports.Count > 0)
        {
            return;
        }

        _reports.Add(new ReportRow { Report = "Network model summary", Category = "Model", Status = "Unavailable" });
        _reports.Add(new ReportRow { Report = "SAIDI / SAIFI comparison", Category = "Analysis", Status = "Unavailable" });
        _reports.Add(new ReportRow { Report = "Validation issue register", Category = "Validation", Status = "Unavailable" });
    }

    // Loads bundled processed-data examples and report metadata into the database grids.
    private void LoadProcessedData()
    {
        _processedFiles.Clear();
        AddExampleProcessedDatasetFiles();
        LoadBuiltModelStorage();
        LoadOptimizationRunLogs();
        return;

#pragma warning disable CS0162
        var path = ResolveConfigPath("processed-data.json");
        if (!File.Exists(path))
        {
            AddExampleProcessedDatasetFiles();
            LoadBuiltModelStorage();
            return;
        }

        using var document = JsonDocument.Parse(File.ReadAllText(path));
        var root = document.RootElement;

        if (root.TryGetProperty("reports", out var reports) && reports.ValueKind == JsonValueKind.Array)
        {
            _reports.Clear();
            foreach (var report in reports.EnumerateArray())
            {
                _reports.Add(new ReportRow
                {
                    Report = GetJsonString(report, "Report"),
                    Category = GetJsonString(report, "Category"),
                    Status = GetJsonString(report, "Status"),
                    Uploaded = File.GetLastWriteTime(path).ToString("yyyy-MM-dd HH:mm"),
                    Path = path,
                });
            }
        }

        if (root.TryGetProperty("processedFiles", out var processedFiles) && processedFiles.ValueKind == JsonValueKind.Array)
        {
            foreach (var file in processedFiles.EnumerateArray())
            {
                AddOrReplaceProcessedFile(new ProcessedFile
                {
                    Active = GetJsonBool(file, "Active"),
                    File = GetJsonString(file, "File"),
                    Type = GetJsonString(file, "Type"),
                    Feeds = GetJsonString(file, "Feeds"),
                    Status = GetJsonString(file, "Status"),
                    Label = GetJsonString(file, "Label"),
                    Locked = GetJsonBool(file, "Locked"),
                    Uploaded = File.Exists(ResolvePreviewPath(GetJsonString(file, "Path")))
                        ? File.GetLastWriteTime(ResolvePreviewPath(GetJsonString(file, "Path"))).ToString("yyyy-MM-dd HH:mm")
                        : "",
                    Path = GetJsonString(file, "Path"),
                });
            }
        }

        AddExampleProcessedDatasetFiles();
        LoadBuiltModelStorage();
#pragma warning restore CS0162
    }

    // Adds a processed-file row after filtering out staged or unprocessed source files.
    private void AddOrReplaceProcessedFile(ProcessedFile file)
    {
        if (!IsProcessedStorageFile(file))
        {
            return;
        }

        var existing = _processedFiles.FirstOrDefault(current => string.Equals(current.File, file.File, StringComparison.OrdinalIgnoreCase));
        if (existing is not null)
        {
            _processedFiles.Remove(existing);
        }

        _processedFiles.Add(file);
    }

    // Keeps the processed storage free of example model files; model JSON belongs in model storage.
    private void AddDefaultProcessedFiles()
    {
    }

    // Determines whether a row belongs in processed storage rather than source-file storage.
    private static bool IsProcessedStorageFile(ProcessedFile file)
    {
        if (string.IsNullOrWhiteSpace(file.File))
        {
            return false;
        }

        if ((file.File.Equals("example-processed-feeder-model.json", StringComparison.OrdinalIgnoreCase)
                || file.File.Equals("example.roa_model.json", StringComparison.OrdinalIgnoreCase))
            && (file.Status.Equals("Example", StringComparison.OrdinalIgnoreCase)
                || file.Uploaded.Contains("example", StringComparison.OrdinalIgnoreCase)
                || file.Path.Contains("example", StringComparison.OrdinalIgnoreCase)
                || file.Path.Contains("config", StringComparison.OrdinalIgnoreCase)))
        {
            return false;
        }

        if (file.Status.Contains("unprocessed", StringComparison.OrdinalIgnoreCase)
            || file.Status.Contains("staged", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        if (file.File.EndsWith(".roa_model.json", StringComparison.OrdinalIgnoreCase)
            || file.File.Contains("model-", StringComparison.OrdinalIgnoreCase) && file.File.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        return file.Type.Contains("processed", StringComparison.OrdinalIgnoreCase)
            || file.Feeds.Contains("model", StringComparison.OrdinalIgnoreCase)
            || file.Feeds.Contains("map", StringComparison.OrdinalIgnoreCase);
    }

    // Adds optional large example dataset files from the local example-data folder.
    private void AddExampleProcessedDatasetFiles()
    {
        var folder = Path.Combine(AppContext.BaseDirectory, "data", "example", "ROA_large_processed_dataset");
        if (!Directory.Exists(folder))
        {
            folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", "..", "..", "data", "example", "ROA_large_processed_dataset");
            folder = Path.GetFullPath(folder);
        }

        if (!Directory.Exists(folder))
        {
            folder = Path.Combine(Environment.CurrentDirectory, "data", "example", "ROA_large_processed_dataset");
        }

        if (!Directory.Exists(folder))
        {
            return;
        }

        foreach (var entry in new[]
                 {
                     ("nodes.csv", "Processed nodes", "Model, Map"),
                     ("lines.csv", "Processed lines", "Model, Map"),
                     ("loads.csv", "Processed loads", "Model, SAIDI/SAIFI"),
                     ("transformers.csv", "Processed transformers", "Model"),
                     ("switches.csv", "Processed switches", "Model"),
                     ("protection.csv", "Processed protection devices", "Protection, Optimization"),
                     ("feeders.csv", "Processed feeders", "Model"),
                     ("network.geojson", "Processed network geometry", "Map"),
                 })
        {
            var path = Path.Combine(folder, entry.Item1);
            if (!File.Exists(path))
            {
                continue;
            }

            var isModelInput = entry.Item1.Equals("nodes.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("lines.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("loads.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("transformers.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("switches.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("protection.csv", StringComparison.OrdinalIgnoreCase)
                || entry.Item1.Equals("feeders.csv", StringComparison.OrdinalIgnoreCase);

            AddOrReplaceProcessedFile(new ProcessedFile
            {
                Active = isModelInput,
                File = entry.Item1,
                Type = entry.Item2,
                Feeds = entry.Item3,
                Status = "Processed",
                Label = "Example",
                Uploaded = File.GetLastWriteTime(path).ToString("yyyy-MM-dd HH:mm"),
                Path = path,
            });
        }
    }

    // Reads built model JSON files for the current project and refreshes model selectors.
    private void LoadBuiltModelStorage()
    {
        _builtModels.Clear();
        var currentProject = _workspaceStore.CurrentProject(_workspaceState);
        var builtModelsPath = _workspaceStore.BuiltModelsPath(_workspaceState);
        foreach (var file in Directory.EnumerateFiles(builtModelsPath, "*.json").OrderByDescending(File.GetLastWriteTimeUtc))
        {
            if (!TryLoadBuiltModelForCurrentProject(file, out var model))
            {
                continue;
            }

            _builtModels.Add(new ProcessedFile
            {
                Active = false,
                File = Path.GetFileName(file),
                Type = "Built model",
                Feeds = "Map, Optimization, Reports",
                Status = model.Id == currentProject.Settings.ActiveModelId ? "Active" : "Saved",
                Label = "Project model",
                Locked = File.GetAttributes(file).HasFlag(FileAttributes.ReadOnly),
                Uploaded = File.GetLastWriteTime(file).ToString("yyyy-MM-dd HH:mm"),
                Path = file,
            });
        }

        RefreshModelLayerSelectors();
        RefreshWorkingDirectoryStorage();
        RefreshDashboard();
    }

    // Reads a built model only when its embedded ProjectId belongs to the active project.
    private bool TryLoadBuiltModelForCurrentProject(string path, out BuiltModelRecord model)
    {
        model = new BuiltModelRecord();
        if (!File.Exists(path))
        {
            return false;
        }

        try
        {
            var loaded = JsonSerializer.Deserialize<BuiltModelRecord>(File.ReadAllText(path), _jsonOptions);
            if (loaded is null)
            {
                return false;
            }

            var project = _workspaceStore.CurrentProject(_workspaceState);
            if (!loaded.ProjectId.Equals(project.Id, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            model = loaded;
            return true;
        }
        catch
        {
            return false;
        }
    }

    // Updates dashboard summary cards from the active project model and current storage state.
    private void RefreshDashboard()
    {
        var project = _workspaceStore.CurrentProject(_workspaceState);
        var activeModel = _builtModels.FirstOrDefault(model => Path.GetFileNameWithoutExtension(model.File).Equals(project.Settings.ActiveModelId, StringComparison.OrdinalIgnoreCase))
            ?? _builtModels.FirstOrDefault(model => model.Status.Equals("Active", StringComparison.OrdinalIgnoreCase));
        var model = activeModel is not null && File.Exists(activeModel.Path)
            ? LoadSelectedMapModel(activeModel.Path)
            : null;

        if (model is null)
        {
            DashboardModelHeadingText.Text = "No feeder model loaded";
            DashboardFeederCountText.Text = "0";
            DashboardFeederSummaryText.Text = "Build a model from processed data to populate feeders";
            DashboardProtectionCountText.Text = "0";
            DashboardProtectionSummaryText.Text = "Protection devices will appear once a model is active";
            DashboardCustomerCountText.Text = "0";
            DashboardCustomerSummaryText.Text = "Customer groupings not imported";
            DashboardIssueCountText.Text = "0";
            DashboardIssueSummaryText.Text = "No model has been validated yet";
            DashboardWorkflowStatusText.Text = _processedFiles.Count > 0 ? "Processed data ready" : "Ready for source data";
            DashboardWorkflowDetailText.Text = $"{_imports.Count} source file(s), {_processedFiles.Count} processed file(s), {_builtModels.Count} project model(s), {_reports.Count} saved report(s).";
            DashboardReliabilityText.Text = "SAIDI/SAIFI will appear after a model is built or assessed.";
            UpdateMapReliabilityProjection(null);
            RefreshOptimizationAreaSelector(null);
            RefreshModelExplorer(null);
            return;
        }

        var reliabilitySnapshot = ReliabilitySnapshotForModel(model);
        var reliability = reliabilitySnapshot.Optimized.Saidi > 0 ? reliabilitySnapshot.Optimized : reliabilitySnapshot.Baseline;
        var issueCount = model.ValidationMessages.Count(message => message.Contains("missing", StringComparison.OrdinalIgnoreCase)
            || message.Contains("error", StringComparison.OrdinalIgnoreCase)
            || message.Contains("warning", StringComparison.OrdinalIgnoreCase));

        DashboardModelHeadingText.Text = model.Name;
        DashboardFeederCountText.Text = model.CartesianMap.Feeders.Count.ToString("N0");
        DashboardFeederSummaryText.Text = $"{model.CartesianMap.Edges.Count:N0} lines, {model.CartesianMap.Nodes.Count:N0} map nodes";
        DashboardProtectionCountText.Text = model.CartesianMap.ProtectionDevices.Count.ToString("N0");
        DashboardProtectionSummaryText.Text = $"{model.CartesianMap.ProtectionDevices.Count(device => device.AssetType.Contains("recloser", StringComparison.OrdinalIgnoreCase)):N0} recloser/protection records";
        DashboardCustomerCountText.Text = reliability.Customers.ToString("N0");
        DashboardCustomerSummaryText.Text = $"{model.CartesianMap.Loads.Count:N0} load records represented";
        DashboardIssueCountText.Text = issueCount.ToString("N0");
        DashboardIssueSummaryText.Text = issueCount == 0 ? "No active model warnings recorded" : "Review model validation messages before export";
        DashboardWorkflowStatusText.Text = $"Active model: {model.Id}";
        DashboardWorkflowDetailText.Text = $"Storage: {_workingDirectoryFiles.Count} current project file(s), {_reports.Count} saved report(s).";
        DashboardReliabilityText.Text = $"Reliability: SAIDI {reliability.Saidi:N2} min/customer/year, SAIFI {reliability.Saifi:N3} interruptions/customer/year, CAIDI {reliability.Caidi:N2} min/interruption.";
        UpdateMapReliabilityProjection(model);
        RefreshOptimizationAreaSelector(model);
        RefreshModelExplorer(model);
    }

    // Rebuilds the optimization area dropdown from the current model's feeders.
    private void RefreshOptimizationAreaSelector(BuiltModelRecord? model)
    {
        OptimizationAreaCombo.Items.Clear();
        if (model is null)
        {
            OptimizationAreaCombo.Items.Add(new ComboBoxItem { Content = "No model selected" });
            OptimizationAreaCombo.SelectedIndex = 0;
            return;
        }

        OptimizationAreaCombo.Items.Add(new ComboBoxItem { Content = "Complete model" });
        foreach (var feeder in model.CartesianMap.Feeders.OrderBy(feeder => feeder.Id))
        {
            var checkBox = new CheckBox
            {
                Content = $"{feeder.Id} - {feeder.Name}",
                IsChecked = CompleteModelSelectionToggle.IsChecked == true,
                ToolTip = $"Include feeder {feeder.Id} in the optimization area.",
            };
            OptimizationAreaCombo.Items.Add(new ComboBoxItem { Content = checkBox, Tag = feeder.Id });
        }

        OptimizationAreaCombo.SelectedIndex = 0;
    }

    // Applies the complete-model toggle to every feeder checkbox in the optimization area dropdown.
    private void SetOptimizationAreaChecks(bool isChecked)
    {
        foreach (var item in OptimizationAreaCombo.Items.OfType<ComboBoxItem>())
        {
            if (item.Content is CheckBox checkBox)
            {
                checkBox.IsChecked = isChecked;
            }
        }
    }

    private readonly record struct ReliabilitySnapshot(ReliabilityMetricsRecord Baseline, ReliabilityMetricsRecord Optimized, string BaselineModelId, string OptimizedModelId);

    // Returns baseline reliability and the selected/best linked optimized reliability for the supplied model.
    private ReliabilitySnapshot ReliabilitySnapshotForModel(BuiltModelRecord? model)
    {
        if (model is null)
        {
            return new ReliabilitySnapshot(new ReliabilityMetricsRecord(), new ReliabilityMetricsRecord(), "", "");
        }

        if (IsOptimizedModel(model))
        {
            var baseline = LoadLinkedBaselineModel(model)?.BaselineReliability ?? model.BaselineReliability;
            return new ReliabilitySnapshot(baseline, model.Optimization.Improved, LinkedBaselineModelId(model), model.Id);
        }

        var bestOptimized = FindBestOptimizedModelForBaseline(model.Id);
        return bestOptimized is null
            ? new ReliabilitySnapshot(model.BaselineReliability, model.BaselineReliability, model.Id, "")
            : new ReliabilitySnapshot(model.BaselineReliability, bestOptimized.Optimization.Improved, model.Id, bestOptimized.Id);
    }

    // Checks whether a model contains an optimization result that should be compared against a baseline.
    private static bool IsOptimizedModel(BuiltModelRecord model)
    {
        return model.Optimization.Improved.Saidi > 0
            || model.Optimization.Improved.Saifi > 0
            || model.Optimization.Recommendations.Count > 0;
    }

    // Reads the baseline model linked from an optimized model, falling back to blank when missing.
    private BuiltModelRecord? LoadLinkedBaselineModel(BuiltModelRecord optimizedModel)
    {
        var baselineId = LinkedBaselineModelId(optimizedModel);
        if (string.IsNullOrWhiteSpace(baselineId))
        {
            return null;
        }

        var path = Path.Combine(_workspaceStore.BuiltModelsPath(_workspaceState), $"{baselineId}.json");
        return File.Exists(path) && TryLoadBuiltModelForCurrentProject(path, out var model) ? model : null;
    }

    // Finds the best optimized model linked to the supplied baseline, based on lowest SAIDI then SAIFI.
    private BuiltModelRecord? FindBestOptimizedModelForBaseline(string baselineModelId)
    {
        var path = _workspaceStore.BuiltModelsPath(_workspaceState);
        if (!Directory.Exists(path))
        {
            return null;
        }

        return Directory.EnumerateFiles(path, "*.json")
            .Select(file => TryLoadBuiltModelForCurrentProject(file, out var model) ? model : null)
            .Where(model => model is not null && IsOptimizedModel(model) && LinkedBaselineModelId(model).Equals(baselineModelId, StringComparison.OrdinalIgnoreCase))
            .OrderBy(model => model!.Optimization.Improved.Saidi <= 0 ? double.MaxValue : model.Optimization.Improved.Saidi)
            .ThenBy(model => model!.Optimization.Improved.Saifi <= 0 ? double.MaxValue : model.Optimization.Improved.Saifi)
            .FirstOrDefault();
    }

    // Resolves a model's baseline ID from current and older saved model shapes.
    private static string LinkedBaselineModelId(BuiltModelRecord model)
    {
        return !string.IsNullOrWhiteSpace(model.Optimization.BaselineModelId)
            ? model.Optimization.BaselineModelId
            : !string.IsNullOrWhiteSpace(model.BaselineModelId)
                ? model.BaselineModelId
                : IsOptimizedModel(model) ? "" : model.Id;
    }

    // Updates the map-side SAIDI/SAIFI projection from linked baseline and optimized model values.
    private void UpdateMapReliabilityProjection(BuiltModelRecord? model)
    {
        if (model is null)
        {
            MapBaselineReliabilityText.Text = "-- / --";
            MapCurrentReliabilityText.Text = "-- / --";
            MapReliabilityImprovementText.Text = "-- / --";
            MapReliabilityConfidenceText.Text = "no model";
            return;
        }

        var snapshot = ReliabilitySnapshotForModel(model);
        var baseline = snapshot.Baseline;
        var current = snapshot.Optimized;
        MapBaselineReliabilityText.Text = $"{baseline.Saidi:N2} / {baseline.Saifi:N3}";
        MapCurrentReliabilityText.Text = $"{current.Saidi:N2} / {current.Saifi:N3}";
        MapReliabilityImprovementText.Text = $"{Math.Max(0, baseline.Saidi - current.Saidi):N2} / {Math.Max(0, baseline.Saifi - current.Saifi):N3}";
        MapReliabilityConfidenceText.Text = string.IsNullOrWhiteSpace(snapshot.OptimizedModelId) ? "baseline only" : $"linked {snapshot.BaselineModelId}";
    }

    // Rebuilds the model explorer tree from the active/selected built model.
    private void RefreshModelExplorer(BuiltModelRecord? model)
    {
        ModelExplorerTree.Items.Clear();
        if (model is null)
        {
            ModelExplorerTree.Items.Add(new TreeViewItem { Header = "No project model selected" });
            return;
        }

        var root = new TreeViewItem { Header = $"{model.Name} ({model.Id})", IsExpanded = true };
        var feeders = new TreeViewItem { Header = $"Feeders ({model.CartesianMap.Feeders.Count:N0})", IsExpanded = true };
        foreach (var feeder in model.CartesianMap.Feeders.Take(30))
        {
            var lineCount = model.CartesianMap.Edges.Count(edge => edge.FeederId.Equals(feeder.Id, StringComparison.OrdinalIgnoreCase));
            var loadCount = model.CartesianMap.Loads.Count(load => load.FeederId.Equals(feeder.Id, StringComparison.OrdinalIgnoreCase));
            feeders.Items.Add(new TreeViewItem { Header = $"{feeder.Id} - {feeder.Name} ({lineCount:N0} lines, {loadCount:N0} loads)" });
        }

        var protection = new TreeViewItem { Header = $"Protection devices ({model.CartesianMap.ProtectionDevices.Count:N0})" };
        foreach (var device in model.CartesianMap.ProtectionDevices.Take(40))
        {
            protection.Items.Add(new TreeViewItem { Header = $"{device.Id} - {device.AssetType} at {device.NodeId}" });
        }

        var switches = new TreeViewItem { Header = $"Switches ({model.CartesianMap.Switches.Count:N0})" };
        foreach (var switchRecord in model.CartesianMap.Switches.Take(40))
        {
            switches.Items.Add(new TreeViewItem { Header = $"{switchRecord.Id} - {switchRecord.SwitchType} at {switchRecord.NodeId}" });
        }

        var reliability = model.Optimization.Improved.Saidi > 0 ? model.Optimization.Improved : model.BaselineReliability;
        var reliabilityNode = new TreeViewItem { Header = $"Reliability: SAIDI {reliability.Saidi:N2}, SAIFI {reliability.Saifi:N3}, CAIDI {reliability.Caidi:N2}" };
        root.Items.Add(feeders);
        root.Items.Add(protection);
        root.Items.Add(switches);
        root.Items.Add(reliabilityNode);
        ModelExplorerTree.Items.Add(root);
    }

    // Rebuilds the header and map model dropdowns from saved built-model storage.
    private void RefreshModelLayerSelectors()
    {
        _isRefreshingModelSelectors = true;
        var selectedMapModel = SelectedComboText(MapModelCombo);
        var selectedHeaderModel = SelectedComboText(HeaderModelCombo);
        var selectedRunSetupModel = SelectedComboText(RunSetupModelCombo);
        var activeModelId = _workspaceStore.CurrentProject(_workspaceState).Settings.ActiveModelId;

        MapModelCombo.Items.Clear();
        MapModelCombo.Items.Add(new ComboBoxItem { Content = "Baseline processed model layer" });

        HeaderModelCombo.Items.Clear();
        HeaderModelCombo.Items.Add(new ComboBoxItem { Content = "Baseline processed model" });
        HeaderModelCombo.Items.Add(new ComboBoxItem { Content = "Custom model" });

        RunSetupModelCombo.Items.Clear();

        foreach (var modelFile in _builtModels)
        {
            var name = Path.GetFileNameWithoutExtension(modelFile.File);
            var display = $"{name} model layer";
            MapModelCombo.Items.Add(new ComboBoxItem { Content = display, Tag = modelFile.Path });
            HeaderModelCombo.Items.Add(new ComboBoxItem { Content = name, Tag = modelFile.Path });
            RunSetupModelCombo.Items.Add(new ComboBoxItem { Content = name, Tag = modelFile.Path });
        }

        var preferredMapModel = !string.IsNullOrWhiteSpace(activeModelId)
            && (string.IsNullOrWhiteSpace(selectedMapModel)
                || selectedMapModel.Equals("Baseline processed model layer", StringComparison.OrdinalIgnoreCase)
                || selectedMapModel.Equals("Optimized vector map layer", StringComparison.OrdinalIgnoreCase))
            ? $"{activeModelId} model layer"
            : selectedMapModel;
        var preferredHeaderModel = !string.IsNullOrWhiteSpace(activeModelId)
            && (string.IsNullOrWhiteSpace(selectedHeaderModel)
                || selectedHeaderModel.Equals("Baseline processed model", StringComparison.OrdinalIgnoreCase)
                || selectedHeaderModel.Equals("Optimized model draft", StringComparison.OrdinalIgnoreCase)
                || selectedHeaderModel.Equals("Custom model", StringComparison.OrdinalIgnoreCase))
            ? activeModelId
            : selectedHeaderModel;
        var preferredRunSetupModel = !string.IsNullOrWhiteSpace(activeModelId)
            && (string.IsNullOrWhiteSpace(selectedRunSetupModel) || selectedRunSetupModel.Equals("Baseline processed model", StringComparison.OrdinalIgnoreCase))
            ? activeModelId
            : selectedRunSetupModel;

        SelectComboContent(MapModelCombo, preferredMapModel);
        SelectComboContent(HeaderModelCombo, preferredHeaderModel);
        SelectComboContent(RunSetupModelCombo, preferredRunSetupModel);
        _isRefreshingModelSelectors = false;
    }

    // Makes the selected model the active project model and refreshes dependent dashboard/explorer views.
    private void ActivateModelFromSelector(ComboBox combo, bool centerMap)
    {
        if (_isRefreshingModelSelectors || combo.SelectedItem is not ComboBoxItem item)
        {
            return;
        }

        var path = item.Tag?.ToString() ?? "";
        if (string.IsNullOrWhiteSpace(path) || !TryLoadBuiltModelForCurrentProject(path, out var model))
        {
            SetStatus("Select a saved model from the current project");
            RefreshDashboard();
            return;
        }

        var project = _workspaceStore.CurrentProject(_workspaceState);
        project.Settings.ActiveModelId = model.Id;
        project.UpdatedAt = DateTime.UtcNow;
        _workspaceStore.Save(_workspaceState);
        LoadBuiltModelStorage();
        if (centerMap)
        {
            CenterMapOnCartesianMap(model.CartesianMap);
        }

        RefreshDashboard();
        RequestMapRender();
        SetStatus($"Active project model selected: {model.Id}");
    }

    // Selects the matching combo item by displayed text, defaulting to the first item.
    private static void SelectComboContent(ComboBox combo, string preferred)
    {
        for (var i = 0; i < combo.Items.Count; i++)
        {
            if (combo.Items[i] is ComboBoxItem item && string.Equals(item.Content?.ToString(), preferred, StringComparison.OrdinalIgnoreCase))
            {
                combo.SelectedIndex = i;
                return;
            }
        }

        combo.SelectedIndex = combo.Items.Count > 0 ? 0 : -1;
    }

    // Reads an optional JSON property as a string without throwing on missing values.
    private static string GetJsonString(JsonElement element, string propertyName)
    {
        return element.TryGetProperty(propertyName, out var property) ? property.ToString() : "";
    }

    // Reads an optional JSON property as a strict true/false flag.
    private static bool GetJsonBool(JsonElement element, string propertyName)
    {
        return element.TryGetProperty(propertyName, out var property) && property.ValueKind == JsonValueKind.True;
    }

    // Resolves config files from either the published output folder or the source checkout.
    private static string ResolveConfigPath(string fileName)
    {
        var outputPath = Path.Combine(AppContext.BaseDirectory, "Config", fileName);
        if (File.Exists(outputPath))
        {
            return outputPath;
        }

        return Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", "..", "..", "config", fileName));
    }
}
