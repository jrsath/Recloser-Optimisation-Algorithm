using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using RecloserOptimisation.App.Models;
using WinForms = System.Windows.Forms;

namespace RecloserOptimisation.App;
public partial class MainWindow
{
    // Processing mode widgets and the staged processing queue.

    // Switches the processing page between overview, validation, analysis, outages, and ablation widgets.
    private void ApplyProcessingMode()
    {
        var mode = SelectedComboText(ProcessingModeCombo);
        ProcessingWidgetTitle.Text = mode;
        ProcessingDetailText.Text = mode switch
        {
            "Data validation" => "Check selected files for missing attributes, connectivity gaps, coordinate confidence and file freshness.",
            "Analysis" => "Review SAIDI, SAIFI, baseline comparison and recloser location efficiency once model outputs are connected.",
            "Outages" => "Inspect outage patterns from OMS-style processed outputs.",
            "Ablation study" => "Choose which optimization inputs are included in comparison runs.",
            _ => "Stage individual files or batches, choose a ruleset, set an order and generate processed outputs when algorithms are connected.",
        };

        ProcessingOverviewWidget.Visibility = mode == "Processing overview" ? Visibility.Visible : Visibility.Collapsed;
        ValidationWidget.Visibility = mode == "Data validation" ? Visibility.Visible : Visibility.Collapsed;
        AnalysisWidget.Visibility = mode == "Analysis" ? Visibility.Visible : Visibility.Collapsed;
        OutagesWidget.Visibility = mode == "Outages" ? Visibility.Visible : Visibility.Collapsed;
        AblationWidget.Visibility = mode == "Ablation study" ? Visibility.Visible : Visibility.Collapsed;
        SetStatus($"Processing view: {mode}");
        RenderRadar();
    }

    // Shows or hides the staged processing queue panel.
    private void ToggleStagedProcessingPanel()
    {
        StagedProcessingPanel.Visibility = StagedProcessingPanel.Visibility == Visibility.Visible
            ? Visibility.Collapsed
            : Visibility.Visible;
        SetStatus(StagedProcessingPanel.Visibility == Visibility.Visible ? "Viewing staged processing queue" : "Staged processing queue hidden");
    }

    // Shows or hides the source-file picker used to select files for processing.
    private void ToggleProcessingFileSelection()
    {
        ProcessingSourceFilesExpander.Visibility = ProcessingSourceFilesExpander.Visibility == Visibility.Visible
            ? Visibility.Collapsed
            : Visibility.Visible;
        ProcessingSourceFilesExpander.IsExpanded = ProcessingSourceFilesExpander.Visibility == Visibility.Visible;

        SetStatus(ProcessingSourceFilesExpander.Visibility == Visibility.Visible
            ? "Select source files to add them to processing"
            : "Source file selection hidden");
    }

    private void RefreshSelectedProcessingFilesFromActiveSources()
    {
        _selectedProcessingFiles.Clear();
        foreach (var source in _imports.Where(file => file.Active))
        {
            _selectedProcessingFiles.Add(source);
        }

        SelectedProcessingFilesCombo.Items.Refresh();
        SetStatus($"{_selectedProcessingFiles.Count} active source file(s) selected for processing");
    }

    // Processes the selected source files into saved prototype processed-output records.
    private void StageProcessing()
    {
        var files = FilesForProcessingSelection().ToList();
        if (files.Count == 0)
        {
            SetStatus("Select source files before beginning processing");
            return;
        }

        var baseOrder = int.TryParse(ProcessingOrderBox.Text, out var parsedOrder) ? parsedOrder : _processingQueue.Count + 1;
        var task = SelectedComboText(ProcessingModeCombo);
        var ruleset = SelectedComboText(RulesetCombo);

        for (var i = 0; i < files.Count; i++)
        {
            var sourceFile = files[i];
            var uploadedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
            var processedPath = WriteProcessedOutputFile(sourceFile, uploadedAt);
            _processingQueue.Add(new ProcessingQueueItem
            {
                Order = baseOrder + i,
                File = sourceFile.File,
                Task = task,
                Ruleset = ruleset,
                Status = "Processed",
            });

            sourceFile.Active = true;
            sourceFile.Status = "Processed";
            AddOrReplaceProcessedFile(new ProcessedFile
            {
                Active = true,
                File = ProcessedOutputName(sourceFile.File),
                Type = ProcessedOutputType(sourceFile),
                Feeds = "Current project, Model, Map",
                Status = "Processed",
                Label = "Processed data",
                Uploaded = uploadedAt,
                Path = processedPath,
            });
        }

        SaveProjectStorageMetadata();
        StagedProcessingPanel.Visibility = Visibility.Visible;
        PauseProcessingButton.Visibility = Visibility.Visible;
        RunProcessingButton.Visibility = Visibility.Visible;
        ImportsGrid.Items.Refresh();
        ProcessingQueueGrid.Items.Refresh();
        ProcessedFilesGrid.Items.Refresh();
        SetStatus($"{files.Count} source file(s) processed into current project storage");
    }

    // Writes the processed metadata JSON that links a processed output back to its source file.
    private string WriteProcessedOutputFile(StagedImport sourceFile, string uploadedAt)
    {
        var folder = _workspaceStore.ProjectFolder(_workspaceState, "processed-files");
        var outputName = ProcessedOutputName(sourceFile.File);
        var outputPath = Path.Combine(folder, outputName);

        var payload = new
        {
            File = outputName,
            OriginalFile = sourceFile.File,
            SourcePath = sourceFile.Path,
            SourceType = sourceFile.Source,
            SourceFormat = sourceFile.Format,
            Uploaded = uploadedAt,
            Status = "Processed",
            Notes = "Prototype processed output. Real parser will normalize this into cartesian-map inputs.",
        };

        File.WriteAllText(outputPath, JsonSerializer.Serialize(payload, _jsonOptions));
        return outputPath;
    }

    // Builds the saved processed-output filename for a staged source file.
    private static string ProcessedOutputName(string sourceFile)
    {
        var name = Path.GetFileNameWithoutExtension(sourceFile);
        return string.IsNullOrWhiteSpace(name) ? "processed-output.roa_model.json" : $"{name}.processed.roa_model.json";
    }

    // Classifies a processed output as map/model or model-only based on source metadata.
    private static string ProcessedOutputType(StagedImport sourceFile)
    {
        return sourceFile.Source.Contains("GIS", StringComparison.OrdinalIgnoreCase)
            || sourceFile.Format.Contains("GeoJSON", StringComparison.OrdinalIgnoreCase)
            ? "Processed map/model layer"
            : "Processed project model input";
    }

    // Resolves the current processing scope into the staged source files that should be processed.
    private IEnumerable<StagedImport> FilesForProcessingSelection()
    {
        if (_selectedProcessingFiles.Count > 0)
        {
            return _selectedProcessingFiles;
        }

        var scope = SelectedComboText(ProcessingSelectionCombo);
        if (scope == "Selected file" && ImportsGrid.SelectedItem is StagedImport selected)
        {
            return new[] { selected };
        }

        if (scope == "All unprocessed files")
        {
            return _imports.Where(file => file.Status.Equals("Unprocessed", StringComparison.OrdinalIgnoreCase));
        }

        return _importsView.Cast<StagedImport>();
    }

    // Clears the processing queue and selected source files, returning processing controls to idle state.
    private void ClearStagedProcessing()
    {
        _processingQueue.Clear();
        _selectedProcessingFiles.Clear();
        StagedProcessingPanel.Visibility = Visibility.Collapsed;
        ProcessingSourceFilesExpander.Visibility = Visibility.Collapsed;
        PauseProcessingButton.Visibility = Visibility.Collapsed;
        RunProcessingButton.Visibility = Visibility.Collapsed;
        SetStatus("Processing stopped and staged queue cleared");
    }

    // Updates every queued processing item to a shared run state such as paused or running.
    private void SetProcessingRunState(string state)
    {
        foreach (var item in _processingQueue)
        {
            item.Status = state;
        }

        ProcessingQueueGrid.Items.Refresh();
        SetStatus($"Processing {state.ToLowerInvariant()}");
    }

    // Handles ruleset dropdown changes, including the create-new-ruleset placeholder.
    private void ApplyRulesetSelection()
    {
        var ruleset = SelectedComboText(RulesetCombo);
        if (ruleset.Contains("Create", StringComparison.OrdinalIgnoreCase))
        {
            SetStatus("New ruleset selection window placeholder opened");
            return;
        }

        SetStatus($"Adapter plan selected: {ruleset}");
    }
}
