using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App;

public partial class MainWindow
{
    // Small workflow actions for dialogs and placeholders that are not algorithm-backed yet.

    // Updates the UI with the intended report creation workflow until full report generation is connected.
    private void CreateReport()
    {
        SetStatus("Create report: choose report sections from model, validation, outages and optimization outputs");
    }

    // Shows the planned reverse-adapter export workflow for downstream model formats.
    private void CreateOutputFiles()
    {
        SetStatus("Create output files: reverse adapters will export the selected model to PowerFactory, ETAP or GIS formats");
    }

    // Prompts for an external map layer file and records the import action in the status bar.
    private void ImportMapLayer()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Import map layer",
            Filter = "Map layers|*.json;*.geojson;*.shp;*.zip;*.gpkg;*.kml;*.kmz|All files|*.*",
        };

        if (dialog.ShowDialog(this) == true)
        {
            SetStatus($"Map layer imported: {Path.GetFileName(dialog.FileName)}");
        }
    }

    // Prompts for an import template file that can guide source-file ingestion.
    private void ImportTemplate()
    {
        var dialog = new OpenFileDialog
        {
            Title = "Import template",
            Filter = "Templates|*.json;*.csv;*.xlsx;*.xml;*.txt|All files|*.*",
        };

        if (dialog.ShowDialog(this) == true)
        {
            SetStatus($"Template imported: {Path.GetFileName(dialog.FileName)}");
        }
    }

    // Adds a temporary marker at the current map centre for manual map inspection.
    private void DropMapMarker()
    {
        DrawMarker(MapHost.ActualWidth / 2.0, MapHost.ActualHeight / 2.0, "#1559C9", "M");
        MapInfoText.Text = $"Marker dropped at Lat {_centerLat:N5}, Lng {_centerLng:N5}. Height/elevation will populate when an elevation layer is connected.";
        SetStatus("Map marker dropped at current map centre");
    }

    // Announces the selected map optimization action before the optimizer host is implemented.
    private void RunMapOptimization()
    {
        SetStatus($"Run optimization: select algorithm '{SelectedComboText(OptimizationAlgorithmCombo)}' and print the output model on the map");
    }

    // Displays the placeholder candidate-site comparison results.
    private void CompareCandidateSites()
    {
        MessageBox.Show(
            this,
            "Best candidate comparison placeholder:\n\n1. REC-CAND-001 - highest SAIDI reduction\n2. REC-CAND-002 - best access score\n3. REC-CAND-003 - lowest protection risk",
            "Compare Candidate Sites",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    // Enables the future comparison overlay mode for baseline, optimized, and custom models.
    private void EnableComparisonMode()
    {
        SetStatus("Comparison mode enabled: saved baseline, optimized and custom models will overlay when model storage is populated");
    }

    // Saves a generated single-line diagram into report storage and refreshes the preview.
    private void SaveSingleLineDiagram()
    {
        var model = LoadModelForSingleLineDiagram();
        if (model is null)
        {
            SetStatus("Select or build a project model before saving a single line diagram");
            return;
        }

        var folder = _workspaceStore.ProjectFolder(_workspaceState, "reports");
        var sldFolder = Path.Combine(folder, "single-line-diagrams");
        Directory.CreateDirectory(sldFolder);
        var id = $"sld-{DateTime.Now:yyyyMMdd-HHmmss}";
        var diagram = BuildSingleLineDiagram(model);
        var jsonPath = Path.Combine(sldFolder, $"{id}.sld.json");
        var svgPath = Path.Combine(sldFolder, $"{id}.svg");
        File.WriteAllText(jsonPath, JsonSerializer.Serialize(diagram, _jsonOptions));
        File.WriteAllText(svgPath, BuildSingleLineDiagramSvg(diagram));

        _lastSingleLineDiagramJsonPath = jsonPath;
        _lastSingleLineDiagramSvgPath = svgPath;
        _lastSingleLineDiagramModel = model;
        _reports.Add(new ReportRow
        {
            Report = $"{id}.svg",
            Category = "SLD",
            Status = "Saved",
            Label = "Single line diagram",
            Uploaded = DateTime.Now.ToString("yyyy-MM-dd HH:mm"),
            Path = svgPath,
        });

        ReportsGrid.Items.Refresh();
        SavedReportsGrid.Items.Refresh();
        RenderSingleLineDiagramPreview(diagram);
        SetStatus($"Saved single line diagram to reports: {Path.GetFileName(svgPath)}");
    }

    private BuiltModelRecord? LoadModelForSingleLineDiagram()
    {
        var modelPath = SelectedMapModelPath();
        if (!string.IsNullOrWhiteSpace(modelPath) && File.Exists(modelPath))
        {
            return LoadSelectedMapModel(modelPath);
        }

        return LoadRunSetupBuiltModel();
    }

    private object BuildSingleLineDiagram(BuiltModelRecord model)
    {
        var nodeIds = model.CartesianMap.Nodes.Select(node => node.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var feeders = model.CartesianMap.Edges
            .Where(edge => edge.VoltageKv < 33)
            .GroupBy(edge => string.IsNullOrWhiteSpace(edge.FeederId) ? "Unknown feeder" : edge.FeederId, StringComparer.OrdinalIgnoreCase)
            .OrderBy(group => group.Key)
            .ToList();
        var palette = new[] { "#D64545", "#1D5ECF", "#2F9E44", "#F08C00", "#7048E8", "#0B7285", "#C2255C", "#5C940D" };
        var nodes = new List<object>();
        var edges = new List<object>();
        var issues = new List<object>();
        var y = 70.0;
        var feederIndex = 0;

        foreach (var feeder in feeders)
        {
            var color = palette[feederIndex % palette.Length];
            var levels = SldLevels(feeder.ToList());
            nodes.Add(new { id = feeder.Key, label = feeder.Key, x = 30, y, type = "FeederLabel", feeder = feeder.Key, color });

            foreach (var level in levels)
            {
                var row = 0;
                foreach (var nodeId in level.Value.OrderBy(value => value, StringComparer.OrdinalIgnoreCase))
                {
                    nodes.Add(new
                    {
                        id = nodeId,
                        label = nodeId,
                        x = 120 + level.Key * 80,
                        y = y + row * 24,
                        type = model.CartesianMap.Nodes.FirstOrDefault(node => node.Id.Equals(nodeId, StringComparison.OrdinalIgnoreCase))?.Type ?? "Junction",
                        feeder = feeder.Key,
                        color,
                    });
                    row++;
                }
            }

            foreach (var edge in feeder)
            {
                var missing = !nodeIds.Contains(edge.FromNode) || !nodeIds.Contains(edge.ToNode);
                edges.Add(new { id = edge.Id, from = edge.FromNode, to = edge.ToNode, feeder = feeder.Key, voltage = edge.VoltageKv, color, normallyEnergised = edge.NormallyEnergised });
                if (missing)
                {
                    issues.Add(new { id = edge.Id, message = $"Missing node reference {edge.FromNode}->{edge.ToNode}", feeder = feeder.Key });
                }
            }

            y += Math.Max(130, (levels.Values.Max(level => level.Count) + 2) * 28);
            feederIndex++;
        }

        foreach (var edge in model.CartesianMap.Edges.Where(edge => edge.VoltageKv >= 33))
        {
            edges.Add(new { id = edge.Id, from = edge.FromNode, to = edge.ToNode, feeder = "33 kV backbone", voltage = edge.VoltageKv, color = "#2458D6", normallyEnergised = edge.NormallyEnergised });
        }

        return new
        {
            id = $"sld-{DateTime.Now:yyyyMMdd-HHmmss}",
            model = model.Id,
            generatedAt = DateTimeOffset.Now,
            background = "white",
            nodes,
            edges,
            issues,
        };
    }

    private static Dictionary<int, List<string>> SldLevels(List<CartesianEdgeRecord> feederEdges)
    {
        var children = feederEdges.GroupBy(edge => edge.FromNode, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.Select(edge => edge.ToNode).Distinct(StringComparer.OrdinalIgnoreCase).ToList(), StringComparer.OrdinalIgnoreCase);
        var toNodes = feederEdges.Select(edge => edge.ToNode).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var roots = feederEdges.Select(edge => edge.FromNode).Where(node => !toNodes.Contains(node)).Distinct(StringComparer.OrdinalIgnoreCase).DefaultIfEmpty(feederEdges.FirstOrDefault()?.FromNode ?? "ROOT").ToList();
        var levels = new Dictionary<int, List<string>>();
        var queue = new Queue<(string Node, int Level)>(roots.Select(root => (root, 0)));
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        while (queue.Count > 0)
        {
            var (node, level) = queue.Dequeue();
            if (!seen.Add(node))
            {
                continue;
            }

            if (!levels.ContainsKey(level))
            {
                levels[level] = new List<string>();
            }

            levels[level].Add(node);
            if (children.TryGetValue(node, out var childNodes))
            {
                foreach (var child in childNodes)
                {
                    queue.Enqueue((child, level + 1));
                }
            }
        }

        return levels;
    }

    private void RenderLastSingleLineDiagramPreview()
    {
        if (_lastSingleLineDiagramModel is null)
        {
            return;
        }

        RenderSingleLineDiagramPreview(BuildSingleLineDiagram(_lastSingleLineDiagramModel));
    }

    private void RenderSingleLineDiagramPreview(object diagram)
    {
        SldPreviewCanvas.Children.Clear();
        SldPreviewCanvas.Background = Brushes.White;
        var json = JsonSerializer.Serialize(diagram);
        using var document = JsonDocument.Parse(json);
        var root = document.RootElement;
        var nodeLookup = new Dictionary<string, Point>(StringComparer.OrdinalIgnoreCase);
        var query = SldSearchBox.Text.StartsWith("Search", StringComparison.OrdinalIgnoreCase) ? "" : SldSearchBox.Text.Trim();

        foreach (var node in root.GetProperty("nodes").EnumerateArray())
        {
            var id = node.GetProperty("id").GetString() ?? "";
            var x = node.GetProperty("x").GetDouble();
            var y = node.GetProperty("y").GetDouble();
            nodeLookup[id] = new Point(x, y);
        }

        foreach (var edge in root.GetProperty("edges").EnumerateArray())
        {
            var from = edge.GetProperty("from").GetString() ?? "";
            var to = edge.GetProperty("to").GetString() ?? "";
            if (!nodeLookup.TryGetValue(from, out var a) || !nodeLookup.TryGetValue(to, out var b))
            {
                continue;
            }

            SldPreviewCanvas.Children.Add(new System.Windows.Shapes.Line
            {
                X1 = a.X,
                Y1 = a.Y,
                X2 = b.X,
                Y2 = b.Y,
                Stroke = BrushFrom(edge.GetProperty("color").GetString() ?? "#D64545"),
                StrokeThickness = edge.GetProperty("voltage").GetDouble() >= 33 ? 3 : 2,
                StrokeDashArray = edge.GetProperty("normallyEnergised").GetBoolean() ? null : new DoubleCollection { 6, 5 },
            });
        }

        foreach (var node in root.GetProperty("nodes").EnumerateArray())
        {
            var id = node.GetProperty("id").GetString() ?? "";
            var x = node.GetProperty("x").GetDouble();
            var y = node.GetProperty("y").GetDouble();
            var match = !string.IsNullOrWhiteSpace(query) && id.Contains(query, StringComparison.OrdinalIgnoreCase);
            var marker = new System.Windows.Shapes.Ellipse
            {
                Width = match ? 12 : 8,
                Height = match ? 12 : 8,
                Fill = node.GetProperty("type").GetString()?.Contains("substation", StringComparison.OrdinalIgnoreCase) == true ? BrushFrom("#2458D6") : Brushes.White,
                Stroke = BrushFrom(node.GetProperty("color").GetString() ?? "#39475D"),
                StrokeThickness = match ? 3 : 1.5,
            };
            Canvas.SetLeft(marker, x - marker.Width / 2);
            Canvas.SetTop(marker, y - marker.Height / 2);
            SldPreviewCanvas.Children.Add(marker);

            if (node.GetProperty("type").GetString() == "FeederLabel" || match)
            {
                var label = new TextBlock { Text = id, Foreground = BrushFrom("#132033"), FontSize = 12, FontWeight = FontWeights.SemiBold };
                Canvas.SetLeft(label, x);
                Canvas.SetTop(label, y - 18);
                SldPreviewCanvas.Children.Add(label);
            }
        }

        foreach (var issue in root.GetProperty("issues").EnumerateArray())
        {
            var square = new System.Windows.Shapes.Rectangle { Width = 12, Height = 12, Fill = BrushFrom("#E03131") };
            Canvas.SetLeft(square, 14);
            Canvas.SetTop(square, 22 + SldPreviewCanvas.Children.Count % 180);
            SldPreviewCanvas.Children.Add(square);
        }
    }

    private string BuildSingleLineDiagramSvg(object diagram)
    {
        var json = JsonSerializer.Serialize(diagram);
        using var document = JsonDocument.Parse(json);
        var root = document.RootElement;
        var nodeLookup = root.GetProperty("nodes").EnumerateArray()
            .ToDictionary(node => node.GetProperty("id").GetString() ?? "", node => (X: node.GetProperty("x").GetDouble(), Y: node.GetProperty("y").GetDouble()), StringComparer.OrdinalIgnoreCase);
        var lines = new List<string>
        {
            "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1600\" height=\"1200\" viewBox=\"0 0 1600 1200\">",
            "<rect width=\"100%\" height=\"100%\" fill=\"white\" />",
        };

        foreach (var edge in root.GetProperty("edges").EnumerateArray())
        {
            var from = edge.GetProperty("from").GetString() ?? "";
            var to = edge.GetProperty("to").GetString() ?? "";
            if (!nodeLookup.TryGetValue(from, out var a) || !nodeLookup.TryGetValue(to, out var b))
            {
                continue;
            }

            var dash = edge.GetProperty("normallyEnergised").GetBoolean() ? "" : " stroke-dasharray=\"8 6\"";
            lines.Add($"<line x1=\"{a.X:0.#}\" y1=\"{a.Y:0.#}\" x2=\"{b.X:0.#}\" y2=\"{b.Y:0.#}\" stroke=\"{edge.GetProperty("color").GetString()}\" stroke-width=\"2\"{dash} />");
        }

        foreach (var node in root.GetProperty("nodes").EnumerateArray())
        {
            var id = node.GetProperty("id").GetString() ?? "";
            var x = node.GetProperty("x").GetDouble();
            var y = node.GetProperty("y").GetDouble();
            lines.Add($"<circle cx=\"{x:0.#}\" cy=\"{y:0.#}\" r=\"4\" fill=\"white\" stroke=\"{node.GetProperty("color").GetString()}\" stroke-width=\"1.5\" />");
            if (node.GetProperty("type").GetString() == "FeederLabel")
            {
                lines.Add($"<text x=\"{x:0.#}\" y=\"{y - 10:0.#}\" font-family=\"Segoe UI\" font-size=\"13\" font-weight=\"600\">{System.Security.SecurityElement.Escape(id)}</text>");
            }
        }

        foreach (var issue in root.GetProperty("issues").EnumerateArray())
        {
            lines.Add("<rect x=\"12\" y=\"12\" width=\"12\" height=\"12\" fill=\"#E03131\" />");
        }

        lines.Add("</svg>");
        return string.Join(Environment.NewLine, lines);
    }

    private void ExportSingleLineDiagram()
    {
        if (string.IsNullOrWhiteSpace(_lastSingleLineDiagramSvgPath) || !File.Exists(_lastSingleLineDiagramSvgPath))
        {
            SaveSingleLineDiagram();
        }

        var dialog = new SaveFileDialog
        {
            Title = "Export single line diagram",
            FileName = "single-line-diagram.dxf",
            Filter = "CAD DXF|*.dxf|SVG drawing|*.svg|All files|*.*",
        };
        if (dialog.ShowDialog(this) != true)
        {
            return;
        }

        if (Path.GetExtension(dialog.FileName).Equals(".svg", StringComparison.OrdinalIgnoreCase))
        {
            File.Copy(_lastSingleLineDiagramSvgPath, dialog.FileName, overwrite: true);
        }
        else
        {
            File.WriteAllText(dialog.FileName, BuildSingleLineDiagramDxf(_lastSingleLineDiagramModel));
        }

        SetStatus($"Exported single line diagram: {Path.GetFileName(dialog.FileName)}");
    }

    private static string BuildSingleLineDiagramDxf(BuiltModelRecord? model)
    {
        if (model is null)
        {
            return "0\nSECTION\n2\nENTITIES\n0\nENDSEC\n0\nEOF\n";
        }

        var lines = new List<string> { "0", "SECTION", "2", "ENTITIES" };
        var index = 0;
        foreach (var edge in model.CartesianMap.Edges.Take(5000))
        {
            lines.AddRange(new[] { "0", "LINE", "8", edge.FeederId, "10", (index * 10).ToString(), "20", "0", "11", (index * 10 + 8).ToString(), "21", edge.VoltageKv >= 33 ? "30" : "10" });
            index++;
        }

        lines.AddRange(new[] { "0", "ENDSEC", "0", "EOF" });
        return string.Join("\n", lines);
    }

    private void PrintSingleLineDiagram()
    {
        var dialog = new PrintDialog();
        if (dialog.ShowDialog() == true)
        {
            dialog.PrintVisual(SldPreviewCanvas, "ROA single line diagram");
            SetStatus("Single line diagram sent to printer/PDF");
        }
    }

    private void ToggleSldPreviewExpansion()
    {
        _sldPreviewExpanded = !_sldPreviewExpanded;
        ReportsStoragePanel.Visibility = _sldPreviewExpanded ? Visibility.Collapsed : Visibility.Visible;
        ExpandSldPreviewButton.Content = _sldPreviewExpanded ? "Restore Preview" : "Expand Preview";
    }

    private void ClearSldSearchPlaceholder()
    {
        if (SldSearchBox.Text.StartsWith("Search", StringComparison.OrdinalIgnoreCase))
        {
            SldSearchBox.Text = "";
            SldSearchBox.Foreground = BrushFrom("#132033");
        }
    }

    private void RestoreSldSearchPlaceholder()
    {
        if (string.IsNullOrWhiteSpace(SldSearchBox.Text))
        {
            SldSearchBox.Text = "Search assets, feeders, reclosers...";
            SldSearchBox.Foreground = BrushFrom("#667287");
        }
    }

}
