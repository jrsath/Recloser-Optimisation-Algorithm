using System;
using System.Collections.Generic;

namespace RecloserOptimisation.App.Models;

// Project metadata and persistent storage indexes for one workspace project.
public sealed class ProjectRecord
{
    // Stable project ID used in workspace state and built model records.
    public string Id { get; set; } = "";
    // User-facing project name.
    public string Name { get; set; } = "";
    // UTC timestamp for project creation.
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    // UTC timestamp for the latest project metadata update.
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    // Current project settings for map defaults, cache behavior, and active model IDs.
    public ProjectSettings Settings { get; set; } = new();
    // Source-file storage rows that should survive app sessions.
    public List<StagedImport> SourceFiles { get; set; } = new();
    // Processed-file storage rows that should survive app sessions.
    public List<ProcessedFile> ProcessedFiles { get; set; } = new();
}
