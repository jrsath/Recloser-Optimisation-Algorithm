namespace RecloserOptimisation.App.Models;

// Storage row for a generated or planned report/output artifact.
public sealed class ReportRow
{
    // User-facing report name.
    public string Report { get; set; } = "";
    // Report category such as model, analysis, or validation.
    public string Category { get; set; } = "";
    // Generation or availability status.
    public string Status { get; set; } = "";
    // Editable label used to group completed outputs.
    public string Label { get; set; } = "";
    // Whether destructive actions are blocked for this storage row.
    public bool Locked { get; set; }
    // Upload or generated timestamp shown in complete storage.
    public string Uploaded { get; set; } = "";
    // Optional local path to the report file.
    public string Path { get; set; } = "";
}
