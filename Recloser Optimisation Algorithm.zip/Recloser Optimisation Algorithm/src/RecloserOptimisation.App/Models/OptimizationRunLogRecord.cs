namespace RecloserOptimisation.App.Models;

// Row shown in Optimization run logs and SAIDI/SAIFI comparison tables.
public sealed class OptimizationRunLogRecord
{
    // Unique optimization or reliability run ID.
    public string RunId { get; set; } = "";
    // Algorithm or assessment method used for the run.
    public string Algorithm { get; set; } = "";
    // Source model ID used by the run.
    public string SourceModelId { get; set; } = "";
    // Output model ID created by the run.
    public string OutputModelId { get; set; } = "";
    // Baseline SAIDI before optimization.
    public double BaselineSaidi { get; set; }
    // Baseline SAIFI before optimization.
    public double BaselineSaifi { get; set; }
    // Improved SAIDI after optimization.
    public double ImprovedSaidi { get; set; }
    // Improved SAIFI after optimization.
    public double ImprovedSaifi { get; set; }
    // Reduction in SAIDI.
    public double SaidiImprovement { get; set; }
    // Reduction in SAIFI.
    public double SaifiImprovement { get; set; }
    // Number of candidate placements or changes made.
    public int Recommendations { get; set; }
    // Current run status.
    public string Status { get; set; } = "";
    // Timestamp shown in the UI.
    public string RunAt { get; set; } = "";
}
