namespace RecloserOptimisation.App.Models;

// Storage row for an imported source file or folder before and during processing.
public sealed class StagedImport
{
    // Whether this source file is currently selected for processing.
    public bool Active { get; set; }
    // Display filename or folder name for the source item.
    public string File { get; set; } = "";
    // User-selected source category, such as GIS or electrical model.
    public string Source { get; set; } = "";
    // Detected source format from extension or folder type.
    public string Format { get; set; } = "";
    // Readable source file size or folder marker.
    public string Size { get; set; } = "";
    // Import timestamp shown in source storage.
    public string Imported { get; set; } = "";
    // Source storage status such as unprocessed, processed, or old version.
    public string Status { get; set; } = "";
    // Editable label used to group files.
    public string Label { get; set; } = "";
    // Whether destructive actions are blocked for this storage row.
    public bool Locked { get; set; }
    // Absolute path to the copied source file or folder in project storage.
    public string Path { get; set; } = "";
}
