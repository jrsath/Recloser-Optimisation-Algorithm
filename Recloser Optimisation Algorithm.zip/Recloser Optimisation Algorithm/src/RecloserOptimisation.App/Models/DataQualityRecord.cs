using System.Collections.Generic;

namespace RecloserOptimisation.App.Models;

// Data quality scores and actionable issues generated from the selected model.
public sealed class DataQualityResultRecord
{
    public double Completeness { get; set; }
    public double Quality { get; set; }
    public double Integrity { get; set; }
    public double DataSize { get; set; }
    public double MapSize { get; set; }
    public double Verification { get; set; }
    public double Overall => (Completeness + Quality + Integrity + DataSize + MapSize + Verification) / 6.0;
    public List<DataQualityIssueRecord> Issues { get; set; } = new();
}

// One data quality error, warning, fix, or assumption that can optionally map to a node.
public sealed class DataQualityIssueRecord
{
    public string Category { get; set; } = "";
    public string Severity { get; set; } = "";
    public string Summary { get; set; } = "";
    public string Detail { get; set; } = "";
    public string NodeId { get; set; } = "";
    public bool FixedWithAssumption { get; set; }
    public string Display => $"{Severity}: {Summary}";
}
