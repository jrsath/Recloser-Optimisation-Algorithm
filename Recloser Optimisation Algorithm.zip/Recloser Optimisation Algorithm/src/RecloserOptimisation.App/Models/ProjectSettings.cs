namespace RecloserOptimisation.App.Models;

// User-editable settings saved with each project.
public sealed class ProjectSettings
{
    // Number of built model versions to retain in project history.
    public int VersionHistoryLimit { get; set; } = 5;
    // Default map source selected when this project opens.
    public string DefaultMapSource { get; set; } = "Offline mode";
    // Default schematic or study area selected when this project opens.
    public string DefaultMapArea { get; set; } = "New Zealand overview";
    // Named processing pipeline shown for project-level configuration.
    public string ProcessingPipeline { get; set; } = "Adapter driven processing";
    // Named optimization/model contract shown for project-level configuration.
    public string OptimizationPipeline { get; set; } = "Common model JSON contract";
    // Whether online map layers should be cached when viewed.
    public bool CacheLayersWhenOnline { get; set; } = true;
    // Whether cached map tiles should be preferred before online refreshes.
    public bool UseOfflineCacheFirst { get; set; } = true;
    // Legacy/default map mode label retained for saved project compatibility.
    public string DefaultMapMode { get; set; } = "Offline";
    // Built model ID currently active for project-level map and optimization workflows.
    public string ActiveModelId { get; set; } = "";
    // Label applied to bundled example processed data rows.
    public string ExampleDataLabel { get; set; } = "Example data";
}
