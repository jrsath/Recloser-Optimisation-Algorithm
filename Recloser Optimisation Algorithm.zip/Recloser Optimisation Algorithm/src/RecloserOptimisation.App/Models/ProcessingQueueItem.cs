namespace RecloserOptimisation.App.Models;

// One queued source file and ruleset combination in the processing workflow.
public sealed class ProcessingQueueItem
{
    // Run order inside the staged processing queue.
    public int Order { get; set; }
    // Source file name being processed.
    public string File { get; set; } = "";
    // Processing task or mode selected by the user.
    public string Task { get; set; } = "";
    // Ruleset or adapter plan applied to this queued item.
    public string Ruleset { get; set; } = "";
    // Current processing state shown in the running processes grid.
    public string Status { get; set; } = "";
}
