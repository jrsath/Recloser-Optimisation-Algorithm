namespace RecloserOptimisation.App.Models;

// Storage row for a file that has been processed or built into a usable project/model artifact.
public sealed class ProcessedFile
{
    // Whether this file is selected as input for model building or map display.
    public bool Active { get; set; }
    // Display filename for the processed artifact.
    public string File { get; set; } = "";
    // Processed artifact category.
    public string Type { get; set; } = "";
    // Workflow areas that can consume this processed artifact.
    public string Feeds { get; set; } = "";
    // Processing or storage status shown in grids.
    public string Status { get; set; } = "";
    // Editable label used to group files, such as Example data or Imported data.
    public string Label { get; set; } = "";
    // Whether destructive actions are blocked for this storage row.
    public bool Locked { get; set; }
    // Upload or generated timestamp shown in storage.
    public string Uploaded { get; set; } = "";
    // Absolute or app-relative path to the stored artifact.
    public string Path { get; set; } = "";
}
