using System;
using System.Collections.Generic;

namespace RecloserOptimisation.App.Models;

// Saved project model produced by the model-builder and optimization pipeline.
public sealed class BuiltModelRecord
{
    // Unique model version ID used as the saved JSON filename.
    public string Id { get; set; } = "";

    // User-facing model name shown in storage and map selectors.
    public string Name { get; set; } = "";

    // ID of the project that owns this model.
    public string ProjectId { get; set; } = "";

    // Base model ID used for reliability comparisons when this is an optimized model.
    public string BaselineModelId { get; set; } = "";

    // UTC timestamp for when this model file was built.
    public DateTime BuiltAt { get; set; } = DateTime.UtcNow;

    // Current pipeline status, such as Cartesian map or optimized vector map.
    public string Status { get; set; } = "Built";

    // Processed file names used to build this model version.
    public List<string> SourceProcessedFiles { get; set; } = new();

    // Build notes and validation messages surfaced to storage previews.
    public List<string> ValidationMessages { get; set; } = new();

    // Source-oriented base model parsed directly from processed files before conversion.
    public BaseModelRecord BaseModel { get; set; } = new();

    // Renderable Cartesian geometry and component storage.
    public CartesianMapRecord CartesianMap { get; set; } = new();

    // Polar vector representation used by the optimization pass.
    public PolarMapRecord PolarMap { get; set; } = new();

    // Baseline reliability values calculated before optimization.
    public ReliabilityMetricsRecord BaselineReliability { get; set; } = new();

    // Optimization output, proposed placements, and improved reliability values.
    public OptimizationResultRecord Optimization { get; set; } = new();
}

// Base model parsed from processed files before Cartesian or polar conversion.
public sealed class BaseModelRecord
{
    public string CoordinateSystem { get; set; } = "LongitudeLatitude";
    public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;
    public List<string> SourceFiles { get; set; } = new();
    public List<CartesianNodeRecord> Nodes { get; set; } = new();
    public List<CartesianEdgeRecord> Lines { get; set; } = new();
    public List<ModelLoadRecord> Loads { get; set; } = new();
    public List<ModelTransformerRecord> Transformers { get; set; } = new();
    public List<ModelSwitchRecord> Switches { get; set; } = new();
    public List<ModelProtectionDeviceRecord> ProtectionDevices { get; set; } = new();
    public List<ModelFeederRecord> Feeders { get; set; } = new();
}

// Cartesian map payload containing nodes, edges, and parsed feeder components.
public sealed class CartesianMapRecord
{
    // Coordinate convention used by the node geometry.
    public string CoordinateSystem { get; set; } = "LongitudeLatitude";

    // UTC timestamp for when the Cartesian geometry was generated.
    public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;

    // Renderable network nodes with coordinates.
    public List<CartesianNodeRecord> Nodes { get; set; } = new();

    // Renderable network edges that connect node IDs.
    public List<CartesianEdgeRecord> Edges { get; set; } = new();

    // Customer load records attached to model nodes.
    public List<ModelLoadRecord> Loads { get; set; } = new();

    // Distribution transformer records attached to model nodes.
    public List<ModelTransformerRecord> Transformers { get; set; } = new();

    // Switch and tie-point records attached to model nodes.
    public List<ModelSwitchRecord> Switches { get; set; } = new();

    // Protection device records, including existing reclosers.
    public List<ModelProtectionDeviceRecord> ProtectionDevices { get; set; } = new();

    // Feeder summary records used by reliability calculations.
    public List<ModelFeederRecord> Feeders { get; set; } = new();
}

// One map node in the Cartesian model overlay.
public sealed class CartesianNodeRecord
{
    // Node identifier matched by line FromNode and ToNode values.
    public string Id { get; set; } = "";

    // Node component type, such as substation or processed input.
    public string Type { get; set; } = "";

    // Latitude in decimal degrees.
    public double Latitude { get; set; }

    // Longitude in decimal degrees.
    public double Longitude { get; set; }

    // Elevation in metres when available.
    public double ElevationM { get; set; }

    // Feeder identifier used for grouping and filtering.
    public string FeederId { get; set; } = "";

    // Source system or dataset label.
    public string Source { get; set; } = "";

    // Component status from the processed input file.
    public string Status { get; set; } = "";
}

// One line or connection in the Cartesian model overlay.
public sealed class CartesianEdgeRecord
{
    // Line or edge identifier.
    public string Id { get; set; } = "";

    // Source node ID for the edge.
    public string FromNode { get; set; } = "";

    // Target node ID for the edge.
    public string ToNode { get; set; } = "";

    // Feeder identifier used for grouping and filtering.
    public string FeederId { get; set; } = "";

    // Nominal line voltage used by layer filters.
    public double VoltageKv { get; set; }

    // Line length in metres.
    public double LengthM { get; set; }

    // Conductor type from the processed line record.
    public string Conductor { get; set; } = "";

    // Phase label from the processed line record.
    public string Phase { get; set; } = "";

    // Whether this line is normally energized.
    public bool NormallyEnergised { get; set; } = true;

    // Component status from the processed input file.
    public string Status { get; set; } = "";
}

// Customer load attached to a model node.
public sealed class ModelLoadRecord
{
    public string Id { get; set; } = "";
    public string NodeId { get; set; } = "";
    public double Kva { get; set; }
    public int Customers { get; set; }
    public string Phase { get; set; } = "";
    public string FeederId { get; set; } = "";
    public string Status { get; set; } = "";
}

// Distribution transformer attached to a model node.
public sealed class ModelTransformerRecord
{
    public string Id { get; set; } = "";
    public string NodeId { get; set; } = "";
    public double Kva { get; set; }
    public double PrimaryKv { get; set; }
    public double SecondaryKv { get; set; }
    public string Phase { get; set; } = "";
    public string FeederId { get; set; } = "";
    public string Status { get; set; } = "";
}

// Switch or tie device attached to a model node.
public sealed class ModelSwitchRecord
{
    public string Id { get; set; } = "";
    public string SwitchType { get; set; } = "";
    public string NodeId { get; set; } = "";
    public string Normally { get; set; } = "";
    public double VoltageKv { get; set; }
    public string FeederId { get; set; } = "";
    public string Status { get; set; } = "";
}

// Existing or proposed protection device attached to a model node.
public sealed class ModelProtectionDeviceRecord
{
    public string Id { get; set; } = "";
    public string AssetType { get; set; } = "";
    public string NodeId { get; set; } = "";
    public double VoltageKv { get; set; }
    public string FeederId { get; set; } = "";
    public string Model { get; set; } = "";
    public string Status { get; set; } = "";
    public bool Proposed { get; set; }
}

// Feeder summary parsed from processed feeder records.
public sealed class ModelFeederRecord
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string SourceSubstation { get; set; } = "";
    public double NominalVoltageKv { get; set; }
    public string Status { get; set; } = "";
}

// Polar vector map derived from Cartesian model geometry.
public sealed class PolarMapRecord
{
    public string OriginNodeId { get; set; } = "";
    public double OriginLatitude { get; set; }
    public double OriginLongitude { get; set; }
    public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;
    public List<PolarNodeRecord> Nodes { get; set; } = new();
    public List<PolarEdgeRecord> Edges { get; set; } = new();
}

// Polar vector for a node relative to the polar map origin.
public sealed class PolarNodeRecord
{
    public string NodeId { get; set; } = "";
    public string Type { get; set; } = "";
    public string FeederId { get; set; } = "";
    public double RadiusM { get; set; }
    public double AngleDeg { get; set; }
    public double XMetres { get; set; }
    public double YMetres { get; set; }
}

// Polar/vector representation for a line edge.
public sealed class PolarEdgeRecord
{
    public string EdgeId { get; set; } = "";
    public string FromNode { get; set; } = "";
    public string ToNode { get; set; } = "";
    public string FeederId { get; set; } = "";
    public double LengthM { get; set; }
    public double AngleDeg { get; set; }
    public double VoltageKv { get; set; }
}

// Reliability metrics returned by the model builder and optimizer.
public sealed class ReliabilityMetricsRecord
{
    public double Saidi { get; set; }
    public double Saifi { get; set; }
    public double Caidi { get; set; }
    public int Customers { get; set; }
    public double TotalLineKm { get; set; }
    public int ExistingReclosers { get; set; }
    public int ProposedReclosers { get; set; }
}

// Optimization result stored with an improved model version.
public sealed class OptimizationResultRecord
{
    public string Algorithm { get; set; } = "";
    public string AlgorithmPath { get; set; } = "";
    public string RunId { get; set; } = "";
    public string BaselineModelId { get; set; } = "";
    public DateTime RunAt { get; set; } = DateTime.UtcNow;
    public string Status { get; set; } = "";
    public ReliabilityMetricsRecord Baseline { get; set; } = new();
    public ReliabilityMetricsRecord Improved { get; set; } = new();
    public double SaidiImprovement { get; set; }
    public double SaifiImprovement { get; set; }
    public List<OptimizationRecommendationRecord> Recommendations { get; set; } = new();
}

// One proposed optimization action, such as placing a recloser at a node.
public sealed class OptimizationRecommendationRecord
{
    public string Id { get; set; } = "";
    public string Action { get; set; } = "";
    public string NodeId { get; set; } = "";
    public string FeederId { get; set; } = "";
    public double Score { get; set; }
    public int ProtectedCustomers { get; set; }
    public double ExpectedSaidiReduction { get; set; }
    public double ExpectedSaifiReduction { get; set; }
}
