using System.Collections.Generic;

namespace RecloserOptimisation.App.Models;

// Workspace account with its own project list.
public sealed class UserAccount
{
    // Stable account ID stored in workspace state.
    public string Id { get; set; } = "";
    // User-facing account name.
    public string DisplayName { get; set; } = "";
    // Role label displayed in settings.
    public string Role { get; set; } = "";
    // Reserved password field while authentication remains a placeholder.
    public string Password { get; set; } = "";
    // Projects owned by this account.
    public List<ProjectRecord> Projects { get; set; } = new();
}
