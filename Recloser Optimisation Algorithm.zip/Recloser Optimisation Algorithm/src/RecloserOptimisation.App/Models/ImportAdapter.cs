using System.Text.Json.Serialization;

namespace RecloserOptimisation.App.Models;

// Configured import adapter plan describing an external data source and supported formats.
public sealed class ImportAdapter
{
    // Adapter category, such as GIS, OMS, or protection.
    [JsonPropertyName("category")]
    public string Category { get; set; } = "";

    // Source platform or product this adapter is intended to handle.
    [JsonPropertyName("platform")]
    public string Platform { get; set; } = "";

    // Supported file formats for this adapter plan.
    [JsonPropertyName("formats")]
    public string Formats { get; set; } = "";

    // Readiness or implementation status displayed in adapter storage.
    [JsonPropertyName("status")]
    public string Status { get; set; } = "";

    // Why the adapter exists and which workflow area it feeds.
    [JsonPropertyName("purpose")]
    public string Purpose { get; set; } = "";
}
