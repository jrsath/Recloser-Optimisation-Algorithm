using System.Collections.Generic;

namespace RecloserOptimisation.App.Models;

// Root persisted workspace state containing accounts and the current selection.
public sealed class WorkspaceState
{
    // ID of the account currently selected in the UI.
    public string CurrentAccountId { get; set; } = "admin";
    // ID of the project currently selected in the UI.
    public string CurrentProjectId { get; set; } = "king-country-feeder-study";
    // All configured workspace accounts and their projects.
    public List<UserAccount> Accounts { get; set; } = new();
}
