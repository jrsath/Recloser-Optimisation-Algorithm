namespace RecloserOptimisation.App.Models;

// Row describing an available or imported optimization algorithm.
public sealed class OptimizationAlgorithmRecord
{
    // User-facing algorithm name.
    public string Name { get; set; } = "";
    // Algorithm family or optimization approach.
    public string Type { get; set; } = "";
    // Readiness or run state displayed in the algorithm grid.
    public string Status { get; set; } = "";
    // Optional local path to an imported algorithm package.
    public string Path { get; set; } = "";
}
