using System.Windows.Controls;
using RecloserOptimisation.App.ViewModels;

namespace RecloserOptimisation.App.Views;

public partial class ModelView : UserControl
{
    public ModelView()
    {
        InitializeComponent();
        DataContext = new ModelViewModel();
    }
}
