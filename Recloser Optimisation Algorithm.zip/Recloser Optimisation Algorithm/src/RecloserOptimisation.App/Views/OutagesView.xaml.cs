using System.Windows.Controls;
using RecloserOptimisation.App.ViewModels;

namespace RecloserOptimisation.App.Views;

public partial class OutagesView : UserControl
{
    public OutagesView()
    {
        InitializeComponent();
        DataContext = new OutagesViewModel();
    }
}
