using System.Windows.Controls;
using RecloserOptimisation.App.ViewModels;

namespace RecloserOptimisation.App.Views;

public partial class MapView : UserControl
{
    public MapView()
    {
        InitializeComponent();
        DataContext = new MapViewModel();
    }
}
