using System.Windows.Controls;
using RecloserOptimisation.App.ViewModels;

namespace RecloserOptimisation.App.Views;

public partial class OptimizationView : UserControl
{
    public OptimizationView()
    {
        InitializeComponent();
        DataContext = new OptimizationViewModel();
    }
}
