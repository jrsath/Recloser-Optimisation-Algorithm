using System.Windows.Controls;
using RecloserOptimisation.App.ViewModels;

namespace RecloserOptimisation.App.Views;

public partial class ProcessingView : UserControl
{
    public ProcessingView()
    {
        InitializeComponent();
        DataContext = new ProcessingViewModel();
    }
}
