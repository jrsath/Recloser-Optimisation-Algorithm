using System.Windows.Controls;
using RecloserOptimisation.App.ViewModels;

namespace RecloserOptimisation.App.Views;

public partial class ValidationView : UserControl
{
    public ValidationView()
    {
        InitializeComponent();
        DataContext = new ValidationViewModel();
    }
}
