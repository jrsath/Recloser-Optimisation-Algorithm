using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using RecloserOptimisation.App.Models;

namespace RecloserOptimisation.App.Services;

// Persists account, project, and project-file metadata under the user's local ROA workspace folder.
public sealed class WorkspaceStore
{
    private readonly JsonSerializerOptions _jsonOptions = new() { WriteIndented = true };

    // Root folder for all per-user workspace state and project storage.
    public string RootPath { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "ROA",
        "Workspace");

    // JSON file that stores accounts, project metadata, and active project IDs.
    public string StatePath => Path.Combine(RootPath, "workspace-state.json");

    // Loads workspace state from disk, creates defaults when missing, and ensures folders exist.
    public WorkspaceState Load()
    {
        Directory.CreateDirectory(RootPath);

        var state = File.Exists(StatePath)
            ? JsonSerializer.Deserialize<WorkspaceState>(File.ReadAllText(StatePath)) ?? CreateDefaultState()
            : CreateDefaultState();

        EnsureDefaults(state);
        Save(state);
        EnsureWorkspaceFolders(state);
        return state;
    }

    // Saves workspace state and refreshes the project folder structure.
    public void Save(WorkspaceState state)
    {
        Directory.CreateDirectory(RootPath);
        File.WriteAllText(StatePath, JsonSerializer.Serialize(state, _jsonOptions));
        EnsureWorkspaceFolders(state);
    }

    // Returns the selected account, falling back to the first account if the stored ID is stale.
    public UserAccount CurrentAccount(WorkspaceState state)
    {
        return state.Accounts.FirstOrDefault(account => account.Id == state.CurrentAccountId)
            ?? state.Accounts.First();
    }

    // Returns the selected project for the current account, falling back to that account's first project.
    public ProjectRecord CurrentProject(WorkspaceState state)
    {
        var account = CurrentAccount(state);
        return account.Projects.FirstOrDefault(project => project.Id == state.CurrentProjectId)
            ?? account.Projects.First();
    }

    // Builds the filesystem path for an account/project pair.
    public string ProjectPath(UserAccount account, ProjectRecord project)
    {
        return Path.Combine(RootPath, SafeFolderName(account.DisplayName), SafeFolderName(project.Name));
    }

    // Returns and creates a named storage folder for the active project.
    public string ProjectFolder(WorkspaceState state, string folderName)
    {
        var account = CurrentAccount(state);
        var project = CurrentProject(state);
        var folder = Path.Combine(ProjectPath(account, project), folderName);
        Directory.CreateDirectory(folder);
        return folder;
    }

    // Returns the active project's current built-model storage folder.
    public string BuiltModelsPath(WorkspaceState state)
    {
        return ProjectFolder(state, "built-models");
    }

    // Returns the active project's version history folder for built models.
    public string ModelHistoryPath(WorkspaceState state)
    {
        return ProjectFolder(state, "model-history");
    }

    // Creates an account with an initial project and makes it the active workspace account.
    public UserAccount AddAccount(WorkspaceState state, string displayName)
    {
        var account = new UserAccount
        {
            Id = UniqueId(displayName, state.Accounts.Select(existing => existing.Id)),
            DisplayName = displayName,
            Role = "User",
            Password = "",
        };

        account.Projects.Add(CreateProject("New project"));
        state.Accounts.Add(account);
        state.CurrentAccountId = account.Id;
        state.CurrentProjectId = account.Projects[0].Id;
        Save(state);
        return account;
    }

    // Creates a project under an account and makes it the active project.
    public ProjectRecord AddProject(WorkspaceState state, UserAccount account, string projectName)
    {
        var project = CreateProject(projectName);
        project.Id = UniqueId(projectName, account.Projects.Select(existing => existing.Id));
        account.Projects.Add(project);
        state.CurrentAccountId = account.Id;
        state.CurrentProjectId = project.Id;
        Save(state);
        return project;
    }

    // Builds the default Admin and Guest workspace state for first launch.
    private static WorkspaceState CreateDefaultState()
    {
        return new WorkspaceState
        {
            CurrentAccountId = "admin",
            CurrentProjectId = "king-country-feeder-study",
            Accounts =
            {
                new UserAccount
                {
                    Id = "admin",
                    DisplayName = "Admin",
                    Role = "Administrator",
                    Password = "",
                    Projects =
                    {
                        CreateProject("King Country feeder study", "king-country-feeder-study"),
                    },
                },
                new UserAccount
                {
                    Id = "guest",
                    DisplayName = "Guest",
                    Role = "Guest",
                    Password = "",
                    Projects =
                    {
                        CreateProject("Guest project", "guest-project"),
                    },
                },
            },
        };
    }

    // Creates a project record with IDs and timestamps initialized.
    private static ProjectRecord CreateProject(string name, string? id = null)
    {
        return new ProjectRecord
        {
            Id = id ?? SafeId(name),
            Name = name,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
        };
    }

    // Repairs missing required accounts, projects, and active IDs after loading older state files.
    private static void EnsureDefaults(WorkspaceState state)
    {
        if (state.Accounts.All(account => account.Id != "admin"))
        {
            state.Accounts.Insert(0, new UserAccount
            {
                Id = "admin",
                DisplayName = "Admin",
                Role = "Administrator",
                Password = "",
                Projects = { CreateProject("King Country feeder study", "king-country-feeder-study") },
            });
        }

        var jack = state.Accounts.FirstOrDefault(account =>
            account.DisplayName.Equals("Jack Satherley", StringComparison.OrdinalIgnoreCase));
        if (jack is not null)
        {
            jack.Id = "admin";
            jack.DisplayName = "Admin";
            jack.Role = "Administrator";
            jack.Password = "";
        }

        if (state.Accounts.All(account => account.Id != "guest"))
        {
            state.Accounts.Add(new UserAccount
            {
                Id = "guest",
                DisplayName = "Guest",
                Role = "Guest",
                Password = "",
                Projects = { CreateProject("Guest project", "guest-project") },
            });
        }

        foreach (var account in state.Accounts.Where(account => account.Projects.Count == 0))
        {
            account.Projects.Add(CreateProject($"{account.DisplayName} project"));
        }

        if (state.Accounts.All(account => account.Id != state.CurrentAccountId))
        {
            state.CurrentAccountId = state.Accounts[0].Id;
        }

        var currentAccount = state.Accounts.First(account => account.Id == state.CurrentAccountId);
        if (currentAccount.Projects.All(project => project.Id != state.CurrentProjectId))
        {
            state.CurrentProjectId = currentAccount.Projects[0].Id;
        }
    }

    // Creates the standard storage folders for every account/project in the workspace state.
    private void EnsureWorkspaceFolders(WorkspaceState state)
    {
        foreach (var account in state.Accounts)
        {
            foreach (var project in account.Projects)
            {
                var projectPath = ProjectPath(account, project);
                foreach (var folder in new[]
                         {
                             "source-files",
                             "processed-files",
                             "built-models",
                             "model-history",
                             "reports",
                             "adapters",
                             "templates",
                             Path.Combine("map-cache", "linz"),
                             Path.Combine("map-cache", "tiles"),
                         })
                {
                    Directory.CreateDirectory(Path.Combine(projectPath, folder));
                }
            }
        }
    }

    // Generates a stable slug ID that does not collide with existing IDs.
    private static string UniqueId(string value, IEnumerable<string> existingIds)
    {
        var baseId = SafeId(value);
        var ids = existingIds.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var candidate = baseId;
        var suffix = 2;
        while (ids.Contains(candidate))
        {
            candidate = $"{baseId}-{suffix++}";
        }

        return candidate;
    }

    // Converts user-facing text into a lowercase slug suitable for project/account IDs.
    private static string SafeId(string value)
    {
        var chars = value.Trim().ToLowerInvariant()
            .Select(character => char.IsLetterOrDigit(character) ? character : '-')
            .ToArray();

        var id = string.Join("", chars).Trim('-');
        while (id.Contains("--", StringComparison.Ordinal))
        {
            id = id.Replace("--", "-");
        }

        return string.IsNullOrWhiteSpace(id) ? "item" : id;
    }

    // Converts user-facing text into a folder name that is valid on Windows.
    private static string SafeFolderName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars().ToHashSet();
        var safe = new string(value.Select(character => invalid.Contains(character) ? '-' : character).ToArray()).Trim();
        return string.IsNullOrWhiteSpace(safe) ? "Workspace" : safe;
    }
}
