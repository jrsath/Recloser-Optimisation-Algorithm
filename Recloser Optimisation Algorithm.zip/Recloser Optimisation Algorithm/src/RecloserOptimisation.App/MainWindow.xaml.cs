using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using RecloserOptimisation.App.Models;
using RecloserOptimisation.App.Services;

namespace RecloserOptimisation.App;

public partial class MainWindow : Window
{
    // Owns application state and bootstraps the feature-specific partial classes.
    private readonly ObservableCollection<StagedImport> _imports = new();
    private readonly ObservableCollection<ImportAdapter> _adapters = new();
    private readonly ObservableCollection<ReportRow> _reports = new();
    private readonly ObservableCollection<ProcessedFile> _processedFiles = new();
    private readonly ObservableCollection<ProcessedFile> _builtModels = new();
    private readonly ObservableCollection<ProcessedFile> _workingDirectoryFiles = new();
    private readonly ObservableCollection<ProcessedFile> _buildMenuFiles = new();
    private readonly ObservableCollection<ProcessedFile> _outageDataFiles = new();
    private readonly ObservableCollection<OptimizationAlgorithmRecord> _optimizationAlgorithms = new();
    private readonly ObservableCollection<ProcessingQueueItem> _processingQueue = new();
    private readonly ObservableCollection<StagedImport> _selectedProcessingFiles = new();
    private readonly ICollectionView _importsView;
    private readonly ICollectionView _processedFilesView;
    private readonly Dictionary<string, FrameworkElement> _pages;
    private readonly Button[] _navButtons;
    private readonly JsonSerializerOptions _jsonOptions = new() { WriteIndented = true };
    private readonly HttpClient _tileHttpClient = new();
    private readonly string _tileCacheRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ROA", "MapTiles");
    private readonly DispatcherTimer _mapRenderTimer = new() { Interval = TimeSpan.FromMilliseconds(24) };
    private readonly TranslateTransform _mapDragTransform = new();
    private readonly Dictionary<string, BitmapImage?> _tileBitmapCache = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _pendingTileDownloads = new(StringComparer.OrdinalIgnoreCase);
    private readonly WorkspaceStore _workspaceStore = new();
    private WorkspaceState _workspaceState = new();

    private bool _isDragging;
    private bool _isUpdatingWorkspaceControls;
    private Point _dragStartPoint;
    private Point _lastMapPoint;
    private Point _lastDragPoint;
    private bool _hasLastMapPoint;
    private string _developerOriginalModelId = "";
    private string _developerCopyModelId = "";
    private string _cachedMapModelPath = "";
    private DateTime _cachedMapModelWriteTime;
    private BuiltModelRecord? _cachedMapModel;
    private DateTime _lastMapReadoutUpdateUtc;
    private string _lastSingleLineDiagramJsonPath = "";
    private string _lastSingleLineDiagramSvgPath = "";
    private BuiltModelRecord? _lastSingleLineDiagramModel;
    private bool _sldPreviewExpanded;
    private double _centerLat = -41.2865;
    private double _centerLng = 174.7762;
    private int _zoom = 6;
    private string _activeLayer = "Current project map";
    private string _activeBaseLayer = "Map";

    public MainWindow()
    {
        InitializeComponent();
        TileCanvas.RenderTransform = _mapDragTransform;
        _tileHttpClient.DefaultRequestHeaders.UserAgent.ParseAdd("ROA/0.1 desktop map tile cache");
        _mapRenderTimer.Tick += (_, _) =>
        {
            _mapRenderTimer.Stop();
            RenderMap();
        };

        _pages = new Dictionary<string, FrameworkElement>
        {
            ["Dashboard"] = DashboardView,
            ["Ingestion"] = DatabaseView,
            ["Map"] = MapView,
            ["Outages"] = OutagesView,
            ["Optimization"] = OptimizationView,
            ["Reports"] = ReportsView,
            ["Settings"] = SettingsView,
        };

        _navButtons = new[]
        {
            NavDashboard,
            NavIngestion,
            NavMap,
            NavOutages,
            NavOptimization,
            NavReports,
            NavSettings,
        };

        _importsView = CollectionViewSource.GetDefaultView(_imports);
        _importsView.Filter = FilterImport;
        _processedFilesView = CollectionViewSource.GetDefaultView(_processedFiles);
        _processedFilesView.Filter = FilterProcessedFile;

        ImportsGrid.ItemsSource = _importsView;
        DashboardImportsGrid.ItemsSource = _imports;
        AdapterFilesGrid.ItemsSource = _adapters;
        ReportsGrid.ItemsSource = _reports;
        ProcessedFilesGrid.ItemsSource = _processedFilesView;
        ProjectModelStorageGrid.ItemsSource = _builtModels;
        WorkingDirectoryGrid.ItemsSource = _workingDirectoryFiles;
        BuildMenuGrid.ItemsSource = _buildMenuFiles;
        OutageDataGrid.ItemsSource = _outageDataFiles;
        SavedReportsGrid.ItemsSource = _reports;
        OptimizationAlgorithmsGrid.ItemsSource = _optimizationAlgorithms;
        ProcessingQueueGrid.ItemsSource = _processingQueue;
        SelectedProcessingFilesCombo.ItemsSource = _selectedProcessingFiles;
        BindEvents();
        RegisterHelpBlurbs();
        LoadWorkspace();
        LoadAdapters();
        ReloadProjectStorage();
        LoadOptimizationAlgorithms();
        LoadReports();
        ShowPage("Dashboard");
        UpdateDeveloperMapModeVisibility();
        ApplyMapViewMode();
        RadarCanvas.SizeChanged += (_, _) => RenderRadar();
    }
}

